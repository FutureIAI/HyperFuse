# -*- coding: utf-8 -*-
"""
FPCSD 数据集划分脚本：把原始图像按论文 4.1 的比例分成 train / val / test。
默认 1514 / 300 / 400，可以在命令行改。同板卡图像不进多个集合（可选开启）。
用法:
    python split_dataset.py --src_img /path/to/images --src_lbl /path/to/labels \
        --out /path/to/dataset_baseline --train 1514 --val 300 --test 400
"""
import os
import shutil
import random
import argparse


def collect_pairs(img_dir, lbl_dir):
    """收集 (图像路径, 标签路径) 配对，标签缺失的图跳过"""
    pairs = []
    for name in sorted(os.listdir(img_dir)):
        if not name.lower().endswith((".jpg", ".png", ".jpeg")):
            continue
        base = os.path.splitext(name)[0]
        lbl = os.path.join(lbl_dir, base + ".txt")
        if not os.path.exists(lbl):
            print(f"跳过无标签图像: {name}")
            continue
        pairs.append((os.path.join(img_dir, name), lbl))
    return pairs


def group_by_board(pairs):
    """
    按文件名前缀分组，前缀相同的认为属于同一块板卡。
    这里前缀取文件名里第一个下划线之前的部分，实际命名不同的话改这里。
    """
    groups = {}
    for img, lbl in pairs:
        base = os.path.splitext(os.path.basename(img))[0]
        prefix = base.split("_")[0]
        groups.setdefault(prefix, []).append((img, lbl))
    return list(groups.values())


def copy_set(items, out_img, out_lbl):
    os.makedirs(out_img, exist_ok=True)
    os.makedirs(out_lbl, exist_ok=True)
    for img, lbl in items:
        shutil.copy(img, out_img)
        shutil.copy(lbl, out_lbl)


def main():
    parser = argparse.ArgumentParser(description="FPCSD train/val/test 划分")
    parser.add_argument("--src_img", required=True, help="原始图像目录")
    parser.add_argument("--src_lbl", required=True, help="YOLO 标签目录")
    parser.add_argument("--out", required=True, help="输出根目录，下面会自动建 images/ labels/")
    parser.add_argument("--train", type=int, default=1514)
    parser.add_argument("--val", type=int, default=300)
    parser.add_argument("--test", type=int, default=400)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--by_board", action="store_true", help="按板卡前缀分组划分")
    args = parser.parse_args()

    pairs = collect_pairs(args.src_img, args.src_lbl)
    total = len(pairs)
    print(f"共 {total} 张有标注图像")
    if total < args.train + args.val + args.test:
        raise SystemExit(f"图像数量不足: {total} < {args.train + args.val + args.test}")

    random.seed(args.seed)

    if args.by_board:
        groups = group_by_board(pairs)
        random.shuffle(groups)
        train_items, val_items, test_items = [], [], []
        for g in groups:
            if len(train_items) < args.train:
                train_items.extend(g)
            elif len(val_items) < args.val:
                val_items.extend(g)
            else:
                test_items.extend(g)
        # 最后各自截断到目标数量，保证集合间不重叠
        train_items = train_items[:args.train]
        val_items = val_items[:args.val]
        test_items = test_items[:args.test]
    else:
        random.shuffle(pairs)
        train_items = pairs[:args.train]
        val_items = pairs[args.train:args.train + args.val]
        test_items = pairs[args.train + args.val:args.train + args.val + args.test]

    base = args.out
    copy_set(train_items, os.path.join(base, "images", "train"), os.path.join(base, "labels", "train"))
    copy_set(val_items, os.path.join(base, "images", "val"), os.path.join(base, "labels", "val"))
    copy_set(test_items, os.path.join(base, "images", "test"), os.path.join(base, "labels", "test"))

    print(f"train: {len(train_items)}  val: {len(val_items)}  test: {len(test_items)}")
    print(f"输出目录: {base}")


if __name__ == "__main__":
    main()
