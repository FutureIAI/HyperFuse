# -*- coding: utf-8 -*-
"""
生成质量评估脚本（对应论文 Table 5 的 FID / SSIM / LPIPS）：
按缺陷框把真实集和生成集的 patch 裁出来，
- FID: Inception-v3 特征，比较两组 patch 分布（默认全量）
- SSIM / LPIPS: 随机抽 500 对求平均（--pairs 可改）
用法:
    python eval_metrics.py --real_img ... --real_lbl ... \
        --gen_img ... --gen_lbl ... --out ./eval_result
"""
import os
import shutil
import random
import argparse
import tempfile

import cv2
import numpy as np
import torch
from PIL import Image
from tqdm import tqdm


def crop_defect_patch(img_dir, lbl_dir, name, size=128):
    """按第一个标签框裁缺陷 patch，resize 到固定尺寸"""
    img = cv2.imread(os.path.join(img_dir, name))
    if img is None:
        return None
    txt = os.path.join(lbl_dir, os.path.splitext(name)[0] + ".txt")
    if not os.path.exists(txt):
        return None
    with open(txt, "r") as f:
        line = f.readline().strip()
    if not line:
        return None
    _, cx, cy, bw, bh = map(float, line.split())
    h, w = img.shape[:2]
    x1 = max(0, int((cx - bw / 2) * w))
    y1 = max(0, int((cy - bh / 2) * h))
    x2 = min(w, int((cx + bw / 2) * w))
    y2 = min(h, int((cy + bh / 2) * h))
    if x2 <= x1 or y2 <= y1:
        return None
    patch = img[y1:y2, x1:x2]
    return cv2.resize(patch, (size, size))


def dump_patches(img_dir, lbl_dir, names, out_dir, size=128):
    os.makedirs(out_dir, exist_ok=True)
    count = 0
    for name in tqdm(names, desc=f"抽取 {os.path.basename(out_dir)}"):
        patch = crop_defect_patch(img_dir, lbl_dir, name, size)
        if patch is None:
            continue
        cv2.imwrite(os.path.join(out_dir, f"{count:06d}.png"), patch)
        count += 1
    return count


def collect_names(img_dir, lbl_dir):
    names = []
    for f in sorted(os.listdir(img_dir)):
        if not f.lower().endswith((".jpg", ".png")):
            continue
        txt = os.path.join(lbl_dir, os.path.splitext(f)[0] + ".txt")
        if os.path.exists(txt):
            names.append(f)
    return names


def main():
    parser = argparse.ArgumentParser(description="FID/SSIM/LPIPS 生成质量评估")
    parser.add_argument("--real_img", required=True, help="真实集图像目录")
    parser.add_argument("--real_lbl", required=True)
    parser.add_argument("--gen_img", required=True, help="生成集图像目录")
    parser.add_argument("--gen_lbl", required=True)
    parser.add_argument("--out", default="./eval_result")
    parser.add_argument("--pairs", type=int, default=500, help="SSIM/LPIPS 随机对数")
    parser.add_argument("--patch_size", type=int, default=128)
    parser.add_argument("--fid_batch", type=int, default=32)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--device", default="0")
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    os.makedirs(args.out, exist_ok=True)

    real_names = collect_names(args.real_img, args.real_lbl)
    gen_names = collect_names(args.gen_img, args.gen_lbl)
    print(f"真实集 {len(real_names)} 张, 生成集 {len(gen_names)} 张")

    # ---------------- FID ----------------
    from pytorch_fid.fid_score import calculate_fid_given_paths
    tmp = tempfile.mkdtemp(prefix="fid_")
    real_dir = os.path.join(tmp, "real")
    gen_dir = os.path.join(tmp, "gen")
    n_real = dump_patches(args.real_img, args.real_lbl, real_names, real_dir, args.patch_size)
    n_gen = dump_patches(args.gen_img, args.gen_lbl, gen_names, gen_dir, args.patch_size)
    if n_real == 0 or n_gen == 0:
        raise SystemExit("patch 抽取为空，检查标签格式")
    print(f"FID 参考 {n_real} 张, 生成 {n_gen} 张")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    fid = calculate_fid_given_paths([real_dir, gen_dir], batch_size=args.fid_batch,
                                    device=device, dims=2048)
    print(f"FID: {fid:.4f}")
    shutil.rmtree(tmp, ignore_errors=True)

    # ---------------- SSIM / LPIPS ----------------
    import lpips
    from skimage.metrics import structural_similarity

    loss_fn = lpips.LPIPS(net="alex").to(device).eval()
    n = min(args.pairs, n_real, n_gen)
    real_pool = [crop_defect_patch(args.real_img, args.real_lbl, x, args.patch_size)
                 for x in random.sample(real_names, n)]
    gen_pool = [crop_defect_patch(args.gen_img, args.gen_lbl, x, args.patch_size)
                for x in random.sample(gen_names, n)]
    real_pool = [x for x in real_pool if x is not None]
    gen_pool = [x for x in gen_pool if x is not None]
    n = min(len(real_pool), len(gen_pool))

    ssim_sum, lpips_sum = 0.0, 0.0
    with torch.no_grad():
        for i in tqdm(range(n), desc="SSIM/LPIPS"):
            r = cv2.cvtColor(real_pool[i], cv2.COLOR_BGR2GRAY)
            g = cv2.cvtColor(gen_pool[i], cv2.COLOR_BGR2GRAY)
            ssim_sum += structural_similarity(r, g)

            rt = torch.from_numpy(cv2.cvtColor(real_pool[i], cv2.COLOR_BGR2RGB)
                                  .astype(np.float32) / 255.0).permute(2, 0, 1).unsqueeze(0).to(device)
            gt = torch.from_numpy(cv2.cvtColor(gen_pool[i], cv2.COLOR_BGR2RGB)
                                  .astype(np.float32) / 255.0).permute(2, 0, 1).unsqueeze(0).to(device)
            lpips_sum += loss_fn(rt * 2 - 1, gt * 2 - 1).item()

    ssim_avg = ssim_sum / n
    lpips_avg = lpips_sum / n
    print(f"SSIM (n={n}): {ssim_avg:.4f}")
    print(f"LPIPS (n={n}): {lpips_avg:.4f}")

    report = os.path.join(args.out, "metrics.txt")
    with open(report, "w") as f:
        f.write(f"FID: {fid:.4f}\nSSIM: {ssim_avg:.4f}\nLPIPS: {lpips_avg:.4f}\n")
    print(f"报告已保存: {report}")


if __name__ == "__main__":
    main()
