#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generate_candidates.py  --  HyperFuse synthetic candidate pool generator
=======================================================================
Produces the candidate pool reported in the paper (Sec. 3.2 / 3.3), i.e. the
10,000 candidates that are then screened down to 5,000 by the Poincare module
(`src/poincare_filter.py`).

This file is SELF-CONTAINED on purpose: it implements the paper's placement
gating rules itself and only *imports* low-level feature / fusion helpers from
`src/`. Nothing in `src/` has to be modified for it to run.

Method implemented
------------------
For every source defect patch (one per annotated bbox instance):

1.  Eight surrounding regions are extracted around the defect bbox
    (`placement_features.extract_8_regions`) and their orientation /
    coherence / period / phase descriptors are computed once.
2.  Every training background image except the source image itself is scanned
    at a coarse stride. For each legal window (inside the valid mask built
    from the target's own bboxes plus a 15 px margin, and outside the white
    board border) the scoring chain is evaluated:

        d_sccp    partitioned mean gradient-magnitude difference (8 regions)
        d_trace   coherence-weighted axial orientation difference (degrees)
        d_period  relative period difference, capped at 1.0
        d_phase   cross-correlation peak shift in cycles (soft term only)

3.  Hard gates, exactly as stated in the paper:
      - the orientation gate is active only when the source patch has at
        least 2 direction-reliable regions; with fewer, the gate is skipped;
      - the period gate is active only when the source patch has at least 1
        period-reliable region; with none, the gate is skipped;
      - the composite score itself has NO additional rejection threshold,
        and phase is retained as a soft score term only.
4.  All eligible windows over the whole training pool are pooled together,
    each term is normalized by its own 5th/95th percentile over that pool,
    and the composite score uses the fixed weights

        score = (1 - Lt - Lp - Lph) * D_sccp + Lt * D_trace
                + Lp * D_period + Lph * D_phase

5.  The best placement on each distinct target image is kept, and the top
    `--per_patch` of them become the samples of this source patch. This is the
    wording used in the paper: "retains up to a fixed number of placements
    per patch".
6.  Each kept placement is fused with LAB colour matching
    (`match_patch_lab_to_target`), Poisson blending plus outer-edge feathering
    (`poisson_clone_with_feather`), then cropped to the placement window and
    written out with a single-defect YOLO label.

Output layout (YOLO-compatible)
-------------------------------
    <out>/images/train/cand_00000.jpg
    <out>/labels/train/cand_00000.txt     # "0 cx cy w h", normalized
    <out>/manifest.csv                    # one row per produced sample
    <out>/run_config.json                 # resolved configuration
    <out>/generation_stats.json           # counts, timing, gate statistics

The saved image is the placement-window crop (background neighbourhood with
the fused defect), which is what the quality metrics and the Poincare filter
consume. Use `--crop full` to keep the whole target board instead.

Typical server runs
-------------------
    # 10,000 candidates = about 1,250 source patches x 8 placements
    python scripts/generate_candidates.py \
        --data_root /data/fpcsd --out /data/pool_10k \
        --num 10000 --per_patch 8 --workers 16 --seed 42

    # resume after an interruption (rows already in manifest.csv are skipped)
    python scripts/generate_candidates.py --data_root /data/fpcsd \
        --out /data/pool_10k --num 10000 --per_patch 8 --workers 16

    # sanity check on a restricted pool (debug only, do not report these)
    python scripts/generate_candidates.py --data_root /data/fpcsd \
        --out /tmp/smoke --num 20 --per_patch 2 --workers 4 \
        --pool_limit 60 --max_sources 5

Runtime
-------
The global sweep dominates. Rough order of magnitude on a desktop CPU: about
2 s per background image per source patch with a single worker, i.e. minutes
per source patch over ~1,500 backgrounds; `--workers` parallelizes only the
background scan. Measure a single patch first
(`--max_sources 1 --per_patch 1 --num 1`) and extrapolate before launching the
full run. `--per_patch` is the main lever: it decides how many source patches
are needed to reach `--num`.

Requirements
------------
opencv-python, numpy. The sibling `src/` directory must be importable.

Notes
-----
* All paths come from --data_root; nothing is hard-coded.
* The seed fixes the numpy/random state; the sweep itself is deterministic.
* The paper's 1514 / 300 / 400 split refers to its own split. This script uses
  whatever is under <data_root>/images/train, so make sure that directory
  holds exactly the training split (no validation or test images) before
  launching.
"""

import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path

SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


# ---------------------------------------------------------------------------
# arguments
# ---------------------------------------------------------------------------
def parse_args():
    ap = argparse.ArgumentParser(
        description="SCCP + Poisson synthetic candidate pool generator")
    ap.add_argument("--data_root", required=True,
                    help="dataset root containing images/train and labels/train")
    ap.add_argument("--out", required=True, help="output directory")
    ap.add_argument("--num", type=int, default=10000,
                    help="target number of candidates (default 10000)")
    ap.add_argument("--per_patch", type=int, default=8,
                    help="max placements kept per source patch (distinct targets)")
    ap.add_argument("--workers", type=int, default=8,
                    help="processes used for the background sweep")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--pool_limit", type=int, default=0,
                    help="scan only the first N backgrounds (debug only)")
    ap.add_argument("--max_sources", type=int, default=0,
                    help="stop after N source patches (debug only)")
    ap.add_argument("--start_source", type=int, default=0,
                    help="resume from this source index")
    ap.add_argument("--crop", choices=["window", "full"], default="window",
                    help="save the placement-window crop (paper protocol) or the full board")
    ap.add_argument("--jpeg_quality", type=int, default=95)
    return ap.parse_args()


# ---------------------------------------------------------------------------
# source enumeration
# ---------------------------------------------------------------------------
def build_source_rows(data_root, max_sources=0):
    """One row per annotated defect instance in the training split."""
    import cv2

    img_dir = os.path.join(data_root, "images", "train")
    lbl_dir = os.path.join(data_root, "labels", "train")
    if not os.path.isdir(img_dir):
        raise SystemExit(f"[ERROR] missing directory: {img_dir}")

    names = sorted(n for n in os.listdir(img_dir)
                   if os.path.splitext(n)[1].lower() in SUFFIXES)
    rows = []
    idx = 0
    for name in names:
        lbl = os.path.join(lbl_dir, os.path.splitext(name)[0] + ".txt")
        if not os.path.isfile(lbl):
            continue
        with open(lbl, "r", encoding="utf-8") as f:
            lines = [ln.strip() for ln in f if ln.strip()]
        W = H = None
        for ln in lines:
            parts = ln.split()
            if len(parts) < 5:
                continue
            if W is None:
                img = cv2.imread(os.path.join(img_dir, name))
                if img is None:
                    break
                H, W = img.shape[:2]
            cx, cy, bw, bh = map(float, parts[1:5])
            x1 = max(0, int(round((cx - bw / 2.0) * W)))
            y1 = max(0, int(round((cy - bh / 2.0) * H)))
            x2 = min(W, int(round((cx + bw / 2.0) * W)))
            y2 = min(H, int(round((cy + bh / 2.0) * H)))
            if x2 - x1 < 4 or y2 - y1 < 4:
                continue
            rows.append({
                "sample_idx": idx,
                "src_image": name,
                "src_bbox_x": x1,
                "src_bbox_y": y1,
                "src_bbox_w": x2 - x1,
                "src_bbox_h": y2 - y1,
                "src_class": int(float(parts[0])),
            })
            idx += 1
            if max_sources and idx >= max_sources:
                return rows
    return rows


# ---------------------------------------------------------------------------
# placement search (paper gate rules implemented here)
# ---------------------------------------------------------------------------
_WORKER = {}
_SRC_DIR = os.environ.get("HYPERFUSE_SRC_DIR", "")


def _init_worker(pack):
    """Worker initializer: re-imports the src modules (modules are not picklable)."""
    import cv2
    src = os.environ.get("HYPERFUSE_SRC_DIR", "") or _SRC_DIR
    if src and src not in sys.path:
        sys.path.insert(0, src)
    import poisson_fusion as _Y
    _WORKER["pack"] = pack
    _WORKER["Y"] = _Y
    try:
        cv2.setNumThreads(1)          # avoid thread oversubscription per process
    except Exception:
        pass


def _worker_target(dst_name):
    return eval_target(_WORKER["pack"], dst_name, _WORKER["Y"])


def eval_target(pack, dst_name, Y):
    """
    Score every legal window of one target background.

    Returns (eligible_window_list, diag_dict). A window is eligible when it
    passes the gates that are *active* for this source patch; the composite
    score is applied later, over the pooled set.
    """
    import numpy as np
    import cv2

    dst_color = cv2.imread(os.path.join(Y.TRAIN_IMG_DIR, dst_name))
    if dst_color is None:
        return [], {"target_image": dst_name, "status": "read_failed", "total": 0}

    dst_gray = cv2.cvtColor(dst_color, cv2.COLOR_BGR2GRAY)
    dst_h, dst_w = dst_gray.shape
    dst_gx, dst_gy, _, _ = Y.precompute_gradient_full(dst_gray)

    dst_bboxes = Y.load_bboxes(
        os.path.join(Y.TRAIN_LBL_DIR, os.path.splitext(dst_name)[0] + ".txt"),
        dst_w, dst_h)
    valid_mask = Y.build_valid_mask(dst_h, dst_w, dst_bboxes, Y.SAFE_MARGIN)
    valid_mask = valid_mask & Y.build_board_white_mask(dst_color)

    win_w, win_h = pack["win_w"], pack["win_h"]
    max_x = dst_w - win_w - Y.SAFE_MARGIN
    max_y = dst_h - win_h - Y.SAFE_MARGIN
    if max_x < Y.SAFE_MARGIN or max_y < Y.SAFE_MARGIN:
        return [], {"target_image": dst_name, "status": "window_too_large", "total": 0}

    feats = pack["feats"]
    mag_means = pack["mag_means"]
    regions = pack["src_regions"]

    trace_enabled = pack["trace_enabled"]
    period_enabled = pack["period_enabled"]
    trace_required = pack["trace_required"]
    min_period_cover = pack["min_period_cover"]
    min_phase_cover = pack["min_phase_cover"]

    eligible = []
    total = trace_pass = period_pass = 0

    for y in range(Y.SAFE_MARGIN, max_y + 1, Y.COARSE_STRIDE):
        for x in range(Y.SAFE_MARGIN, max_x + 1, Y.COARSE_STRIDE):
            if not valid_mask[y:y + win_h, x:x + win_w].all():
                continue
            total += 1

            # ---- gradient-magnitude term + orientation term --------------
            d_sccp = 0.0
            d_trace = 0.0
            trace_hit = 0
            trace_weight_sum = 0.0

            for i in range(8):
                feat = feats[i]
                if not feat["valid"]:
                    continue
                mask = regions[i][0]
                r_gx = dst_gx[y:y + win_h, x:x + win_w][mask]
                r_gy = dst_gy[y:y + win_h, x:x + win_w][mask]
                dst_theta, dst_coh = Y.compute_region_trace_feat(r_gx, r_gy)
                dst_theta_deg = np.degrees(dst_theta) % 180
                dst_mag = np.sqrt(r_gx ** 2 + r_gy ** 2)
                d_sccp += abs(mag_means[i] - float(np.mean(dst_mag)))

                if feat["trace_ok"] and dst_coh >= Y.COH_THRESH:
                    raw = abs(feat["theta_deg"] - dst_theta_deg) % 180.0
                    axial = min(raw, 180.0 - raw)
                    w = min(float(feat["coherence"]), float(dst_coh))
                    d_trace += axial * w
                    trace_weight_sum += w
                    trace_hit += 1

            d_sccp /= 8.0
            if trace_weight_sum > 0:
                d_trace /= trace_weight_sum
            else:
                d_trace = float("nan")

            # ---- orientation hard gate (skipped when <2 reliable regions)
            if trace_enabled:
                if (trace_hit < trace_required
                        or not np.isfinite(d_trace)
                        or d_trace > Y.MAX_TRACE_DIFF_DEG):
                    continue
                trace_pass += 1

            # ---- period / phase terms ------------------------------------
            period_diffs = []
            phase_diffs = []
            for i in range(8):
                feat = feats[i]
                if not feat["valid"] or not feat["period_ok"]:
                    continue
                mask = regions[i][0]
                r_gx = dst_gx[y:y + win_h, x:x + win_w][mask]
                r_gy = dst_gy[y:y + win_h, x:x + win_w][mask]
                dst_theta, _ = Y.compute_region_trace_feat(r_gx, r_gy)
                dst_theta_deg = np.degrees(dst_theta) % 180
                dst_region = dst_gray[y:y + win_h, x:x + win_w].copy()
                _, dst_period, dst_conf, dst_phase, _ = Y.compute_texture_features(
                    dst_region, dst_theta_deg,
                    src_proj_ref=feat["proj_ref"],
                    region_mask=mask,
                    reference_period=feat["period"])
                if dst_conf >= Y.PERIOD_CONF_THRESH and not np.isnan(dst_period):
                    pdiff = abs(feat["period"] - dst_period) / (feat["period"] + 1e-8)
                    period_diffs.append(min(pdiff, 1.0))
                    if not np.isnan(dst_phase):
                        phase_diffs.append(dst_phase)

            if period_enabled:
                if len(period_diffs) < min_period_cover:
                    continue
                d_period = float(np.mean(period_diffs))
                if d_period > Y.MAX_PERIOD_REL_DIFF:
                    continue
                period_pass += 1
            else:
                d_period = float("nan")

            eligible.append({
                "target_image": dst_name, "x": x, "y": y,
                "d_sccp": float(d_sccp),
                "d_trace": float(d_trace),
                "d_period": d_period,
                "d_phase": (float(np.mean(phase_diffs))
                            if len(phase_diffs) >= min_phase_cover else float("nan")),
                "phase_regions": len(phase_diffs),
            })

    return eligible, {"target_image": dst_name, "status": "ok", "total": total,
                      "trace_pass": trace_pass, "period_pass": period_pass}


def score_pool(eligible, pack, Y):
    """5/95-percentile normalization over the pooled eligible windows + score."""
    import numpy as np
    from sccp_search import _robust_norm

    sccp_n, _, _ = _robust_norm([c["d_sccp"] for c in eligible])
    trace_n, _, _ = _robust_norm([c["d_trace"] for c in eligible])
    period_n, _, _ = _robust_norm([c["d_period"] for c in eligible])
    phase_n, _, _ = _robust_norm([c["d_phase"] for c in eligible])

    w_sccp = 1 - Y.LAMBDA_TRACE - Y.LAMBDA_PERIOD - Y.LAMBDA_PHASE
    trace_on = pack["trace_enabled"]
    period_on = pack["period_enabled"]

    for i, c in enumerate(eligible):
        ds = float(sccp_n[i]) if np.isfinite(sccp_n[i]) else 0.5
        dt = float(trace_n[i]) if np.isfinite(trace_n[i]) else 0.5
        dp = float(period_n[i]) if np.isfinite(period_n[i]) else 0.0
        dph = float(phase_n[i]) if np.isfinite(phase_n[i]) else float("nan")

        # a switched-off term contributes nothing; a constant offset would
        # not change the ranking anyway
        t_trace = dt if trace_on else 0.0
        t_period = dp if period_on else 0.0
        # phase remains a soft term, neutral 0.5 when unavailable
        t_phase = dph if np.isfinite(dph) else 0.5

        c["score"] = (w_sccp * ds
                      + Y.LAMBDA_TRACE * t_trace
                      + Y.LAMBDA_PERIOD * t_period
                      + Y.LAMBDA_PHASE * t_phase)
    return eligible


def pick_top_placements(eligible, k):
    """Best placement per distinct target image, then the k best overall."""
    best = {}
    for c in eligible:
        t = c["target_image"]
        if t not in best or c["score"] < best[t]["score"]:
            best[t] = c
    return sorted(best.values(), key=lambda c: c["score"])[:k]


# ---------------------------------------------------------------------------
# fusion + writing
# ---------------------------------------------------------------------------
def fuse_and_save(pack, cand, Y, out_img, out_lbl, crop_mode, jpeg_quality):
    """LAB match -> Poisson + feathering -> crop -> write image + YOLO label."""
    import cv2

    sx, sy, sw, sh = pack["src_bbox"]
    src_patch = pack["src_color"][sy:sy + sh, sx:sx + sw]
    if src_patch.size == 0:
        return None

    dst = cv2.imread(os.path.join(Y.TRAIN_IMG_DIR, cand["target_image"]))
    if dst is None:
        return None

    bbox = (int(cand["x"]), int(cand["y"]), int(sw), int(sh))
    matched = Y.match_patch_lab_to_target(src_patch, dst, bbox)
    fused = Y.poisson_clone_with_feather(matched, dst, bbox)

    if crop_mode == "window":
        img = fused[bbox[1]:bbox[1] + pack["win_h"],
                    bbox[0]:bbox[0] + pack["win_w"]].copy()
        px = sx - pack["ex1s"]
        py = sy - pack["ey1s"]
    else:
        img = fused.copy()
        px, py = sx, sy

    if img.size == 0:
        return None
    H, W = img.shape[:2]

    nw, nh = sw / W, sh / H
    cx, cy = (px + sw / 2.0) / W, (py + sh / 2.0) / H
    if not (0 < nw <= 1 and 0 < nh <= 1 and 0 <= cx <= 1 and 0 <= cy <= 1):
        return None

    cv2.imwrite(str(out_img), img, [cv2.IMWRITE_JPEG_QUALITY, int(jpeg_quality)])
    with open(out_lbl, "w", encoding="utf-8") as f:
        f.write(f"0 {cx:.6f} {cy:.6f} {nw:.6f} {nh:.6f}\n")
    return {"crop_w": W, "crop_h": H}


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main():
    args = parse_args()

    root = Path(args.out)
    (root / "images" / "train").mkdir(parents=True, exist_ok=True)
    (root / "labels" / "train").mkdir(parents=True, exist_ok=True)

    # module-level paths in src/ read these env vars at import time
    os.environ["HYPERFUSE_DATA_ROOT"] = os.path.abspath(args.data_root)
    os.environ.setdefault("HYPERFUSE_OUT", str((root / "_work").resolve()))

    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
    os.environ["HYPERFUSE_SRC_DIR"] = str(Path(__file__).resolve().parents[1] / "src")

    import random
    import numpy as np
    import cv2
    import poisson_fusion as Y
    import sccp_search as S

    random.seed(args.seed)
    np.random.seed(args.seed)
    cv2.setNumThreads(max(1, args.workers))

    rows = build_source_rows(args.data_root, args.max_sources)
    if not rows:
        raise SystemExit("[ERROR] no annotated defect instances found")

    pool = S.list_train_images()
    print(f"[INFO] source patches: {len(rows)}   training backgrounds: {len(pool)}")
    if args.pool_limit:
        pool = pool[:args.pool_limit]
        print(f"[INFO] DEBUG: background pool limited to {len(pool)}")

    cfg = {
        "data_root": os.path.abspath(args.data_root),
        "out": str(root.resolve()),
        "num_target": args.num,
        "per_patch": args.per_patch,
        "workers": args.workers,
        "seed": args.seed,
        "crop": args.crop,
        "pool_limit": args.pool_limit,
        "placement": {
            "lambda_trace": Y.LAMBDA_TRACE,
            "lambda_period": Y.LAMBDA_PERIOD,
            "lambda_phase": Y.LAMBDA_PHASE,
            "safe_margin": Y.SAFE_MARGIN,
            "coarse_stride": Y.COARSE_STRIDE,
            "max_trace_diff_deg": Y.MAX_TRACE_DIFF_DEG,
            "max_period_rel_diff": Y.MAX_PERIOD_REL_DIFF,
            "min_trace_coverage": Y.MIN_TRACE_COVERAGE,
            "candidate_coverage": Y.CANDIDATE_COVERAGE,
            "norm_percentiles": [Y.NORM_LOW_P, Y.NORM_HIGH_P],
            "gate_rule": ("orientation gate active only when >=2 direction-reliable "
                          "regions; period gate active only when >=1 period-reliable "
                          "region; composite score has no extra rejection threshold"),
            "phase_role": "soft score term, neutral 0.5 when unavailable",
        },
    }
    with open(root / "run_config.json", "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

    manifest = root / "manifest.csv"
    produced = 0
    if manifest.exists():
        with open(manifest, "r", encoding="utf-8") as f:
            produced = sum(1 for _ in csv.DictReader(f))
        print(f"[INFO] resume: {produced} samples already in manifest")

    f_man = open(manifest, "a", newline="", encoding="utf-8")
    writer = csv.writer(f_man)
    if manifest.stat().st_size == 0:
        writer.writerow(["sample_id", "source_image", "source_idx",
                         "src_x", "src_y", "src_w", "src_h",
                         "target_image", "dst_x", "dst_y",
                         "score", "trace_gate", "period_gate",
                         "search_sec", "fuse_sec"])

    t_all = time.perf_counter()
    skips = 0
    sources_used = 0

    try:
        for si, row in enumerate(rows):
            if si < args.start_source:
                continue
            if produced >= args.num:
                break
            sources_used += 1

            pack = S.prepare_source(row)
            if pack is None:
                skips += 1
                continue
            if pack.get("invalid"):
                skips += 1
                print(f"[skip] source {row['sample_idx']}: {pack.get('reason')}")
                continue

            bg = [n for n in pool
                  if os.path.normcase(n) != os.path.normcase(row["src_image"])]
            if not bg:
                skips += 1
                continue

            t0 = time.perf_counter()
            eligible = []
            if args.workers > 1:
                from concurrent.futures import ProcessPoolExecutor
                with ProcessPoolExecutor(
                        max_workers=args.workers,
                        initializer=_init_worker,
                        initargs=(pack,)) as ex:
                    for el, _diag in ex.map(_worker_target, bg, chunksize=16):
                        eligible.extend(el)
            else:
                for name in bg:
                    el, _diag = eval_target(pack, name, Y)
                    eligible.extend(el)
            search_s = time.perf_counter() - t0

            if not eligible:
                skips += 1
                print(f"[skip] source {row['sample_idx']}: no eligible window "
                      f"({search_s:.1f}s)")
                continue

            score_pool(eligible, pack, Y)
            picks = pick_top_placements(eligible, args.per_patch)
            n_targets = len({c["target_image"] for c in eligible})

            print(f"[src {row['sample_idx']}] {row['src_image']} "
                  f"eligible={len(eligible)} targets={n_targets} picks={len(picks)} "
                  f"trace_gate={int(pack['trace_enabled'])} "
                  f"period_gate={int(pack['period_enabled'])} ({search_s:.1f}s)")

            for c in picks:
                if produced >= args.num:
                    break
                sid = f"cand_{produced:05d}"
                img_p = root / "images" / "train" / f"{sid}.jpg"
                lbl_p = root / "labels" / "train" / f"{sid}.txt"

                t1 = time.perf_counter()
                info = fuse_and_save(pack, c, Y, img_p, lbl_p,
                                     args.crop, args.jpeg_quality)
                fuse_s = time.perf_counter() - t1
                if info is None:
                    skips += 1
                    continue

                writer.writerow([sid, row["src_image"], row["sample_idx"],
                                 row["src_bbox_x"], row["src_bbox_y"],
                                 row["src_bbox_w"], row["src_bbox_h"],
                                 c["target_image"], c["x"], c["y"],
                                 f"{c['score']:.6f}",
                                 int(pack["trace_enabled"]),
                                 int(pack["period_enabled"]),
                                 f"{search_s:.2f}", f"{fuse_s:.3f}"])
                f_man.flush()
                produced += 1

                if produced % 100 == 0:
                    el = time.perf_counter() - t_all
                    rate = produced / max(el, 1e-6)
                    eta_min = (args.num - produced) / max(rate, 1e-9) / 60.0
                    print(f"[progress] {produced}/{args.num}  "
                          f"{rate:.2f} samples/s  ETA {eta_min:.1f} min")
    finally:
        f_man.close()

    elapsed = time.perf_counter() - t_all
    stats = dict(cfg)
    stats.update({
        "produced": produced,
        "sources_scanned": sources_used,
        "skipped": skips,
        "elapsed_sec": round(elapsed, 1),
        "elapsed_min": round(elapsed / 60.0, 1),
        "samples_per_sec": round(produced / max(elapsed, 1e-9), 3),
        "timing_note": ("wall-clock on the machine that ran the script; the "
                        "global background sweep dominates the cost"),
    })
    with open(root / "generation_stats.json", "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=2)

    print("=" * 64)
    print(f"[DONE] {produced} candidates -> {root}")
    print(f"[DONE] {elapsed/60:.1f} min, skipped: {skips}")
    print(f"[DONE] manifest: {manifest}")


if __name__ == "__main__":
    main()
