# -*- coding: utf-8 -*-
"""
统一的 YOLO 训练脚本：baseline / ours / wgan / cutpaste / diffusion 五组通用，
也用于 PKU-Market-PCB 泛化实验。超参默认按论文 4.2：epochs=100, batch=8,
lr=0.01, SGD, imgsz=640。
用法（每组只需换 --train 和 --name）:
    python train_yolo.py --train ./dataset_baseline/images/train \
        --val ./dataset_baseline/images/val --model yolo11s.pt \
        --name baseline
训练配置 yaml 会自动生成在 runs 下，方便复现时查看。
"""
import os
import argparse
import yaml

from ultralytics import YOLO


def make_data_yaml(train_dirs, val_dir, out_dir):
    """train_dirs 可以传多个目录（如 真实集+扩增集），自动合成 yaml"""
    data = {
        "path": os.path.abspath(out_dir),
        "train": [os.path.abspath(d) for d in train_dirs],
        "val": os.path.abspath(val_dir),
        "nc": 1,
        "names": {0: "defect"},
    }
    yaml_path = os.path.join(out_dir, "data.yaml")
    with open(yaml_path, "w") as f:
        yaml.dump(data, f, allow_unicode=True)
    return yaml_path


def main():
    parser = argparse.ArgumentParser(description="YOLO 训练（五组通用）")
    parser.add_argument("--train", required=True, help="训练图像目录，多个用逗号分隔")
    parser.add_argument("--val", required=True, help="验证图像目录")
    parser.add_argument("--model", default="yolo11s.pt", help="yolo11s.pt 或 yolov8s.pt")
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch", type=int, default=8)
    parser.add_argument("--lr", type=float, default=0.01)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--optimizer", default="SGD")
    parser.add_argument("--name", default="exp", help="实验名，也是 runs 下的目录名")
    parser.add_argument("--device", default="0")
    parser.add_argument("--project", default="runs/detect")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    train_dirs = [d.strip() for d in args.train.split(",") if d.strip()]
    os.makedirs(args.project, exist_ok=True)
    data_yaml = make_data_yaml(train_dirs, args.val, args.project)

    model = YOLO(args.model)
    model.train(
        data=data_yaml,
        epochs=args.epochs,
        batch=args.batch,
        imgsz=args.imgsz,
        lr0=args.lr,
        optimizer=args.optimizer,
        weight_decay=0.0005,
        project=args.project,
        name=args.name,
        device=args.device,
        seed=args.seed,
        exist_ok=True,
        val=True,
    )
    print(f"训练完成，结果在 {os.path.join(args.project, args.name)}")


if __name__ == "__main__":
    main()
