# -*- coding: utf-8 -*-
"""
测试集检测指标评估脚本（对应论文 Table 7/8/9/10 的测试集结果）：
加载训练好的 best.pt，在 test 目录上跑一次 val，输出
mAP@0.5 / mAP@0.5:0.95 / precision / recall。
用法:
    python eval_detection.py --weights runs/detect/ours/best.pt \
        --img_dir .../dataset_baseline/images/test \
        --lbl_dir .../dataset_baseline/labels/test \
        --name eval_ours --imgsz 640
"""
import os
import argparse
import yaml

from ultralytics import YOLO


def make_test_yaml(img_dir, lbl_dir, out_dir):
    data = {
        "path": os.path.abspath(out_dir),
        "test": os.path.abspath(img_dir),
        "nc": 1,
        "names": {0: "defect"},
    }
    yaml_path = os.path.join(out_dir, "test_data.yaml")
    with open(yaml_path, "w") as f:
        yaml.dump(data, f, allow_unicode=True)
    return yaml_path


def main():
    parser = argparse.ArgumentParser(description="测试集检测指标评估")
    parser.add_argument("--weights", required=True, help="best.pt 路径")
    parser.add_argument("--img_dir", required=True, help="test 图像目录")
    parser.add_argument("--lbl_dir", required=True, help="test 标签目录")
    parser.add_argument("--name", default="eval_test")
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--device", default="0")
    parser.add_argument("--project", default="runs/eval")
    parser.add_argument("--conf", type=float, default=0.001, help="检测置信度阈值")
    parser.add_argument("--iou", type=float, default=0.6, help="NMS IoU 阈值")
    args = parser.parse_args()

    if not os.path.exists(args.lbl_dir):
        raise SystemExit(f"标签目录不存在: {args.lbl_dir}")

    os.makedirs(args.project, exist_ok=True)
    data_yaml = make_test_yaml(args.img_dir, args.lbl_dir, args.project)

    model = YOLO(args.weights)
    results = model.val(
        data=data_yaml,
        split="test",
        imgsz=args.imgsz,
        device=args.device,
        project=args.project,
        name=args.name,
        conf=args.conf,
        iou=args.iou,
        exist_ok=True,
    )

    box = results.box
    print("\n" + "=" * 50)
    print(f"测试集评估: {args.weights}")
    print(f"mAP@0.5    : {box.map50:.4f}")
    print(f"mAP@0.5:0.95: {box.map:.4f}")
    print(f"Precision  : {box.mp:.4f}")
    print(f"Recall     : {box.mr:.4f}")
    print("=" * 50)

    report = os.path.join(args.project, args.name, "test_metrics.txt")
    with open(report, "w") as f:
        f.write(f"mAP50: {box.map50:.4f}\n")
        f.write(f"mAP50-95: {box.map:.4f}\n")
        f.write(f"precision: {box.mp:.4f}\n")
        f.write(f"recall: {box.mr:.4f}\n")
    print(f"指标已保存: {report}")


if __name__ == "__main__":
    main()
