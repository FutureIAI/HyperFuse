# -*- coding: utf-8 -*-
"""
PKU-Market-PCB 预处理脚本（对应论文 4.1 的跨数据集实验说明）：
- 图像统一 resize 到 768x768
- 6 类缺陷（missing_hole/mouse_bite/open_circuit/short/burr/spurious_copper）合并为单类
- VOC XML 标注转 YOLO-txt
- 保留官方 train/test 划分
- 校验旋转增强样本不跨 train/test（同一块基板的旋转版本不会同时出现在两个集合）
用法:
    python pku_prepare.py --src /path/to/PKU-Market-PCB --out ./pku_yolo
PKU-Market-PCB 原始目录结构:
    images/  Annotations/  train.txt  test.txt
"""
import os
import re
import shutil
import argparse
import xml.etree.ElementTree as ET

import cv2


def parse_xml(xml_path):
    """解析 VOC XML，返回 [(cls, xmin, ymin, xmax, ymax), ...]"""
    tree = ET.parse(xml_path)
    root = tree.getroot()
    objs = []
    for obj in root.findall("object"):
        cls = obj.find("name").text
        bnd = obj.find("bndbox")
        xmin = float(bnd.find("xmin").text)
        ymin = float(bnd.find("ymin").text)
        xmax = float(bnd.find("xmax").text)
        ymax = float(bnd.find("ymax").text)
        objs.append((cls, xmin, ymin, xmax, ymax))
    return objs


def base_name(filename):
    """去掉旋转后缀取基板名：xxx_rotate_90.jpg -> xxx"""
    stem = os.path.splitext(filename)[0]
    stem = re.sub(r"_rotate_\d+$", "", stem)
    return stem


def check_split_boundary(train_names, test_names):
    """校验旋转增强样本不跨界"""
    train_bases = {base_name(n) for n in train_names}
    test_bases = {base_name(n) for n in test_names}
    overlap = train_bases & test_bases
    if overlap:
        print(f"警告: {len(overlap)} 块基板同时出现在 train 和 test:")
        for b in sorted(overlap)[:10]:
            print("  ", b)
        raise SystemExit("划分边界校验失败，请检查官方划分文件")
    print(f"校验通过: train {len(train_bases)} 块基板 / test {len(test_bases)} 块基板，无跨界")


def convert_one(src_img, src_xml, dst_img, dst_lbl, size=768):
    img = cv2.imread(src_img)
    if img is None:
        return 0
    img = cv2.resize(img, (size, size))
    cv2.imwrite(dst_img, img)

    objs = parse_xml(src_xml)
    lines = []
    for _, xmin, ymin, xmax, ymax in objs:
        cx = (xmin + xmax) / 2 / size
        cy = (ymin + ymax) / 2 / size
        w = (xmax - xmin) / size
        h = (ymax - ymin) / size
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        w = min(max(w, 0.0), 1.0)
        h = min(max(h, 0.0), 1.0)
        # 6 类统一合并为缺陷单类 0
        lines.append(f"0 {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}")
    with open(dst_lbl, "w") as f:
        if lines:
            f.write("\n".join(lines) + "\n")
    return len(objs)


def main():
    parser = argparse.ArgumentParser(description="PKU-Market-PCB 预处理")
    parser.add_argument("--src", required=True, help="PKU 原始数据根目录")
    parser.add_argument("--out", required=True, help="输出目录")
    parser.add_argument("--size", type=int, default=768, help="论文统一 768x768")
    args = parser.parse_args()

    img_dir = os.path.join(args.src, "images")
    xml_dir = os.path.join(args.src, "Annotations")
    train_txt = os.path.join(args.src, "train.txt")
    test_txt = os.path.join(args.src, "test.txt")
    for p in (img_dir, xml_dir, train_txt, test_txt):
        if not os.path.exists(p):
            raise SystemExit(f"缺少文件/目录: {p}")

    with open(train_txt) as f:
        train_names = [x.strip() for x in f if x.strip()]
    with open(test_txt) as f:
        test_names = [x.strip() for x in f if x.strip()]
    check_split_boundary(train_names, test_names)

    for split, names in (("train", train_names), ("test", test_names)):
        out_img = os.path.join(args.out, "images", split)
        out_lbl = os.path.join(args.out, "labels", split)
        os.makedirs(out_img, exist_ok=True)
        os.makedirs(out_lbl, exist_ok=True)

        total_boxes = 0
        for name in names:
            stem = os.path.splitext(name)[0]
            src_img = os.path.join(img_dir, name)
            src_xml = os.path.join(xml_dir, stem + ".xml")
            if not os.path.exists(src_xml):
                print(f"跳过无标注图像: {name}")
                continue
            n = convert_one(src_img, src_xml,
                            os.path.join(out_img, name),
                            os.path.join(out_lbl, stem + ".txt"),
                            args.size)
            total_boxes += n
        print(f"{split}: {len(names)} 张, 缺陷框 {total_boxes} 个")

    print(f"PKU 预处理完成 -> {args.out}")


if __name__ == "__main__":
    main()
