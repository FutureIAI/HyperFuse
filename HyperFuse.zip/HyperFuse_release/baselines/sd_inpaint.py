# -*- coding: utf-8 -*-
"""
扩散模型生成扩增集（论文 4.5 DDPM 组，实现为 SD-Inpaint + IP-Adapter）：
用 Stable Diffusion Inpainting + IP-Adapter 在真实 PCB 图的局部区域重绘出缺陷，
生成 5k 数据集。参数与 testdiff.py 基准脚本保持一致。
用法:
    python diffusion_generate_dataset.py --real_img ... --real_lbl ... \
        --out ... --num 5000
首次运行会自动从 HuggingFace 下载模型，网络不通时先设 HF_ENDPOINT=https://hf-mirror.com
"""
import os
import argparse
import random

import cv2
import numpy as np
import torch
from PIL import Image
from tqdm import tqdm

os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")


def read_defect_bbox(lbl_path, W, H):
    """读第一个框，返回 (x1,y1,x2,y2)，用于随机选 ROI 时避开原缺陷"""
    if not os.path.exists(lbl_path):
        return None
    with open(lbl_path, "r") as f:
        line = f.readline().strip()
    if not line:
        return None
    _, cx, cy, bw, bh = map(float, line.split())
    x1 = int((cx - bw / 2) * W)
    y1 = int((cy - bh / 2) * H)
    x2 = int((cx + bw / 2) * W)
    y2 = int((cy + bh / 2) * H)
    return (max(0, x1), max(0, y1), min(W, x2), min(H, y2))


def build_mask(roi, defect_size):
    """在 ROI 内随机放一个缺陷矩形，返回 (掩码, 缺陷框在原图坐标)"""
    rx1, ry1, rx2, ry2 = roi
    rw = rx2 - rx1
    rh = ry2 - ry1
    dw = random.randint(defect_size[0], defect_size[1])
    dh = random.randint(defect_size[0], defect_size[1])
    ox = random.randint(0, max(rw - dw, 0))
    oy = random.randint(0, max(rh - dh, 0))
    dx1, dy1 = rx1 + ox, ry1 + oy
    dx2, dy2 = dx1 + dw, dy1 + dh
    mask = np.zeros((rh, rw), dtype=np.uint8)
    mask[oy:oy + dh, ox:ox + dw] = 255
    return mask, (dx1, dy1, dx2, dy2)


def main():
    parser = argparse.ArgumentParser(description="SD-Inpaint+IP-Adapter 生成扩增集")
    parser.add_argument("--real_img", required=True, help="真实图像目录")
    parser.add_argument("--real_lbl", required=True, help="真实标签目录")
    parser.add_argument("--out", required=True)
    parser.add_argument("--num", type=int, default=5000)
    parser.add_argument("--roi_size", type=int, default=128, help="ROI 尺寸，对应 TARGET_ROI")
    parser.add_argument("--defect_min", type=int, default=64)
    parser.add_argument("--defect_max", type=int, default=96)
    parser.add_argument("--final_size", type=int, default=512, help="inpaint 输入尺寸，对应 FINAL_SIZE")
    parser.add_argument("--edge_pad", type=int, default=20, help="ROI 外扩像素，对应 EDGE_PAD")
    parser.add_argument("--steps", type=int, default=50)
    parser.add_argument("--cfg", type=float, default=13.0)
    parser.add_argument("--ip_scale", type=float, default=1.7)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--sd_model", default="runwayml/stable-diffusion-inpainting")
    parser.add_argument("--ip_model", default="h94/IP-Adapter")
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    from diffusers import AutoPipelineForInpainting
    from diffusers.utils import load_image

    prompt = ("Micro industrial PCB photography, severe circuit defect, "
              "broken trace on green substrate, realistic, high detail")
    negative = "lowres, watermark, text, blurry, oversaturated"

    pipe = AutoPipelineForInpainting.from_pretrained(
        args.sd_model, torch_dtype=torch.float16, safety_checker=None
    ).to(device)
    pipe.load_ip_adapter(
        args.ip_model,
        subfolder="models",
        weight_name="ip-adapter_sd15.safetensors",
        image_encoder_folder="models/image_encoder",
    )
    pipe.set_ip_adapter_scale(args.ip_scale)
    pipe.set_progress_bar_config(disable=True)
    print("模型加载完成")

    out_img = os.path.join(args.out, "images", "train")
    out_lbl = os.path.join(args.out, "labels", "train")
    os.makedirs(out_img, exist_ok=True)
    os.makedirs(out_lbl, exist_ok=True)

    images = [f for f in os.listdir(args.real_img) if f.lower().endswith((".jpg", ".png"))]
    print(f"真实图像: {len(images)} 张")

    gen = 0
    pbar = tqdm(total=args.num, desc="扩散生成中")
    while gen < args.num:
        try:
            name = random.choice(images)
            img_path = os.path.join(args.real_img, name)
            lbl_path = os.path.join(args.real_lbl, os.path.splitext(name)[0] + ".txt")
            pil = Image.open(img_path).convert("RGB")
            W, H = pil.size

            # 随机 ROI，尽量避开原缺陷
            orig_bbox = read_defect_bbox(lbl_path, W, H)
            for _ in range(50):
                rx = random.randint(0, max(W - args.roi_size, 0))
                ry = random.randint(0, max(H - args.roi_size, 0))
                roi = (rx, ry, rx + args.roi_size, ry + args.roi_size)
                if orig_bbox is None:
                    break
                # ROI 与原缺陷交集过小就算避开
                ix1, iy1 = max(roi[0], orig_bbox[0]), max(roi[1], orig_bbox[1])
                ix2, iy2 = min(roi[2], orig_bbox[2]), min(roi[3], orig_bbox[3])
                if not (ix1 < ix2 and iy1 < iy2):
                    break

            mask, defect_box = build_mask(roi, (args.defect_min, args.defect_max))

            # ROI 外扩 EDGE_PAD 再缩放到 final_size 做 inpaint
            pad = args.edge_pad
            cx1 = max(0, roi[0] - pad)
            cy1 = max(0, roi[1] - pad)
            cx2 = min(W, roi[2] + pad)
            cy2 = min(H, roi[3] + pad)
            crop = pil.crop((cx1, cy1, cx2, cy2))
            mask_pil = Image.fromarray(mask).resize(
                (args.final_size, args.final_size), Image.NEAREST
            )
            crop_resized = crop.resize((args.final_size, args.final_size))

            result = pipe(
                prompt=prompt,
                negative_prompt=negative,
                image=crop_resized,
                mask_image=mask_pil,
                num_inference_steps=args.steps,
                guidance_scale=args.cfg,
                generator=torch.Generator(device="cpu").manual_seed(args.seed + gen),
            ).images[0]

            # 结果缩放回 ROI 区域贴回原图
            result_roi = result.resize((roi[2] - roi[0], roi[3] - roi[1]))
            out_pil = pil.copy()
            out_pil.paste(result_roi, (roi[0], roi[1]))

            # 标签：缺陷框在原图上的归一化坐标
            dx1, dy1, dx2, dy2 = defect_box
            cx = (dx1 + dx2) / 2 / W
            cy = (dy1 + dy2) / 2 / H
            bw = (dx2 - dx1) / W
            bh = (dy2 - dy1) / H
            label_str = f"0 {cx:.6f} {cy:.6f} {bw:.6f} {bh:.6f}\n"

            save_name = f"diff_{gen:05d}.jpg"
            out_pil.save(os.path.join(out_img, save_name), quality=95)
            with open(os.path.join(out_lbl, os.path.splitext(save_name)[0] + ".txt"), "w") as f:
                f.write(label_str)
            gen += 1
            pbar.update(1)
        except Exception as e:
            print(f"跳过一张: {e}")
            continue
    pbar.close()
    print(f"完成，共 {gen} 张 -> {args.out}")


if __name__ == "__main__":
    main()
