# -*- coding: utf-8 -*-
"""
WGAN-GP 训练脚本：从零训练一个生成缺陷 patch（128x128）的生成器。
对应论文 4.5 节 WGAN-GP 对比方法的训练阶段。
用法:
    python wgan_gp_train.py --data /path/to/defect_patches --epochs 300 \
        --out /path/to/gan_weight
训练数据是真实缺陷的 crop，统一 resize 成 128x128。
"""
import os
import argparse

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
from PIL import Image
from tqdm import tqdm


# ---------------- 网络结构 ----------------
class Generator(nn.Module):
    """z(128) -> 3x128x128, 输出 tanh 归一化到 [-1,1]"""
    def __init__(self, z_dim=128):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(z_dim, 128 * 16 * 16),
            nn.BatchNorm1d(128 * 16 * 16),
            nn.ReLU(inplace=True),
        )
        self.deconv = nn.Sequential(
            nn.ConvTranspose2d(128, 128, 4, 2, 1, bias=False),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(128, 64, 4, 2, 1, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(64, 3, 4, 2, 1, bias=False),
            nn.Tanh(),
        )

    def forward(self, z):
        x = self.fc(z).view(z.size(0), 128, 16, 16)
        return self.deconv(x)


class Discriminator(nn.Module):
    """DCGAN 风格 4 层下采样，输出单值 critic"""
    def __init__(self):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3, 64, 4, 2, 1, bias=False),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(64, 128, 4, 2, 1, bias=False),
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(128, 256, 4, 2, 1, bias=False),
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(256, 512, 4, 2, 1, bias=False),
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.2, inplace=True),
        )
        self.out = nn.Conv2d(512, 1, 4, 1, 0, bias=False)

    def forward(self, x):
        return self.out(self.conv(x)).view(x.size(0), -1)


class PatchDataset(Dataset):
    def __init__(self, img_dir, size=128):
        self.names = [f for f in os.listdir(img_dir) if f.lower().endswith((".jpg", ".png"))]
        self.dir = img_dir
        self.tf = transforms.Compose([
            transforms.Resize((size, size)),
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5]),
        ])

    def __len__(self):
        return len(self.names)

    def __getitem__(self, idx):
        img = Image.open(os.path.join(self.dir, self.names[idx])).convert("RGB")
        return self.tf(img)


# ---------------- WGAN-GP 训练 ----------------
def compute_gp(critic, real, fake):
    """梯度惩罚，系数 10"""
    batch = real.size(0)
    eps = torch.rand(batch, 1, 1, 1, device=real.device)
    interp = (eps * real + (1 - eps) * fake).requires_grad_(True)
    d_interp = critic(interp)
    grads = torch.autograd.grad(
        outputs=d_interp, inputs=interp,
        grad_outputs=torch.ones_like(d_interp),
        create_graph=True, retain_graph=True,
    )[0]
    grads = grads.view(batch, -1)
    gp = ((grads.norm(2, dim=1) - 1) ** 2).mean()
    return gp


def main():
    parser = argparse.ArgumentParser(description="WGAN-GP 训练")
    parser.add_argument("--data", required=True, help="缺陷 patch 目录")
    parser.add_argument("--out", default="gan_weight", help="权重输出目录")
    parser.add_argument("--epochs", type=int, default=300)
    parser.add_argument("--batch", type=int, default=32)
    parser.add_argument("--lr", type=float, default=0.0001, help="论文报告 lr=0.0001")
    parser.add_argument("--n_critic", type=int, default=5)
    parser.add_argument("--gp", type=float, default=10.0)
    parser.add_argument("--z_dim", type=int, default=128)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    os.makedirs(args.out, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"设备: {device}")

    dataset = PatchDataset(args.data)
    loader = DataLoader(dataset, batch_size=args.batch, shuffle=True, num_workers=4,
                        pin_memory=True, drop_last=True)
    print(f"训练样本数: {len(dataset)}")

    G = Generator(args.z_dim).to(device)
    D = Discriminator().to(device)
    opt_g = optim.Adam(G.parameters(), lr=args.lr, betas=(0.5, 0.9))
    opt_d = optim.Adam(D.parameters(), lr=args.lr, betas=(0.5, 0.9))

    best_loss = float("inf")
    for epoch in range(1, args.epochs + 1):
        d_loss_sum, g_loss_sum, n_batch = 0.0, 0.0, 0
        pbar = tqdm(loader, desc=f"Epoch {epoch}/{args.epochs}", leave=False)
        for real in pbar:
            real = real.to(device)
            batch = real.size(0)

            # 训练判别器
            for _ in range(args.n_critic):
                z = torch.randn(batch, args.z_dim, device=device)
                fake = G(z).detach()
                d_real = D(real)
                d_fake = D(fake)
                gp = compute_gp(D, real, fake)
                d_loss = d_fake.mean() - d_real.mean() + args.gp * gp
                opt_d.zero_grad()
                d_loss.backward()
                opt_d.step()

            # 训练生成器
            z = torch.randn(batch, args.z_dim, device=device)
            fake = G(z)
            g_loss = -D(fake).mean()
            opt_g.zero_grad()
            g_loss.backward()
            opt_g.step()

            d_loss_sum += d_loss.item()
            g_loss_sum += g_loss.item()
            n_batch += 1
            pbar.set_postfix(d_loss=d_loss.item(), g_loss=g_loss.item())

        avg_d = d_loss_sum / n_batch
        avg_g = g_loss_sum / n_batch
        print(f"Epoch {epoch}: D_loss {avg_d:.4f}, G_loss {avg_g:.4f}")

        if avg_d < best_loss:
            best_loss = avg_d
            torch.save(G.state_dict(), os.path.join(args.out, "generator_best.pth"))
            print(f"  保存 best generator (D_loss {avg_d:.4f})")

    print(f"训练完成，权重在 {args.out}")


if __name__ == "__main__":
    main()
