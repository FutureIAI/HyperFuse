# -*- coding: utf-8 -*-
"""
WGAN-GP 生成扩增集：加载训练好的生成器，产出缺陷 patch（128x128），
然后用 NCC 检索背景 + 泊松融合把 patch 贴到真实 PCB 背景上，
凑成对比组的 5k 数据集（论文 4.5 WGAN-GP 组）。
用法:
    python wgan_gp_generate.py --weight /path/to/generator_best.pth \
        --pool_img ... --pool_lbl ... --out ... --num 5000
"""
import os
import argparse
import random

import cv2
import numpy as np
import torch
from PIL import Image
from tqdm import tqdm


def get_white_ratio(patch, threshold=200):
    gray = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY)
    return np.sum(gray > threshold) / gray.size


def get_pure_bg_candidates(img, txt_path, margin=15):
    """按标签框外扩 margin，把图切成上下左右四个纯背景候选"""
    if not os.path.exists(txt_path):
        return []
    with open(txt_path, "r") as f:
        line = f.readline().strip()
    if not line:
        return []
    _, cx, cy, bw, bh = map(float, line.split())
    h, w = img.shape[:2]
    x1 = int((cx - bw / 2) * w)
    y1 = int((cy - bh / 2) * h)
    x2 = int((cx + bw / 2) * w)
    y2 = int((cy + bh / 2) * h)
    sx1 = max(0, x1 - margin)
    sy1 = max(0, y1 - margin)
    sx2 = min(w, x2 + margin)
    sy2 = min(h, y2 + margin)
    cands = [
        {"box": img[0:h, 0:sx1], "area": h * sx1},
        {"box": img[0:h, sx2:w], "area": h * (w - sx2)},
        {"box": img[0:sy1, 0:w], "area": sy1 * w},
        {"box": img[sy2:h, 0:w], "area": (h - sy2) * w},
    ]
    return [c for c in cands if c["area"] > 0 and c["box"].size > 0]


def paste_wgan_patch(img, patch, txt_path, white_thresh=0.01, margin=15):
    """
    NCC 找最佳嵌入位置 + 泊松融合。
    返回 (贴好的子图, 子图宽, 子图高, patch 中心, patch 宽, patch 高) 或 None
    输出图是纯背景子图，标签按子图尺寸归一化（与 10k.py 一致）
    """
    cands = get_pure_bg_candidates(img, txt_path, margin)
    ph, pw = patch.shape[:2]
    valid = [c for c in cands if c["box"].shape[0] > ph and c["box"].shape[1] > pw]
    if not valid:
        return None
    pure_bg = max(valid, key=lambda x: x["area"])["box"]
    bg_h, bg_w = pure_bg.shape[:2]

    gray_defect = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY)
    gray_bg = cv2.cvtColor(pure_bg, cv2.COLOR_BGR2GRAY)
    if gray_bg.shape[0] <= gray_defect.shape[0] or gray_bg.shape[1] <= gray_defect.shape[1]:
        return None

    ncc = cv2.matchTemplate(gray_defect, gray_bg, cv2.TM_CCOEFF_NORMED)
    _, _, _, max_loc = cv2.minMaxLoc(ncc)
    best_center = (max_loc[0] + pw // 2, max_loc[1] + ph // 2)

    target = pure_bg[max_loc[1]:max_loc[1] + ph, max_loc[0]:max_loc[0] + pw]
    if get_white_ratio(target) > white_thresh:
        return None

    mask = 255 * np.ones(patch.shape, patch.dtype)
    mixed = cv2.seamlessClone(patch, pure_bg, mask, best_center, cv2.NORMAL_CLONE)
    return mixed, bg_w, bg_h, best_center, pw, ph


def main():
    parser = argparse.ArgumentParser(description="WGAN-GP 生成扩增集")
    parser.add_argument("--weight", required=True, help="generator_best.pth 路径")
    parser.add_argument("--pool_img", required=True, help="背景池图像目录（候选池或真实集）")
    parser.add_argument("--pool_lbl", required=True, help="背景池标签目录")
    parser.add_argument("--out", required=True, help="输出根目录 (images/train + labels/train)")
    parser.add_argument("--num", type=int, default=5000)
    parser.add_argument("--z_dim", type=int, default=128)
    parser.add_argument("--patch_size", type=int, default=128)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 生成器结构与训练脚本保持一致
    from wgan_gp_train import Generator
    G = Generator(args.z_dim).to(device).eval()
    G.load_state_dict(torch.load(args.weight, map_location=device))
    print("生成器加载完成")

    out_img = os.path.join(args.out, "images", "train")
    out_lbl = os.path.join(args.out, "labels", "train")
    os.makedirs(out_img, exist_ok=True)
    os.makedirs(out_lbl, exist_ok=True)

    pool_images = [f for f in os.listdir(args.pool_img) if f.lower().endswith((".jpg", ".png"))]
    print(f"背景池: {len(pool_images)} 张")

    gen = 0
    pbar = tqdm(total=args.num, desc="WGAN-GP 生成中")
    while gen < args.num:
        try:
            with torch.no_grad():
                z = torch.randn(1, args.z_dim, device=device)
                fake = G(z).cpu()[0]
            # tanh [-1,1] -> [0,255] BGR
            patch = ((fake.permute(1, 2, 0).numpy() * 0.5 + 0.5) * 255).astype(np.uint8)
            patch = cv2.cvtColor(patch, cv2.COLOR_RGB2BGR)

            bg_name = random.choice(pool_images)
            img = cv2.imread(os.path.join(args.pool_img, bg_name))
            if img is None:
                continue
            txt = os.path.join(args.pool_lbl, os.path.splitext(bg_name)[0] + ".txt")
            ret = paste_wgan_patch(img, patch, txt)
            if ret is None:
                continue
            mixed, bg_w, bg_h, center, pw, ph = ret

            cx_norm = center[0] / bg_w
            cy_norm = center[1] / bg_h
            w_norm = pw / bg_w
            h_norm = ph / bg_h
            label_str = f"0 {cx_norm:.6f} {cy_norm:.6f} {w_norm:.6f} {h_norm:.6f}\n"

            name = f"wgan_{gen:05d}.jpg"
            cv2.imwrite(os.path.join(out_img, name), mixed)
            with open(os.path.join(out_lbl, os.path.splitext(name)[0] + ".txt"), "w") as f:
                f.write(label_str)
            gen += 1
            pbar.update(1)
        except Exception:
            continue
    pbar.close()
    print(f"完成，共 {gen} 张 -> {args.out}")


if __name__ == "__main__":
    main()
