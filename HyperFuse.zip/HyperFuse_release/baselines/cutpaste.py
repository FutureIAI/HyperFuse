# -*- coding: utf-8 -*-
"""
Cut-Paste 对比组生成脚本（论文 4.5 Cut-Paste 组）：
直接抠真实缺陷 patch，随机扔到真实背景上，不做 NCC 检索、不做泊松融合、
不做庞加莱筛选。这也是论文 Table 4 里 all-modules-disabled 的配置。
用法:
    python cutpaste_augment.py --real_img ... --real_lbl ... \
        --pool_img ... --pool_lbl ... --out ... --num 5000
"""
import os
import argparse
import random

import cv2
import numpy as np
from tqdm import tqdm


def load_defect_crop(img_dir, lbl_dir, name, resize_to=128):
    """读图 + 第一个标签框，返回缺陷 crop（默认 resize 到 128）"""
    img = cv2.imread(os.path.join(img_dir, name))
    if img is None:
        return None, None
    txt = os.path.join(lbl_dir, os.path.splitext(name)[0] + ".txt")
    if not os.path.exists(txt):
        return None, None
    with open(txt, "r") as f:
        line = f.readline().strip()
    if not line:
        return None, None
    _, cx, cy, bw, bh = map(float, line.split())
    h, w = img.shape[:2]
    x1 = max(0, int((cx - bw / 2) * w))
    y1 = max(0, int((cy - bh / 2) * h))
    x2 = min(w, int((cx + bw / 2) * w))
    y2 = min(h, int((cy + bh / 2) * h))
    if x2 <= x1 or y2 <= y1:
        return None, None
    crop = img[y1:y2, x1:x2]
    if resize_to is not None:
        crop = cv2.resize(crop, (resize_to, resize_to))
    return crop, resize_to


def random_paste(img, patch):
    """随机位置直接粘贴，返回 (贴好的图, 中心, 图宽, 图高) 或 None"""
    ih, iw = img.shape[:2]
    ph, pw = patch.shape[:2]
    if ih <= ph or iw <= pw:
        return None
    x = random.randint(0, iw - pw)
    y = random.randint(0, ih - ph)
    canvas = img.copy()
    canvas[y:y + ph, x:x + pw] = patch
    return canvas, (x + pw // 2, y + ph // 2), iw, ih, pw, ph


def main():
    parser = argparse.ArgumentParser(description="Cut-Paste 生成扩增集")
    parser.add_argument("--real_img", required=True, help="真实缺陷图像目录（抠缺陷用）")
    parser.add_argument("--real_lbl", required=True)
    parser.add_argument("--pool_img", required=True, help="背景图像目录")
    parser.add_argument("--pool_lbl", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--num", type=int, default=5000)
    parser.add_argument("--patch_size", type=int, default=128)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)

    real_images = [f for f in os.listdir(args.real_img) if f.lower().endswith((".jpg", ".png"))]
    pool_images = [f for f in os.listdir(args.pool_img) if f.lower().endswith((".jpg", ".png"))]
    print(f"真实缺陷源: {len(real_images)} 张, 背景池: {len(pool_images)} 张")

    out_img = os.path.join(args.out, "images", "train")
    out_lbl = os.path.join(args.out, "labels", "train")
    os.makedirs(out_img, exist_ok=True)
    os.makedirs(out_lbl, exist_ok=True)

    gen = 0
    pbar = tqdm(total=args.num, desc="Cut-Paste 生成中")
    while gen < args.num:
        def_name = random.choice(real_images)
        crop, size = load_defect_crop(args.real_img, args.real_lbl, def_name, args.patch_size)
        if crop is None:
            continue
        bg_name = random.choice(pool_images)
        img = cv2.imread(os.path.join(args.pool_img, bg_name))
        if img is None:
            continue
        ret = random_paste(img, crop)
        if ret is None:
            continue
        canvas, center, iw, ih, pw, ph = ret

        cx_norm = center[0] / iw
        cy_norm = center[1] / ih
        w_norm = pw / iw
        h_norm = ph / ih
        label_str = f"0 {cx_norm:.6f} {cy_norm:.6f} {w_norm:.6f} {h_norm:.6f}\n"

        name = f"cutpaste_{gen:05d}.jpg"
        cv2.imwrite(os.path.join(out_img, name), canvas)
        with open(os.path.join(out_lbl, os.path.splitext(name)[0] + ".txt"), "w") as f:
            f.write(label_str)
        gen += 1
        pbar.update(1)
    pbar.close()
    print(f"完成，共 {gen} 张 -> {args.out}")


if __name__ == "__main__":
    main()
