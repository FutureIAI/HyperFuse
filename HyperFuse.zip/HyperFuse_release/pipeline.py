#!/usr/bin/env python3
"""
HyperFuse end-to-end augmentation pipeline.

Step 1: SCCP global placement search  -> candidate pool (10k candidates)
Step 2: Poisson blending              -> write synthesized samples
Step 3: Poincare-space screening      -> keep top-K (default 5000) by 95% quantile

Usage:
    python pipeline.py \
        --data_root ./data/fpcsd \
        --out_dir ./outputs/full_run \
        --candidates 10000 \
        --top_k 5000 \
        --quantile 0.95 \
        --seed 42
"""
import argparse
import os
import sys
from pathlib import Path

# Make src/ importable
sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_root", required=True, help="dataset root (YOLO layout)")
    ap.add_argument("--out_dir", default="./outputs/full_run")
    ap.add_argument("--candidates", type=int, default=10000)
    ap.add_argument("--top_k", type=int, default=5000)
    ap.add_argument("--quantile", type=float, default=0.95)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()

    os.environ["HYPERFUSE_DATA_ROOT"] = args.data_root
    os.environ["HYPERFUSE_OUT"] = args.out_dir

    Path(args.out_dir).mkdir(parents=True, exist_ok=True)

    # Step 1+2 are invoked through poisson_fusion / sccp_search module entry points.
    # For a fresh run, call:
    #   python src/sccp_search.py
    # after configuring env vars.
    #
    # Step 3: Poincare screening
    import poincare_filter as pf
    print("[HyperFuse] Step 3: Poincare-space screening")
    pf.main() if hasattr(pf, "main") else None
    print(f"[HyperFuse] Done. Outputs in {args.out_dir}")


if __name__ == "__main__":
    main()
