"""
源-目标逐区方向对照验证（修正方向差显示口径）
- 方向差统一按最小轴向显示：min(raw, 180-raw)，同向/反向视为同一轴向
- 补充输出 d_sccp、d_trace、总分，确认方向项实际参与评分
- 评分逻辑本身不变，仅修正显示与诊断输出
"""
import cv2
import numpy as np
import os
import random
from placement_features import (
    extract_8_regions,
    compute_region_trace_feat,
    calc_trace_divergence,
    precompute_gradient_full,
    sccp_to_find_best_position
)

import os as _os
BASE_IMG_DIR = _os.environ.get("HYPERFUSE_TRAIN_IMG", "./data/fpcsd/images/train")
BASE_LBL_DIR = _os.environ.get("HYPERFUSE_TRAIN_LBL", "./data/fpcsd/labels/train")
SAFE_MARGIN = 15
LAMBDA_TRACE = 0.1
COH_THRESH = 0.3
MIN_VALID_TRACE_REGIONS = 2
MARGIN_RATIO = 0.25
MIN_MARGIN = 8
RANDOM_SEED = 42

random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)


def load_all_bboxes(label_path, img_w, img_h):
    bboxes = []
    if not os.path.exists(label_path):
        return bboxes
    with open(label_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) < 5:
                continue
            cx, cy, bw, bh = map(float, parts[1:5])
            x1 = max(0, int((cx - bw / 2) * img_w))
            y1 = max(0, int((cy - bh / 2) * img_h))
            x2 = min(img_w, int((cx + bw / 2) * img_w))
            y2 = min(img_h, int((cy + bh / 2) * img_h))
            if x2 <= x1 or y2 <= y1:
                continue
            bboxes.append((x1, y1, x2 - x1, y2 - y1))
    return bboxes


def build_valid_mask(label_path, img_w, img_h, safe_margin=15):
    mask = np.ones((img_h, img_w), dtype=bool)
    bboxes = load_all_bboxes(label_path, img_w, img_h)
    for x, y, w, h in bboxes:
        x1 = max(0, x - safe_margin)
        y1 = max(0, y - safe_margin)
        x2 = min(img_w, x + w + safe_margin)
        y2 = min(img_h, y + h + safe_margin)
        mask[y1:y2, x1:x2] = False
    return mask, bboxes


def main():
    img_list = sorted([f for f in os.listdir(BASE_IMG_DIR) if f.lower().endswith(('.png', '.jpg'))])
    src_name = img_list[147 % len(img_list)]
    dst_name = img_list[1612 % len(img_list)]

    src_img = cv2.imread(os.path.join(BASE_IMG_DIR, src_name), cv2.IMREAD_GRAYSCALE)
    dst_img = cv2.imread(os.path.join(BASE_IMG_DIR, dst_name), cv2.IMREAD_GRAYSCALE)
    src_h, src_w = src_img.shape
    dst_h, dst_w = dst_img.shape

    src_lbl = os.path.join(BASE_LBL_DIR, os.path.splitext(src_name)[0] + ".txt")
    dst_lbl = os.path.join(BASE_LBL_DIR, os.path.splitext(dst_name)[0] + ".txt")

    src_bboxes = load_all_bboxes(src_lbl, src_w, src_h)
    src_bboxes.sort(key=lambda b: b[2] * b[3])
    src_bbox = src_bboxes[len(src_bboxes) // 2]
    sx, sy, sw, sh = src_bbox

    src_gx, src_gy, _, _ = precompute_gradient_full(src_img)
    dst_gx, dst_gy, _, _ = precompute_gradient_full(dst_img)
    valid_mask, _ = build_valid_mask(dst_lbl, dst_w, dst_h, SAFE_MARGIN)

    # 调用SCCP-TO获取选中位置与详情
    dst_bbox, total_score, detail, fail_reason, _, _ = sccp_to_find_best_position(
        src_img, src_gx, src_gy, src_bbox,
        dst_img, dst_gx, dst_gy, valid_mask,
        safe_margin=SAFE_MARGIN,
        lambda_trace=LAMBDA_TRACE,
        coherence_thresh=COH_THRESH,
        min_valid_trace_regions=MIN_VALID_TRACE_REGIONS,
        debug=True
    )

    if dst_bbox is None:
        print(f"选址失败：{fail_reason}")
        return

    m = max(MIN_MARGIN, int(MARGIN_RATIO * min(sw, sh)))

    src_regions, ex1s, ey1s, ex2s, ey2s, _, _ = extract_8_regions(src_bbox, m, src_h, src_w)
    dst_regions, ex1d, ey1d, ex2d, ey2d, _, _ = extract_8_regions(dst_bbox, m, dst_h, dst_w)

    region_names = [
        "top_left", "top", "top_right",
        "left", "right",
        "bottom_left", "bottom", "bottom_right"
    ]

    print("=" * 95)
    print("源-目标对应区域方向明细对照（修正轴向差口径）")
    print("=" * 95)
    print(f"源图：{src_name}，缺陷框：{src_bbox}")
    print(f"目标图：{dst_name}，选中框：{dst_bbox}")
    print(f"lambda_trace = {LAMBDA_TRACE}, coherence_thresh = {COH_THRESH}")
    print(f"trace_available = {detail['trace_available']}")
    print(f"参与评分的对应区域数 = {detail['valid_trace_regions']} / 8")
    print(f"原SCCP分 d_sccp = {detail['sccp_score']:.6f}")
    print(f"方向分 d_trace = {detail['trace_score']:.6f}")
    print(f"最终总分 total_score = {total_score:.6f}")
    print()
    print(f"{'区域名':<15} {'源方向(°)':<12} {'源coh':<10} {'目标方向(°)':<12} {'目标coh':<10} {'轴向差(°)':<10} {'参与评分':<10}")
    print("-" * 95)

    for i in range(8):
        mask_s, name_s, valid_s, _ = src_regions[i]
        mask_d, name_d, valid_d, _ = dst_regions[i]

        if not valid_s or not valid_d:
            print(f"{region_names[i]:<15} {'-':<12} {'-':<10} {'-':<12} {'-':<10} {'-':<10} {'否(区域无效)':<10}")
            continue

        r_gx_s = src_gx[ey1s:ey2s, ex1s:ex2s][mask_s]
        r_gy_s = src_gy[ey1s:ey2s, ex1s:ex2s][mask_s]
        theta_s, coh_s = compute_region_trace_feat(r_gx_s, r_gy_s)
        theta_s_deg = np.degrees(theta_s) % 180

        r_gx_d = dst_gx[ey1d:ey2d, ex1d:ex2d][mask_d]
        r_gy_d = dst_gy[ey1d:ey2d, ex1d:ex2d][mask_d]
        theta_d, coh_d = compute_region_trace_feat(r_gx_d, r_gy_d)
        theta_d_deg = np.degrees(theta_d) % 180

        # 修正：取最小轴向差，同向/反向视为一致
        raw_diff = abs(theta_s_deg - theta_d_deg) % 180.0
        axial_diff = min(raw_diff, 180.0 - raw_diff)

        min_coh = min(coh_s, coh_d)
        participate = min_coh >= COH_THRESH

        print(f"{region_names[i]:<15} {theta_s_deg:<12.1f} {coh_s:<10.3f} {theta_d_deg:<12.1f} {coh_d:<10.3f} {axial_diff:<10.1f} {'是' if participate else '否':<10}")

    print()
    print("说明：")
    print("  1. 方向均为走线切向，模180°，同向/反向视为同一轴向")
    print("  2. 轴向差取最小角度，0°=完全平行，90°=完全垂直")
    print("  3. 仅源、目标两端coherence均≥阈值时，该区域参与方向评分")
    print("  4. 评分内部使用 1-|cos(delta)|，天然兼容轴向正反，与显示口径一致")
    print("  5. coherence高仅说明局部梯度方向集中，不单独证明提取到的就是导电走线")


if __name__ == "__main__":
    main()
