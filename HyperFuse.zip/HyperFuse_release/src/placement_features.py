import cv2
import numpy as np
import csv
import numbers


# ============== 基础工具函数 ==============

def js_divergence(p: np.ndarray, q: np.ndarray, eps: float = 1e-8) -> float:
    p = np.asarray(p, dtype=np.float64) + eps
    q = np.asarray(q, dtype=np.float64) + eps
    p = p / p.sum()
    q = q / q.sum()
    m = 0.5 * (p + q)
    kl_pm = np.sum(p * np.log2(p / m))
    kl_qm = np.sum(q * np.log2(q / m))
    return float(0.5 * (kl_pm + kl_qm))


def extract_annulus_ring(bbox: tuple, margin: int, img_h: int, img_w: int):
    x, y, w, h = bbox
    ex1 = max(0, x - margin)
    ey1 = max(0, y - margin)
    ex2 = min(img_w, x + w + margin)
    ey2 = min(img_h, y + h + margin)
    offset_x = x - ex1
    offset_y = y - ey1
    ring_h = ey2 - ey1
    ring_w = ex2 - ex1
    mask = np.zeros((ring_h, ring_w), dtype=bool)
    mask[:offset_y, :] = True
    mask[offset_y + h:, :] = True
    mask[:, :offset_x] = True
    mask[:, offset_x + w:] = True
    return mask, ex1, ey1, ex2, ey2, offset_x, offset_y


# ============== 特征计算函数 ==============

def compute_gray_hist(pixels: np.ndarray, n_bins: int = 32) -> np.ndarray:
    if len(pixels) == 0:
        return np.zeros(n_bins, dtype=np.float64)
    hist, _ = np.histogram(pixels, bins=n_bins, range=(0, 255))
    hist = hist.astype(np.float64)
    s = hist.sum()
    return hist / s if s > 0 else hist


def compute_mag_hist(mag_ring: np.ndarray, n_bins: int = 16) -> np.ndarray:
    if len(mag_ring) == 0:
        return np.zeros(n_bins, dtype=np.float64)
    p95 = np.percentile(mag_ring, 95)
    if p95 < 1e-6:
        return np.zeros(n_bins, dtype=np.float64)
    mag_norm = np.clip(mag_ring / p95, 0, 1)
    hist, _ = np.histogram(mag_norm, bins=n_bins, range=(0, 1))
    hist = hist.astype(np.float64)
    s = hist.sum()
    return hist / s if s > 0 else hist


def compute_ori_hist_legacy(mag_ring: np.ndarray, ori_ring: np.ndarray,
                            n_bins: int = 16, mag_thresh: float = 1e-3) -> np.ndarray:
    valid = mag_ring > mag_thresh
    if valid.sum() == 0:
        return np.zeros(n_bins, dtype=np.float64)
    mag_valid = mag_ring[valid]
    ori_valid = ori_ring[valid]
    bin_width = 360.0 / n_bins
    hist = np.zeros(n_bins, dtype=np.float64)
    bin_idx = np.floor(ori_valid / bin_width).astype(int) % n_bins
    for i in range(len(bin_idx)):
        hist[bin_idx[i]] += mag_valid[i]
    s = hist.sum()
    return hist / s if s > 0 else hist


def compute_ori_hist(mag_ring: np.ndarray, ori_ring: np.ndarray,
                     n_bins: int = 16, mag_thresh: float = 1e-3) -> np.ndarray:
    valid = mag_ring > mag_thresh
    if valid.sum() == 0:
        return np.zeros(n_bins, dtype=np.float64)
    mag_valid = mag_ring[valid]
    ori_valid = ori_ring[valid]
    bin_width = 360.0 / n_bins
    bin_idx = np.floor(ori_valid / bin_width).astype(np.int32) % n_bins
    hist = np.bincount(bin_idx, weights=mag_valid, minlength=n_bins).astype(np.float64)
    s = hist.sum()
    return hist / s if s > 0 else hist


def gradient_orientation_degrees(gx: np.ndarray, gy: np.ndarray) -> np.ndarray:
    """
    计算梯度方向角，单位度，范围 [0, 360)
    兼容二维整图、布尔索引后的一维数组
    与 cv2.phase(gx, gy, angleInDegrees=True) 定义一致
    """
    gx = np.asarray(gx, dtype=np.float64)
    gy = np.asarray(gy, dtype=np.float64)
    if gx.shape != gy.shape:
        raise ValueError(f"gx/gy 形状不一致：{gx.shape} vs {gy.shape}")
    return np.mod(np.degrees(np.arctan2(gy, gx)), 360.0)


# ============== 梯度预处理 ==============

def precompute_gradient_maps(gray_img: np.ndarray):
    sobel_x = cv2.Sobel(gray_img, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(gray_img, cv2.CV_64F, 0, 1, ksize=3)
    mag = np.sqrt(sobel_x ** 2 + sobel_y ** 2)
    ori = cv2.phase(sobel_x, sobel_y, angleInDegrees=True)
    return mag, ori


def precompute_gradient_full(gray_img: np.ndarray):
    sobel_x = cv2.Sobel(gray_img, cv2.CV_64F, 1, 0, ksize=3)
    sobel_y = cv2.Sobel(gray_img, cv2.CV_64F, 0, 1, ksize=3)
    mag = np.sqrt(sobel_x ** 2 + sobel_y ** 2)
    ori = cv2.phase(sobel_x, sobel_y, angleInDegrees=False)
    return sobel_x, sobel_y, mag, ori


# ============== 输入校验 ==============

def _validate_inputs(
    src_gray, src_mag, src_ori, src_bbox,
    dst_gray, dst_mag, dst_ori, valid_mask,
    margin_ratio, min_margin, weights,
    coarse_stride, fine_stride, fine_range, safe_margin
):
    if src_gray.ndim != 2 or dst_gray.ndim != 2:
        raise ValueError("src_gray 和 dst_gray 必须是二维灰度图")
    src_h, src_w = src_gray.shape
    dst_h, dst_w = dst_gray.shape
    if src_mag.shape != (src_h, src_w) or src_ori.shape != (src_h, src_w):
        raise ValueError("src_mag / src_ori 尺寸必须与 src_gray 一致")
    if dst_mag.shape != (dst_h, dst_w) or dst_ori.shape != (dst_h, dst_w):
        raise ValueError("dst_mag / dst_ori 尺寸必须与 dst_gray 一致")
    if valid_mask is not None and valid_mask.shape != (dst_h, dst_w):
        raise ValueError("valid_mask 尺寸必须与 dst_gray 一致")

    x, y, w, h = src_bbox
    if not all(isinstance(v, numbers.Integral) for v in [x, y, w, h]):
        raise TypeError("bbox 坐标必须为整数类型，请在外层统一预处理后传入")
    if w <= 0 or h <= 0:
        raise ValueError(f"bbox 宽高必须为正，当前 w={w}, h={h}")
    if x < 0 or y < 0 or x + w > src_w or y + h > src_h:
        raise ValueError(f"bbox 超出源图范围，bbox=({x},{y},{w},{h})，图像尺寸=({src_w},{src_h})")

    if margin_ratio < 0 or min_margin < 0 or fine_range < 0 or safe_margin < 0:
        raise ValueError("几何参数不能为负")
    if coarse_stride <= 0 or fine_stride <= 0:
        raise ValueError(f"步长必须大于 0，当前 coarse_stride={coarse_stride}, fine_stride={fine_stride}")
    alpha, beta, gamma = weights
    if alpha < 0 or beta < 0 or gamma < 0:
        raise ValueError("权重不能为负")


# ============== NCC 选址 ==============

def ncc_find_best_position(
    src_gray, src_bbox, dst_gray, valid_mask=None, safe_margin=15
):
    sx, sy, sw, sh = src_bbox
    dst_h, dst_w = dst_gray.shape[:2]

    defect_patch = src_gray[sy:sy+sh, sx:sx+sw]
    if defect_patch.size == 0 or sw <= 0 or sh <= 0:
        return None, None, None

    try:
        ncc_heatmap = cv2.matchTemplate(dst_gray, defect_patch, cv2.TM_CCOEFF_NORMED)
    except Exception:
        return None, None, None

    if valid_mask is not None:
        hm_h, hm_w = ncc_heatmap.shape
        mask_roi = valid_mask[0:hm_h, 0:hm_w]
        ncc_heatmap[~mask_roi] = -1.0

    _, max_val, _, max_loc = cv2.minMaxLoc(ncc_heatmap)
    if max_val < -0.9:
        return None, None, None

    tx, ty = max_loc
    if tx < 0 or ty < 0 or tx + sw > dst_w or ty + sh > dst_h:
        return None, None, None

    target_bbox = (tx, ty, sw, sh)
    return target_bbox, max_val, None


# ============== 整圈 CCP 选址 ==============

def ccp_find_best_position(
    src_gray: np.ndarray,
    src_mag: np.ndarray,
    src_ori: np.ndarray,
    src_bbox: tuple,
    dst_gray: np.ndarray,
    dst_mag: np.ndarray,
    dst_ori: np.ndarray,
    valid_mask: np.ndarray = None,
    margin_ratio: float = 0.25,
    min_margin: int = 8,
    weights: tuple = (0.5, 0.25, 0.25),
    coarse_stride: int = 4,
    fine_stride: int = 1,
    fine_range: int = 8,
    safe_margin: int = 15,
    debug: bool = False,
):
    try:
        _validate_inputs(
            src_gray, src_mag, src_ori, src_bbox,
            dst_gray, dst_mag, dst_ori, valid_mask,
            margin_ratio, min_margin, weights,
            coarse_stride, fine_stride, fine_range, safe_margin
        )
    except Exception as e:
        if debug:
            return None, None, None, f"输入校验失败: {str(e)}", 0, (0, 0)
        return None, None, None

    x, y, w, h = src_bbox
    alpha, beta, gamma = weights
    src_h, src_w = src_gray.shape[:2]
    dst_h, dst_w = dst_gray.shape[:2]

    weight_sum = alpha + beta + gamma
    if weight_sum <= 0:
        if debug:
            return None, None, None, "权重和为0", 0, (0, 0)
        return None, None, None
    alpha, beta, gamma = alpha / weight_sum, beta / weight_sum, gamma / weight_sum

    m = max(min_margin, int(margin_ratio * min(w, h)))
    ring_mask, ex1, ey1, ex2, ey2, offset_x, offset_y = extract_annulus_ring(
        src_bbox, m, src_h, src_w
    )
    win_w = ex2 - ex1
    win_h = ey2 - ey1
    win_size = (win_w, win_h)

    if ring_mask.sum() < 10:
        if debug:
            return None, None, None, f"源上下文环像素不足: {ring_mask.sum()} < 10", 0, win_size
        return None, None, None

    src_gray_ring = src_gray[ey1:ey2, ex1:ex2][ring_mask]
    src_mag_ring = src_mag[ey1:ey2, ex1:ex2][ring_mask]
    src_ori_ring = src_ori[ey1:ey2, ex1:ex2][ring_mask]

    src_h_gray = compute_gray_hist(src_gray_ring)
    src_h_mag = compute_mag_hist(src_mag_ring)
    src_h_ori = compute_ori_hist(src_mag_ring, src_ori_ring)

    max_y = dst_h - win_h - safe_margin
    max_x = dst_w - win_w - safe_margin
    if max_y < safe_margin or max_x < safe_margin:
        if debug:
            return None, None, None, f"扩展窗口超限: 窗口{win_w}x{win_h}, 目标图{dst_w}x{dst_h}, 边距{safe_margin}", 0, win_size
        return None, None, None

    def _score_window(x_win, y_win):
        dst_gray_win = dst_gray[y_win:y_win+win_h, x_win:x_win+win_w]
        dst_mag_win = dst_mag[y_win:y_win+win_h, x_win:x_win+win_w]
        dst_ori_win = dst_ori[y_win:y_win+win_h, x_win:x_win+win_w]
        d_gray = js_divergence(src_h_gray, compute_gray_hist(dst_gray_win[ring_mask]))
        d_mag = js_divergence(src_h_mag, compute_mag_hist(dst_mag_win[ring_mask]))
        d_ori = js_divergence(src_h_ori, compute_ori_hist(dst_mag_win[ring_mask], dst_ori_win[ring_mask]))
        score = alpha * d_gray + beta * d_mag + gamma * d_ori
        return score, d_gray, d_mag, d_ori

    best_score = float('inf')
    best_x_win, best_y_win = safe_margin, safe_margin
    best_detail = None
    valid_window_count = 0

    for y_win in range(safe_margin, max_y + 1, coarse_stride):
        for x_win in range(safe_margin, max_x + 1, coarse_stride):
            if valid_mask is not None:
                if not valid_mask[y_win:y_win+win_h, x_win:x_win+win_w].all():
                    continue
            valid_window_count += 1
            score, d_g, d_m, d_o = _score_window(x_win, y_win)
            if score < best_score:
                best_score = score
                best_x_win, best_y_win = x_win, y_win
                best_detail = (d_g, d_m, d_o)

    if not np.isfinite(best_score):
        for y_win in range(safe_margin, max_y + 1, 1):
            for x_win in range(safe_margin, max_x + 1, 1):
                if valid_mask is not None:
                    if not valid_mask[y_win:y_win+win_h, x_win:x_win+win_w].all():
                        continue
                valid_window_count += 1
                score, d_g, d_m, d_o = _score_window(x_win, y_win)
                if score < best_score:
                    best_score = score
                    best_x_win, best_y_win = x_win, y_win
                    best_detail = (d_g, d_m, d_o)

    if not np.isfinite(best_score):
        if debug:
            return None, None, None, f"无有效候选窗口, 遍历合法数={valid_window_count}", valid_window_count, win_size
        return None, None, None

    if coarse_stride > fine_stride:
        cx, cy = best_x_win, best_y_win
        fine_y_start = max(safe_margin, cy - fine_range)
        fine_y_end = min(max_y, cy + fine_range)
        fine_x_start = max(safe_margin, cx - fine_range)
        fine_x_end = min(max_x, cx + fine_range)
        for y_win in range(fine_y_start, fine_y_end + 1, fine_stride):
            for x_win in range(fine_x_start, fine_x_end + 1, fine_stride):
                if valid_mask is not None:
                    if not valid_mask[y_win:y_win+win_h, x_win:x_win+win_w].all():
                        continue
                score, d_g, d_m, d_o = _score_window(x_win, y_win)
                if score < best_score:
                    best_score = score
                    best_x_win, best_y_win = x_win, y_win
                    best_detail = (d_g, d_m, d_o)

    target_x = best_x_win + offset_x
    target_y = best_y_win + offset_y
    target_bbox = (target_x, target_y, w, h)

    if debug:
        return target_bbox, best_score, best_detail, "", valid_window_count, win_size
    return target_bbox, best_score, best_detail


def save_placement_csv(csv_path: str, results: list):
    headers = [
        "src_image", "src_x", "src_y", "src_w", "src_h",
        "dst_image", "target_x", "target_y",
        "total_score", "d_gray", "d_mag", "d_ori"
    ]
    with open(csv_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        for row in results:
            assert len(row) == 12, f"行长度不符，预期 12 列，实际 {len(row)} 列"
            writer.writerow(row)


# ============== 8分区 SCCP 选址 ==============

def extract_8_regions(bbox: tuple, margin: int, img_h: int, img_w: int, min_pixels: int = 10):
    x, y, w, h = bbox
    ex1 = max(0, x - margin)
    ey1 = max(0, y - margin)
    ex2 = min(img_w, x + w + margin)
    ey2 = min(img_h, y + h + margin)
    offset_x = x - ex1
    offset_y = y - ey1
    win_h = ey2 - ey1
    win_w = ex2 - ex1

    x_split = [0, offset_x, offset_x + w, win_w]
    y_split = [0, offset_y, offset_y + h, win_h]

    region_names = [
        "top_left", "top", "top_right",
        "left",               "right",
        "bottom_left", "bottom", "bottom_right"
    ]
    region_indices = [
        (0, 0), (0, 1), (0, 2),
        (1, 0),          (1, 2),
        (2, 0), (2, 1), (2, 2)
    ]

    regions = []
    for (yi, xi), name in zip(region_indices, region_names):
        r_x1, r_x2 = x_split[xi], x_split[xi + 1]
        r_y1, r_y2 = y_split[yi], y_split[yi + 1]
        mask = np.zeros((win_h, win_w), dtype=bool)
        mask[r_y1:r_y2, r_x1:r_x2] = True
        pixel_count = mask.sum()
        is_valid = pixel_count >= min_pixels
        regions.append((mask, name, is_valid, pixel_count))
    return regions, ex1, ey1, ex2, ey2, offset_x, offset_y


def _calc_single_region_score(
    src_pixels_gray, src_pixels_mag, src_pixels_ori,
    dst_pixels_gray, dst_pixels_mag, dst_pixels_ori
):
    d_gray = js_divergence(compute_gray_hist(src_pixels_gray), compute_gray_hist(dst_pixels_gray))
    d_mag = js_divergence(compute_mag_hist(src_pixels_mag), compute_mag_hist(dst_pixels_mag))
    d_ori = js_divergence(
        compute_ori_hist(src_pixels_mag, src_pixels_ori),
        compute_ori_hist(dst_pixels_mag, dst_pixels_ori)
    )
    return 0.5 * d_gray + 0.25 * d_mag + 0.25 * d_ori, d_gray, d_mag, d_ori


def sccp_find_best_position(
    src_gray: np.ndarray,
    src_mag: np.ndarray,
    src_ori: np.ndarray,
    src_bbox: tuple,
    dst_gray: np.ndarray,
    dst_mag: np.ndarray,
    dst_ori: np.ndarray,
    valid_mask: np.ndarray = None,
    margin_ratio: float = 0.25,
    min_margin: int = 8,
    global_weight: float = 0.25,
    spatial_weight: float = 0.75,
    coarse_stride: int = 4,
    fine_stride: int = 1,
    fine_range: int = 8,
    safe_margin: int = 15,
    min_valid_regions: int = 6,
    debug: bool = False,
):
    try:
        _validate_inputs(
            src_gray, src_mag, src_ori, src_bbox,
            dst_gray, dst_mag, dst_ori, valid_mask,
            margin_ratio, min_margin, (global_weight, spatial_weight, 0.0),
            coarse_stride, fine_stride, fine_range, safe_margin
        )
    except Exception as e:
        if debug:
            return None, None, None, f"输入校验失败: {str(e)}", 0, (0, 0)
        return None, None, None

    x, y, w, h = src_bbox
    src_h, src_w = src_gray.shape[:2]
    dst_h, dst_w = dst_gray.shape[:2]

    weight_sum = global_weight + spatial_weight
    if weight_sum <= 0:
        if debug:
            return None, None, None, "权重和为0", 0, (0, 0)
        return None, None, None
    global_weight /= weight_sum
    spatial_weight /= weight_sum

    m = max(min_margin, int(margin_ratio * min(w, h)))
    src_regions, ex1, ey1, ex2, ey2, offset_x, offset_y = extract_8_regions(
        src_bbox, m, src_h, src_w
    )
    win_w = ex2 - ex1
    win_h = ey2 - ey1
    win_size = (win_w, win_h)

    valid_count = sum(1 for _, _, valid, _ in src_regions if valid)
    if valid_count < min_valid_regions:
        if debug:
            return None, None, None, f"有效区域不足: {valid_count}/8 < {min_valid_regions}", 0, win_size
        return None, None, None

    src_global_mask = np.zeros((win_h, win_w), dtype=bool)
    for mask, _, _, _ in src_regions:
        src_global_mask |= mask
    src_global_gray = src_gray[ey1:ey2, ex1:ex2][src_global_mask]
    src_global_mag = src_mag[ey1:ey2, ex1:ex2][src_global_mask]
    src_global_ori = src_ori[ey1:ey2, ex1:ex2][src_global_mask]

    src_h_gray_global = compute_gray_hist(src_global_gray)
    src_h_mag_global = compute_mag_hist(src_global_mag)
    src_h_ori_global = compute_ori_hist(src_global_mag, src_global_ori)

    src_region_features = []
    for mask, name, valid, _ in src_regions:
        if not valid:
            src_region_features.append(None)
            continue
        r_gray = src_gray[ey1:ey2, ex1:ex2][mask]
        r_mag = src_mag[ey1:ey2, ex1:ex2][mask]
        r_ori = src_ori[ey1:ey2, ex1:ex2][mask]
        src_region_features.append((r_gray, r_mag, r_ori))

    max_y = dst_h - win_h - safe_margin
    max_x = dst_w - win_w - safe_margin
    if max_y < safe_margin or max_x < safe_margin:
        if debug:
            return None, None, None, f"扩展窗口超限: 窗口{win_w}x{win_h}, 目标图{dst_w}x{dst_h}, 边距{safe_margin}", 0, win_size
        return None, None, None

    def _score_window(x_win, y_win):
        dst_win_gray = dst_gray[y_win:y_win+win_h, x_win:x_win+win_w]
        dst_win_mag = dst_mag[y_win:y_win+win_h, x_win:x_win+win_w]
        dst_win_ori = dst_ori[y_win:y_win+win_h, x_win:x_win+win_w]

        d_global = (
            0.5  * js_divergence(src_h_gray_global, compute_gray_hist(dst_win_gray[src_global_mask]))
            + 0.25 * js_divergence(src_h_mag_global, compute_mag_hist(dst_win_mag[src_global_mask]))
            + 0.25 * js_divergence(src_h_ori_global, compute_ori_hist(dst_win_mag[src_global_mask], dst_win_ori[src_global_mask]))
        )

        region_scores = []
        region_details = []
        for i, (mask, name, valid, _) in enumerate(src_regions):
            if not valid:
                region_details.append((None, None, None, None))
                continue
            dst_r_gray = dst_win_gray[mask]
            dst_r_mag = dst_win_mag[mask]
            dst_r_ori = dst_win_ori[mask]
            d_r, d_g, d_m, d_o = _calc_single_region_score(
                src_region_features[i][0], src_region_features[i][1], src_region_features[i][2],
                dst_r_gray, dst_r_mag, dst_r_ori
            )
            region_scores.append(d_r)
            region_details.append((d_r, d_g, d_m, d_o))

        d_spatial = np.mean(region_scores)
        total_score = global_weight * d_global + spatial_weight * d_spatial
        return total_score, d_global, d_spatial, region_details

    best_score = float('inf')
    best_x_win, best_y_win = safe_margin, safe_margin
    best_detail = None
    valid_window_count = 0

    for y_win in range(safe_margin, max_y + 1, coarse_stride):
        for x_win in range(safe_margin, max_x + 1, coarse_stride):
            if valid_mask is not None:
                if not valid_mask[y_win:y_win+win_h, x_win:x_win+win_w].all():
                    continue
            valid_window_count += 1
            score, d_glo, d_spa, reg_det = _score_window(x_win, y_win)
            if score < best_score:
                best_score = score
                best_x_win, best_y_win = x_win, y_win
                best_detail = {
                    "global_score": d_glo,
                    "spatial_score": d_spa,
                    "region_details": reg_det,
                    "region_valid": [v for _, _, v, _ in src_regions]
                }

    if not np.isfinite(best_score):
        for y_win in range(safe_margin, max_y + 1, 1):
            for x_win in range(safe_margin, max_x + 1, 1):
                if valid_mask is not None:
                    if not valid_mask[y_win:y_win+win_h, x_win:x_win+win_w].all():
                        continue
                valid_window_count += 1
                score, d_glo, d_spa, reg_det = _score_window(x_win, y_win)
                if score < best_score:
                    best_score = score
                    best_x_win, best_y_win = x_win, y_win
                    best_detail = {
                        "global_score": d_glo,
                        "spatial_score": d_spa,
                        "region_details": reg_det,
                        "region_valid": [v for _, _, v, _ in src_regions]
                    }

    if not np.isfinite(best_score):
        if debug:
            return None, None, None, f"无有效候选窗口, 遍历合法数={valid_window_count}", valid_window_count, win_size
        return None, None, None

    if coarse_stride > fine_stride:
        cx, cy = best_x_win, best_y_win
        fine_y_start = max(safe_margin, cy - fine_range)
        fine_y_end = min(max_y, cy + fine_range)
        fine_x_start = max(safe_margin, cx - fine_range)
        fine_x_end = min(max_x, cx + fine_range)
        for y_win in range(fine_y_start, fine_y_end + 1, fine_stride):
            for x_win in range(fine_x_start, fine_x_end + 1, fine_stride):
                if valid_mask is not None:
                    if not valid_mask[y_win:y_win+win_h, x_win:x_win+win_w].all():
                        continue
                score, d_glo, d_spa, reg_det = _score_window(x_win, y_win)
                if score < best_score:
                    best_score = score
                    best_x_win, best_y_win = x_win, y_win
                    best_detail = {
                        "global_score": d_glo,
                        "spatial_score": d_spa,
                        "region_details": reg_det,
                        "region_valid": [v for _, _, v, _ in src_regions]
                    }

    target_x = best_x_win + offset_x
    target_y = best_y_win + offset_y
    target_bbox = (target_x, target_y, w, h)

    if debug:
        return target_bbox, best_score, best_detail, "", valid_window_count, win_size
    return target_bbox, best_score, best_detail


def save_sccp_placement_csv(csv_path: str, results: list):
    headers = [
        "src_image", "src_x", "src_y", "src_w", "src_h",
        "dst_image", "target_x", "target_y",
        "total_score", "global_score", "spatial_score",
        "score_top_left", "score_top", "score_top_right",
        "score_left", "score_right",
        "score_bottom_left", "score_bottom", "score_bottom_right",
        "valid_top_left", "valid_top", "valid_top_right",
        "valid_left", "valid_right",
        "valid_bottom_left", "valid_bottom", "valid_bottom_right"
    ]
    with open(csv_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        for row in results:
            assert len(row) == 27, f"行长度不符，预期27列，实际{len(row)}列"
            writer.writerow(row)


# ==================================================
# SCCP-TO：空间分区 + 走线方向一致性（修复版）
# ==================================================

def compute_region_trace_feat(gx_pixels: np.ndarray, gy_pixels: np.ndarray, eps: float = 1e-8):
    if len(gx_pixels) < 5:
        return 0.0, 0.0

    Jxx = np.sum(gx_pixels * gx_pixels)
    Jyy = np.sum(gy_pixels * gy_pixels)
    Jxy = np.sum(gx_pixels * gy_pixels)

    theta_g = 0.5 * np.arctan2(2 * Jxy, Jxx - Jyy)
    theta_trace = theta_g + np.pi / 2

    trace_sum = Jxx + Jyy + eps
    coherence = np.sqrt((Jxx - Jyy) ** 2 + 4 * Jxy ** 2) / trace_sum

    return float(theta_trace), float(coherence)


def calc_trace_divergence(theta_src: float, theta_dst: float) -> float:
    delta = abs(theta_src - theta_dst) % np.pi
    return 1.0 - abs(np.cos(delta))


def sccp_to_find_best_position(
    src_gray: np.ndarray,
    src_gx: np.ndarray,
    src_gy: np.ndarray,
    src_bbox: tuple,
    dst_gray: np.ndarray,
    dst_gx: np.ndarray,
    dst_gy: np.ndarray,
    valid_mask: np.ndarray = None,
    margin_ratio: float = 0.25,
    min_margin: int = 8,
    global_weight: float = 0.25,
    spatial_weight: float = 0.75,
    lambda_trace: float = 0.0,
    coherence_thresh: float = 0.3,
    min_valid_trace_regions: int = 2,
    coarse_stride: int = 4,
    fine_stride: int = 1,
    fine_range: int = 8,
    safe_margin: int = 15,
    min_valid_regions: int = 6,
    debug: bool = False,
):
    # 步骤1：输入校验
    try:
        src_mag = np.sqrt(src_gx ** 2 + src_gy ** 2)
        src_ori = gradient_orientation_degrees(src_gx, src_gy)
        dst_mag = np.sqrt(dst_gx ** 2 + dst_gy ** 2)
        dst_ori = gradient_orientation_degrees(dst_gx, dst_gy)

        _validate_inputs(
            src_gray, src_mag, src_ori, src_bbox,
            dst_gray, dst_mag, dst_ori, valid_mask,
            margin_ratio, min_margin, (global_weight, spatial_weight, 0.0),
            coarse_stride, fine_stride, fine_range, safe_margin
        )
    except Exception as e:
        if debug:
            return None, None, None, f"[步骤1-输入校验] {str(e)}", 0, (0, 0)
        return None, None, None

    x, y, w, h = src_bbox
    src_h, src_w = src_gray.shape[:2]
    dst_h, dst_w = dst_gray.shape[:2]

    # 步骤2：权重归一化
    weight_sum = global_weight + spatial_weight
    if weight_sum <= 0:
        if debug:
            return None, None, None, "[步骤2-权重] 全局+空间权重和为0", 0, (0, 0)
        return None, None, None
    global_weight /= weight_sum
    spatial_weight /= weight_sum

    # 步骤3：源端8区域划分
    m = max(min_margin, int(margin_ratio * min(w, h)))
    src_regions, ex1, ey1, ex2, ey2, offset_x, offset_y = extract_8_regions(
        src_bbox, m, src_h, src_w
    )
    win_w = ex2 - ex1
    win_h = ey2 - ey1
    win_size = (win_w, win_h)

    valid_count = sum(1 for _, _, valid, _ in src_regions if valid)
    if valid_count < min_valid_regions:
        if debug:
            return None, None, None, f"[步骤3-区域划分] 有效区域不足: {valid_count}/8 < {min_valid_regions}", 0, win_size
        return None, None, None

    # 步骤4：预计算源端所有特征
    try:
        src_global_mask = np.zeros((win_h, win_w), dtype=bool)
        for mask, _, _, _ in src_regions:
            src_global_mask |= mask

        src_global_gray = src_gray[ey1:ey2, ex1:ex2][src_global_mask]
        src_global_gx = src_gx[ey1:ey2, ex1:ex2][src_global_mask]
        src_global_gy = src_gy[ey1:ey2, ex1:ex2][src_global_mask]
        src_global_mag = np.sqrt(src_global_gx ** 2 + src_global_gy ** 2)
        src_global_ori = gradient_orientation_degrees(src_global_gx, src_global_gy)

        src_h_gray_global = compute_gray_hist(src_global_gray)
        src_h_mag_global = compute_mag_hist(src_global_mag)
        src_h_ori_global = compute_ori_hist(src_global_mag, src_global_ori)

        src_region_features = []
        src_trace_feats = []
        for mask, name, valid, _ in src_regions:
            if not valid:
                src_region_features.append(None)
                src_trace_feats.append((0.0, 0.0))
                continue
            r_gray = src_gray[ey1:ey2, ex1:ex2][mask]
            r_gx = src_gx[ey1:ey2, ex1:ex2][mask]
            r_gy = src_gy[ey1:ey2, ex1:ex2][mask]
            r_mag = np.sqrt(r_gx ** 2 + r_gy ** 2)
            r_ori = gradient_orientation_degrees(r_gx, r_gy)

            src_region_features.append((r_gray, r_mag, r_ori))
            theta, coh = compute_region_trace_feat(r_gx, r_gy)
            src_trace_feats.append((theta, coh))
    except Exception as e:
        if debug:
            return None, None, None, f"[步骤4-源特征] {str(e)}", 0, win_size
        return None, None, None

    # 步骤5：滑窗范围检查
    max_y = dst_h - win_h - safe_margin
    max_x = dst_w - win_w - safe_margin
    if max_y < safe_margin or max_x < safe_margin:
        if debug:
            return None, None, None, f"[步骤5-窗口范围] 扩展窗口超限: 窗口{win_w}x{win_h}, 目标图{dst_w}x{dst_h}", 0, win_size
        return None, None, None

    # 步骤6：单窗口评分函数
    def _score_window(x_win, y_win):
        dst_win_gray = dst_gray[y_win:y_win+win_h, x_win:x_win+win_w]
        dst_win_gx = dst_gx[y_win:y_win+win_h, x_win:x_win+win_w]
        dst_win_gy = dst_gy[y_win:y_win+win_h, x_win:x_win+win_w]

        # 原SCCP全局分
        dst_global_gray = dst_win_gray[src_global_mask]
        dst_global_gx = dst_win_gx[src_global_mask]
        dst_global_gy = dst_win_gy[src_global_mask]
        dst_global_mag = np.sqrt(dst_global_gx ** 2 + dst_global_gy ** 2)
        dst_global_ori = gradient_orientation_degrees(dst_global_gx, dst_global_gy)

        d_global = (
            0.5  * js_divergence(src_h_gray_global, compute_gray_hist(dst_global_gray))
            + 0.25 * js_divergence(src_h_mag_global, compute_mag_hist(dst_global_mag))
            + 0.25 * js_divergence(src_h_ori_global, compute_ori_hist(dst_global_mag, dst_global_ori))
        )

        # 原SCCP分区分
        region_scores = []
        region_details = []
        for i, (mask, name, valid, _) in enumerate(src_regions):
            if not valid:
                region_details.append((None, None, None, None))
                continue
            dst_r_gray = dst_win_gray[mask]
            dst_r_gx = dst_win_gx[mask]
            dst_r_gy = dst_win_gy[mask]
            dst_r_mag = np.sqrt(dst_r_gx ** 2 + dst_r_gy ** 2)
            dst_r_ori = gradient_orientation_degrees(dst_r_gx, dst_r_gy)

            d_r, d_g, d_m, d_o = _calc_single_region_score(
                src_region_features[i][0], src_region_features[i][1], src_region_features[i][2],
                dst_r_gray, dst_r_mag, dst_r_ori
            )
            region_scores.append(d_r)
            region_details.append((d_r, d_g, d_m, d_o))

        d_spatial = np.mean(region_scores)
        d_sccp = global_weight * d_global + spatial_weight * d_spatial

        # 走线方向分
        d_trace = 0.0
        trace_weights = []
        trace_scores = []
        src_valid_trace = 0
        dst_valid_trace = 0
        valid_trace = 0
        trace_available = False

        if lambda_trace > 1e-8:
            for i, (mask, name, valid, _) in enumerate(src_regions):
                if not valid:
                    continue
                dst_r_gx = dst_win_gx[mask]
                dst_r_gy = dst_win_gy[mask]
                dst_theta, dst_coh = compute_region_trace_feat(dst_r_gx, dst_r_gy)
                src_theta, src_coh = src_trace_feats[i]

                if src_coh >= coherence_thresh:
                    src_valid_trace += 1
                if dst_coh >= coherence_thresh:
                    dst_valid_trace += 1

                min_coh = min(src_coh, dst_coh)
                if min_coh >= coherence_thresh:
                    delta = calc_trace_divergence(src_theta, dst_theta)
                    trace_scores.append(delta)
                    trace_weights.append(min_coh)
                    valid_trace += 1

            if valid_trace >= min_valid_trace_regions:
                total_weight = sum(trace_weights) + 1e-8
                d_trace = np.average(trace_scores, weights=trace_weights)
                trace_available = True

        # 总分：方向可用才加权，不可用退回原SCCP分
        if trace_available:
            total_score = (1 - lambda_trace) * d_sccp + lambda_trace * d_trace
        else:
            total_score = d_sccp

        detail = {
            "global_score": d_global,
            "spatial_score": d_spatial,
            "sccp_score": d_sccp,
            "trace_score": d_trace,
            "trace_available": trace_available,
            "src_valid_trace_regions": src_valid_trace,
            "dst_valid_trace_regions": dst_valid_trace,
            "valid_trace_regions": valid_trace,
            "avg_coherence_src": np.mean([c for _, c in src_trace_feats]) if src_trace_feats else 0,
            "lambda_trace": lambda_trace,
            "region_details": region_details,
            "region_valid": [v for _, _, v, _ in src_regions],
            "fine_search_error": ""
        }
        return total_score, d_sccp, d_trace, detail

    # 步骤7：粗搜索
    best_score = float('inf')
    best_x_win, best_y_win = safe_margin, safe_margin
    best_detail = None
    valid_window_count = 0
    has_valid_window = False
    coarse_error = ""

    try:
        for y_win in range(safe_margin, max_y + 1, coarse_stride):
            for x_win in range(safe_margin, max_x + 1, coarse_stride):
                if valid_mask is not None:
                    if not valid_mask[y_win:y_win+win_h, x_win:x_win+win_w].all():
                        continue
                valid_window_count += 1
                score, _, _, det = _score_window(x_win, y_win)
                if np.isfinite(score) and score < best_score:
                    best_score = score
                    best_x_win, best_y_win = x_win, y_win
                    best_detail = det
                    has_valid_window = True

        if not has_valid_window:
            for y_win in range(safe_margin, max_y + 1, 1):
                for x_win in range(safe_margin, max_x + 1, 1):
                    if valid_mask is not None:
                        if not valid_mask[y_win:y_win+win_h, x_win:x_win+win_w].all():
                            continue
                    valid_window_count += 1
                    score, _, _, det = _score_window(x_win, y_win)
                    if np.isfinite(score) and score < best_score:
                        best_score = score
                        best_x_win, best_y_win = x_win, y_win
                        best_detail = det
                        has_valid_window = True
    except Exception as e:
        coarse_error = str(e)

    if coarse_error:
        if debug:
            return None, None, None, f"[步骤7-粗搜索异常] {coarse_error}", valid_window_count, win_size
        return None, None, None

    if not has_valid_window or not np.isfinite(best_score):
        if debug:
            return None, None, None, f"[步骤7-无有效候选] 遍历合法数={valid_window_count}", valid_window_count, win_size
        return None, None, None

    # 步骤8：细搜索
    if coarse_stride > fine_stride:
        cx, cy = best_x_win, best_y_win
        fine_y_start = max(safe_margin, cy - fine_range)
        fine_y_end = min(max_y, cy + fine_range)
        fine_x_start = max(safe_margin, cx - fine_range)
        fine_x_end = min(max_x, cx + fine_range)
        try:
            for y_win in range(fine_y_start, fine_y_end + 1, fine_stride):
                for x_win in range(fine_x_start, fine_x_end + 1, fine_stride):
                    if valid_mask is not None:
                        if not valid_mask[y_win:y_win+win_h, x_win:x_win+win_w].all():
                            continue
                    score, _, _, det = _score_window(x_win, y_win)
                    if np.isfinite(score) and score < best_score:
                        best_score = score
                        best_x_win, best_y_win = x_win, y_win
                        best_detail = det
        except Exception as e:
            if best_detail is not None:
                best_detail["fine_search_error"] = str(e)

    # 步骤9：坐标回算
    target_x = best_x_win + offset_x
    target_y = best_y_win + offset_y
    target_bbox = (target_x, target_y, w, h)

    if debug:
        return target_bbox, best_score, best_detail, "", valid_window_count, win_size
    return target_bbox, best_score, best_detail


# ==================================================
# 走线方向可视化诊断
# ==================================================

def draw_trace_direction_check(
    src_gray, src_gx, src_gy, src_bbox,
    dst_gray, dst_gx, dst_gy, dst_bbox,
    margin_ratio=0.25, min_margin=8, coherence_thresh=0.3,
    line_len=15
):
    src_h, src_w = src_gray.shape[:2]
    dst_h, dst_w = dst_gray.shape[:2]
    m = max(min_margin, int(margin_ratio * min(src_bbox[2], src_bbox[3])))

    src_regions, ex1s, ey1s, ex2s, ey2s, _, _ = extract_8_regions(src_bbox, m, src_h, src_w)
    dst_regions, ex1d, ey1d, ex2d, ey2d, _, _ = extract_8_regions(dst_bbox, m, dst_h, dst_w)

    src_vis = cv2.cvtColor(src_gray, cv2.COLOR_GRAY2BGR)
    dst_vis = cv2.cvtColor(dst_gray, cv2.COLOR_GRAY2BGR)

    # 源端方向线
    for i, (mask, name, valid, _) in enumerate(src_regions):
        if not valid:
            continue
        r_gx = src_gx[ey1s:ey2s, ex1s:ex2s][mask]
        r_gy = src_gy[ey1s:ey2s, ex1s:ex2s][mask]
        theta, coh = compute_region_trace_feat(r_gx, r_gy)
        cy, cx = np.mean(np.where(mask), axis=1)
        cx += ex1s
        cy += ey1s

        dx = line_len * np.cos(theta)
        dy = line_len * np.sin(theta)
        color = (0, 255, 0) if coh >= coherence_thresh else (0, 0, 255)
        cv2.line(src_vis, (int(cx-dx), int(cy-dy)), (int(cx+dx), int(cy+dy)), color, 2)
        cv2.rectangle(src_vis, (ex1s, ey1s), (ex2s, ey2s), (255, 255, 255), 1)

    # 目标端方向线
    for i, (mask, name, valid, _) in enumerate(dst_regions):
        if not valid:
            continue
        r_gx = dst_gx[ey1d:ey2d, ex1d:ex2d][mask]
        r_gy = dst_gy[ey1d:ey2d, ex1d:ex2d][mask]
        theta, coh = compute_region_trace_feat(r_gx, r_gy)
        cy, cx = np.mean(np.where(mask), axis=1)
        cx += ex1d
        cy += ey1d

        dx = line_len * np.cos(theta)
        dy = line_len * np.sin(theta)
        color = (0, 255, 0) if coh >= coherence_thresh else (0, 0, 255)
        cv2.line(dst_vis, (int(cx-dx), int(cy-dy)), (int(cx+dx), int(cy+dy)), color, 2)
        cv2.rectangle(dst_vis, (ex1d, ey1d), (ex2d, ey2d), (255, 255, 255), 1)

    sx, sy, sw, sh = src_bbox
    cv2.rectangle(src_vis, (sx, sy), (sx+sw, sy+sh), (0, 0, 255), 2)
    dx, dy, dw, dh = dst_bbox
    cv2.rectangle(dst_vis, (dx, dy), (dx+dw, dy+dh), (0, 0, 255), 2)

    return np.hstack([src_vis, dst_vis])
