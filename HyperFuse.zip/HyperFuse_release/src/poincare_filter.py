"""
poincare_filter.py
Poincare-ball quality screening of the candidate pool (paper Section 3.4).

Pipeline:
1. Extract 512-d features of real defect patches with ImageNet-pretrained ResNet-18
   (classification head removed), normalize to L2 norm 0.99.
2. Map features into the Poincare ball (curvature c=1) via the origin exponential map.
3. Estimate the Frechet mean anchor mu and the distance distribution of real samples.
4. Compute the hyperbolic distance of every candidate to mu; keep candidates
   within the given quantile threshold, sorted by distance, up to --top_k.

--top_k makes it possible to build both the 5000-sample final set and larger
ablation sets (e.g. 6000 in Table 2) from the same 10000-candidate pool.
All randomness is seeded (default 42).

Usage:
    python poincare_filter.py --real_img <train images> --real_lbl <train labels> \
        --pool_img <candidate images> --pool_lbl <candidate labels> \
        --out_img <kept images> --out_lbl <kept labels> --top_k 5000
"""

import os
import shutil
import json
import argparse

import torch
import numpy as np
import pandas as pd
from torchvision import models, transforms
from PIL import Image
from tqdm import tqdm


def poincare_dist(u, v, eps=1e-5):
    """Poincare disk distance with curvature c=1; inputs must satisfy ||x|| < 1."""
    norm_u = torch.clamp(torch.sum(u ** 2, dim=-1), max=1.0 - eps)
    norm_v = torch.clamp(torch.sum(v ** 2, dim=-1), max=1.0 - eps)
    sq = torch.sum((u - v) ** 2, dim=-1)
    arg = torch.clamp(1.0 + 2.0 * sq / ((1.0 - norm_u) * (1.0 - norm_v)), min=1.0 + eps)
    return torch.acosh(arg)


def frechet_mean_poincare(points, num_iter=20, eps=1e-5):
    """Weighted-iteration Frechet mean on the Poincare disk, returns [1, D]."""
    mu = torch.mean(points, dim=0, keepdim=True)
    mu = mu / (torch.norm(mu, dim=-1, keepdim=True) + eps) * 0.99
    for _ in range(num_iter):
        d = poincare_dist(mu, points)[:, None]
        w = 1.0 / (d + eps)
        numerator = torch.sum(w * points, dim=0, keepdim=True)
        denom = torch.sum(w, dim=0, keepdim=True)
        mu = numerator / denom
        norm_mu = torch.norm(mu, dim=-1, keepdim=True)
        mu = mu / (norm_mu + eps) * 0.99
    return mu


def extract_patch_feature(img_obj, bbox, model, tf, device):
    """Crop the defect patch, extract features, map into the Poincare disk."""
    x1, y1, x2, y2 = bbox
    crop = img_obj.crop((x1, y1, x2, y2))
    inp = tf(crop).unsqueeze(0).to(device)
    with torch.no_grad():
        feat = model(inp)
        feat = torch.nn.functional.normalize(feat, p=2, dim=1) * 0.99
    return feat


def read_first_bbox(lbl_path, W, H):
    with open(lbl_path, "r") as f:
        line = f.readline().strip()
    if not line:
        return None
    _, cx, cy, bw, bh = map(float, line.split())
    x1 = max(0, int((cx - bw / 2) * W))
    y1 = max(0, int((cy - bh / 2) * H))
    x2 = min(W, int((cx + bw / 2) * W))
    y2 = min(H, int((cy + bh / 2) * H))
    if x2 <= x1 or y2 <= y1:
        return None
    return (x1, y1, x2, y2)


def collect_real_features(img_dir, lbl_dir, model, tf, device):
    feats = []
    for name in tqdm(sorted(os.listdir(img_dir)), desc="Real-set features"):
        if not name.lower().endswith((".jpg", ".png")):
            continue
        lbl_path = os.path.join(lbl_dir, os.path.splitext(name)[0] + ".txt")
        if not os.path.exists(lbl_path):
            continue
        img = Image.open(os.path.join(img_dir, name)).convert("RGB")
        W, H = img.size
        bbox = read_first_bbox(lbl_path, W, H)
        if bbox is None:
            continue
        feats.append(extract_patch_feature(img, bbox, model, tf, device))
    return torch.cat(feats, dim=0)


def score_candidates(img_dir, lbl_dir, mu, model, tf, device):
    rows = []
    for name in tqdm(sorted(os.listdir(img_dir)), desc="Score candidates"):
        if not name.lower().endswith((".jpg", ".png")):
            continue
        lbl_path = os.path.join(lbl_dir, os.path.splitext(name)[0] + ".txt")
        if not os.path.exists(lbl_path):
            continue
        try:
            img = Image.open(os.path.join(img_dir, name)).convert("RGB")
            W, H = img.size
            bbox = read_first_bbox(lbl_path, W, H)
            if bbox is None:
                continue
            feat = extract_patch_feature(img, bbox, model, tf, device)
            d = poincare_dist(mu, feat).item()
            rows.append({"filename": name, "distance": d})
        except Exception:
            continue
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(description="Poincare-ball quality screening")
    parser.add_argument("--real_img", required=True, help="real training image directory")
    parser.add_argument("--real_lbl", required=True, help="real training label directory")
    parser.add_argument("--pool_img", required=True, help="candidate pool image directory")
    parser.add_argument("--pool_lbl", required=True, help="candidate pool label directory")
    parser.add_argument("--out_img", required=True, help="output image directory for kept samples")
    parser.add_argument("--out_lbl", required=True, help="output label directory for kept samples")
    parser.add_argument("--top_k", type=int, default=5000, help="max number of kept samples (5000 final set, 6000 for Table 2)")
    parser.add_argument("--quantile", type=float, default=0.95, help="distance quantile threshold")
    parser.add_argument("--stat_json", default="poincare_stats.json", help="path to save mu/tau statistics")
    parser.add_argument("--report_csv", default="candidate_scores.csv", help="path to save per-candidate distance report")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    model = models.resnet18(weights="DEFAULT").to(device).eval()
    model.fc = torch.nn.Identity()
    tf = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
    ])

    real_feats = collect_real_features(args.real_img, args.real_lbl, model, tf, device)
    print(f"Real samples used for statistics: {real_feats.shape[0]}")
    mu = frechet_mean_poincare(real_feats)
    dists = poincare_dist(mu, real_feats)
    tau = float(torch.quantile(dists, args.quantile))
    print(f"Frechet anchor mu computed, tau({args.quantile:.0%}) = {tau:.4f}")

    df = score_candidates(args.pool_img, args.pool_lbl, mu, model, tf, device)
    print(f"Candidates scored: {len(df)}")
    df.to_csv(args.report_csv, index=False, encoding="utf-8")

    valid = df[df["distance"] <= tau].sort_values("distance").reset_index(drop=True)
    keep = valid.head(args.top_k)
    print(f"Pass threshold: {len(valid)}, kept: {len(keep)} (top_k={args.top_k})")

    os.makedirs(args.out_img, exist_ok=True)
    os.makedirs(args.out_lbl, exist_ok=True)
    for name in tqdm(keep["filename"], desc="Copy kept samples"):
        shutil.copy(os.path.join(args.pool_img, name), os.path.join(args.out_img, name))
        txt = os.path.splitext(name)[0] + ".txt"
        shutil.copy(os.path.join(args.pool_lbl, txt), os.path.join(args.out_lbl, txt))

    stat = {
        "num_real_samples": int(real_feats.shape[0]),
        "quantile": args.quantile,
        "tau": tau,
        "top_k": args.top_k,
        "kept": int(len(keep)),
    }
    with open(args.stat_json, "w", encoding="utf-8") as f:
        json.dump(stat, f, ensure_ascii=False, indent=2)
    print(f"Done, kept {len(keep)} samples -> {args.out_img}")


if __name__ == "__main__":
    main()
