"""
SCCP-TO-FPC 实验分支 V1.3（修订版；诊断用途）
修正点：
1. 板边筛查：连通域区分「边界相连板外区域」与「内部丝印」，仅统计源bbox patch内
2. 统一CSV字段名，淘汰样本同字段写入
3. 相位计算修正：用互相关峰值位移计算相位差，范围[0,1]，越小越好
4. 补全相位有效率、源端有效区域数、完整评分公式
5. 重新判定样本2是否为丝印误判
6. 保留选址+融合对照图，单变量对比
"""
import os
import cv2
import numpy as np
import csv
import random
from pathlib import Path
from placement_features import (
    extract_8_regions,
    compute_region_trace_feat,
    precompute_gradient_full
)
from residual_mask import (
    estimate_fpc_defect_residual,
    apply_lab_residual,
    mask_bbox,
    validate_residual_mask,
    apply_lab_residual_with_stats,
    changed_region_bbox,
    compute_trace_texture_support,
    run_residual_branch,
    write_residual_diagnosis_csv,
    fallback_residual_record,
)

# ==================================================
# 全局配置（权重固定，不调参）
# ==================================================
# Paths: override via environment variables or edit here.
# Expected layout:
#   <data_root>/images/train, <data_root>/labels/train  (YOLO-format)
import os as _os
_DATA_ROOT = _os.environ.get("HYPERFUSE_DATA_ROOT", "./data/fpcsd")
TRAIN_IMG_DIR = _os.environ.get("HYPERFUSE_TRAIN_IMG", _os.path.join(_DATA_ROOT, "images", "train"))
TRAIN_LBL_DIR = _os.environ.get("HYPERFUSE_TRAIN_LBL", _os.path.join(_DATA_ROOT, "labels", "train"))
INPUT_CSV = _os.environ.get("HYPERFUSE_INPUT_CSV", "")
OUTPUT_DIR = _os.environ.get("HYPERFUSE_OUT", "./outputs/sccp_fusion")
Path(OUTPUT_DIR).mkdir(parents=True, exist_ok=True)

SAFE_MARGIN = 15
COH_THRESH = 0.3
MARGIN_RATIO = 0.25
MIN_MARGIN = 8
COARSE_STRIDE = 4

# 权重固定，本次不调参
LAMBDA_TRACE = 0.1
LAMBDA_PERIOD = 0.05
LAMBDA_PHASE = 0.05

# 板边筛查阈值
WHITE_GRAY_THRESH = 235
EDGE_CONNECTED_WHITE_MAX = 0.10  # 边界相连白色占比 >10% 判定跨板边
MIN_WHITE_AREA = 10  # 最小连通域面积

# 纹理参数
PERIOD_CONF_THRESH = 0.4
MIN_VALID_TEXTURE_REGIONS = 3
CANDIDATE_COVERAGE = 0.75

# 多背景检索原型：先做硬兼容筛选，再在合格候选中评分。
# 这些阈值是验证集起始值，不是论文结论；必须用验证集校准。
TARGET_POOL_SIZE = 20
MAX_TRACE_DIFF_DEG = 20.0
MAX_PERIOD_REL_DIFF = 0.25
MAX_PHASE_DIFF_CYCLES = 0.25  # 仅作报告参考；相位不作为硬拒绝条件
MIN_TRACE_COVERAGE = 0.50

# 归一化参数
NORM_LOW_P = 5
NORM_HIGH_P = 95

# 残差迁移参数（实验分支）
RESIDUAL_STRENGTH = 0.60

# 残差分支独立诊断输出目录（新目录；不覆盖旧 v1/v2 / v143 结果）
RESIDUAL_DIAG_DIR = _os.environ.get("HYPERFUSE_RESIDUAL_DIAG", os.path.join(OUTPUT_DIR, "residual_diag"))
os.makedirs(RESIDUAL_DIAG_DIR, exist_ok=True)

# ---- 残差分支准入门槛（工程筛查初值，非普适真值；调整须依据训练/验证集）----
# 角度/周期支持度
RES_MIN_TRACE_REGIONS = 2        # 方向可靠区最少数量
RES_MIN_PERIOD_REGIONS = 2       # 周期可靠区最少数量
RES_MAX_ANGLE_SPREAD_DEG = 12.0  # 各区角度与轴向均值的最大平均轴向偏差
# 重建不确定度（模块内部判据）
RES_MAX_UNCERTAIN_RATIO = 0.35
RES_MAX_REF_SPREAD = 26.0
RES_MIN_REF_SAMPLES = 3
# mask 质量门槛
RES_MIN_MASK_RATIO = 0.003
RES_MAX_MASK_RATIO = 0.45
RES_MIN_LARGEST_COMPONENT_RATIO = 0.60
RES_MAX_TIGHT_W_RATIO = 0.95
RES_MAX_TIGHT_H_RATIO = 0.95
RES_MIN_RESIDUAL_MAG_MEDIAN = 6.0
RES_REJECT_ON_BORDER_TOUCH = False
# 迁移有效性
RES_LAB_DELTA_EPSILON = 1.0     # changed 判定：单像素 LAB delta > 该阈值为"被改动"
RES_MIN_LAB_DELTA_MEDIAN = 2.0  # 仅对被改动像素的中位数 delta 判定弱迁移
RES_MIN_CHANGED_PIXEL_RATIO = 0.002
RES_LABEL_MIN_W = 4              # 标签 bbox 最小宽/高（像素）
RES_LABEL_MIN_H = 4
RES_LABEL_MIN_LAB_DELTA = 3.0    # 计算标签 bbox 时的修改区域阈值化门限
# residual 能量/裁剪与标签散度门槛（工程筛查初值，非普适真值；逐样本写入 CSV）
RES_MAX_RESIDUAL_MAG_P95 = 180.0  # mask 内残差幅值 p95 上限，防大面积过强
RES_MAX_EDGE_TOUCH_RATIO = 0.30   # mask 接触 bbox 外沿像素占比上限
RES_MAX_CLIPPED_RATIO = 0.05      # 融合时 LAB 裁剪像素占比上限
RES_LABEL_MIN_FILL_RATIO = 0.20   # 修改区域紧框内有效修改像素占比下限（防太散）
RES_LABEL_CLASS_ID = 0            # 新增标签类别（与现有数据集一致）

# 残差分支统一门槛配置（run_residual_branch 逐样本回写阈值到 CSV）
RESIDUAL_THRESHOLDS = {
    "min_trace_regions": RES_MIN_TRACE_REGIONS,
    "min_period_regions": RES_MIN_PERIOD_REGIONS,
    "max_angle_spread_deg": RES_MAX_ANGLE_SPREAD_DEG,
    "estimate": {
        "threshold_k": 3.0,
        "min_residual": 7.0,
        "min_mask_ratio": RES_MIN_MASK_RATIO,
        "max_mask_ratio": RES_MAX_MASK_RATIO,
        "min_reconstruction_coverage": 0.70,
        "min_ref_samples": RES_MIN_REF_SAMPLES,
        "max_ref_spread": RES_MAX_REF_SPREAD,
        "max_uncertain_ratio": RES_MAX_UNCERTAIN_RATIO,
    },
    "validate": {
        "min_mask_ratio": RES_MIN_MASK_RATIO,
        "max_mask_ratio": RES_MAX_MASK_RATIO,
        "min_largest_component_ratio": RES_MIN_LARGEST_COMPONENT_RATIO,
        "max_tight_w_ratio": RES_MAX_TIGHT_W_RATIO,
        "max_tight_h_ratio": RES_MAX_TIGHT_H_RATIO,
        "max_uncertain_ratio": RES_MAX_UNCERTAIN_RATIO,
        "min_residual_mag_median": RES_MIN_RESIDUAL_MAG_MEDIAN,
        "max_residual_mag_p95": RES_MAX_RESIDUAL_MAG_P95,
        "max_edge_touch_ratio": RES_MAX_EDGE_TOUCH_RATIO,
        "edge_strip_px": 1,
        "reject_on_border_touch": False,  # 外沿触达由 edge_touch_ratio 门槛量化执行
    },
    "transfer": {
        "lab_delta_epsilon": RES_LAB_DELTA_EPSILON,
        "min_lab_delta_median": RES_MIN_LAB_DELTA_MEDIAN,
        "min_changed_pixel_ratio": RES_MIN_CHANGED_PIXEL_RATIO,
        "max_clipped_ratio": RES_MAX_CLIPPED_RATIO,
        "label_min_w": RES_LABEL_MIN_W,
        "label_min_h": RES_LABEL_MIN_H,
        "label_min_lab_delta": RES_LABEL_MIN_LAB_DELTA,
        "label_min_fill_ratio": RES_LABEL_MIN_FILL_RATIO,
        "label_class_id": RES_LABEL_CLASS_ID,
    },
}

# 残差分支逐样本诊断记录（compute_ok / quality_pass / transfer_effective 三字段分离）
RESIDUAL_RECORDS = []
RESIDUAL_CSV = os.path.join(RESIDUAL_DIAG_DIR, "residual_diagnosis.csv")

# 残差诊断图输出映射（新目录 RESIDUAL_DIAG_DIR，不覆盖 OUTPUT_DIR 基线结果）
RESIDUAL_DIAG_FILE_MAP = [
    ("src_patch", "01_src_bbox_patch.jpg"),
    ("mask_bin", "02_candidate_mask.png"),
    ("mask_overlay", "03_candidate_mask_overlay.jpg"),
    ("normal_reconstruction", "04_normal_reconstruction.jpg"),
    ("residual_visual", "05_residual_visual.jpg"),
    ("dst_original", "06_target_original.jpg"),
    ("baseline_fusion", "07_baseline_full_fusion.jpg"),
    ("residual_fusion", "08_residual_only_fusion.jpg"),
    ("compare", "09_residual_vs_baseline_compare.jpg"),
    # sample4 定位用：旋转坐标系候选 mask / 逆旋转完整 mask / 裁剪回源 bbox mask
    ("mask_rot", "10_rotated_box_mask.png"),
    ("mask_inv_full", "11_inverse_full_mask.png"),
    ("mask_bbox", "12_bbox_cropped_mask.png"),
]

# ==================================================
# 工具函数
# ==================================================
def load_bboxes(label_path, img_w, img_h):
    bboxes = []
    if not os.path.exists(label_path):
        return bboxes
    with open(label_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            if len(parts) < 5:
                continue
            try:
                cls_id, cx, cy, w, h = map(float, parts[:5])
                x1 = int((cx - w/2) * img_w)
                y1 = int((cy - h/2) * img_h)
                bw = int(w * img_w)
                bh = int(h * img_h)
                if bw <= 0 or bh <= 0:
                    continue
                if x1 < 0 or y1 < 0 or x1 + bw > img_w or y1 + bh > img_h:
                    continue
                bboxes.append((int(cls_id), x1, y1, bw, bh))
            except (ValueError, TypeError):
                continue
    return bboxes


def build_valid_mask(img_h, img_w, bboxes, safe_margin):
    mask = np.ones((img_h, img_w), dtype=bool)
    for _, x, y, w, h in bboxes:
        x1 = max(0, x - safe_margin)
        y1 = max(0, y - safe_margin)
        x2 = min(img_w, x + w + safe_margin)
        y2 = min(img_h, y + h + safe_margin)
        mask[y1:y2, x1:x2] = False
    return mask


def build_board_white_mask(img_bgr, white_thresh=None, min_area=None, dilate_px=None):
    """目标侧板外白背景掩码。
    灰度不低于 white_thresh、八连通、面积不小于 min_area、且与图像边界相连的白色连通域
    视为板外背景，外扩 dilate_px 后标记为不可用；位于板面内部的白色区域不剔除。
    返回 (img_h, img_w) 布尔数组，True 表示该像素可参与放置。
    """
    if white_thresh is None:
        white_thresh = WHITE_GRAY_THRESH
    if min_area is None:
        min_area = MIN_WHITE_AREA
    if dilate_px is None:
        dilate_px = SAFE_MARGIN
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape
    white = (gray >= white_thresh).astype(np.uint8)
    num, labels, stats, _ = cv2.connectedComponentsWithStats(white, connectivity=8)
    out = np.zeros((h, w), np.uint8)
    for i in range(1, num):
        if int(stats[i, cv2.CC_STAT_AREA]) < min_area:
            continue
        x, y, bw, bh = [int(v) for v in stats[i][:4]]
        if x <= 0 or y <= 0 or x + bw >= w or y + bh >= h:
            out[labels == i] = 1
    if dilate_px > 0 and out.any():
        k = np.ones((2 * dilate_px + 1, 2 * dilate_px + 1), np.uint8)
        out = cv2.dilate(out, k)
    return out == 0


# ==================================================
# 一、修正版板边筛查：连通域区分板外/丝印
# ==================================================
def check_pcb_edge_refined(patch_color):
    """
    仅统计源bbox patch内的白色像素
    连通域分析区分：边界相连的板外区域 vs 内部分散的丝印区域
    返回：是否有效、原因、统计字典、叠加图
    """
    gray = cv2.cvtColor(patch_color, cv2.COLOR_BGR2GRAY)
    h, w = gray.shape

    # 二值化白色区域
    white_mask = (gray >= WHITE_GRAY_THRESH).astype(np.uint8) * 255
    total_white_ratio = np.sum(white_mask > 0) / (h * w)

    # 连通域分析
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(white_mask, connectivity=8)

    edge_connected_area = 0
    internal_area = 0
    touch_edges = set()

    for i in range(1, num_labels):
        area = stats[i, cv2.CC_STAT_AREA]
        if area < MIN_WHITE_AREA:
            continue
        x, y, bw, bh = stats[i, cv2.CC_STAT_LEFT], stats[i, cv2.CC_STAT_TOP], stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT]

        # 判断是否触及patch边界
        touch_left = x == 0
        touch_right = x + bw >= w
        touch_top = y == 0
        touch_bottom = y + bh >= h
        is_edge_connected = touch_left or touch_right or touch_top or touch_bottom

        if is_edge_connected:
            edge_connected_area += area
            if touch_left: touch_edges.add("left")
            if touch_right: touch_edges.add("right")
            if touch_top: touch_edges.add("top")
            if touch_bottom: touch_edges.add("bottom")
        else:
            internal_area += area

    edge_white_ratio = edge_connected_area / (h * w)
    internal_white_ratio = internal_area / (h * w)
    touch_edge_count = len(touch_edges)

    # 判定规则：仅边界相连白色占比超标才判定跨板边淘汰
    is_valid = True
    fail_reason = ""
    if edge_white_ratio > EDGE_CONNECTED_WHITE_MAX:
        is_valid = False
        fail_reason = f"边界相连板外区域占比{edge_white_ratio*100:.1f}%，判定跨板边"
    elif total_white_ratio > 0.3 and edge_white_ratio <= EDGE_CONNECTED_WHITE_MAX:
        fail_reason = "内部高占比白色，疑似丝印，保留"

    # 可视化叠加图
    overlay = patch_color.copy()
    # 边界相连区域标红
    edge_mask = np.zeros_like(white_mask)
    for i in range(1, num_labels):
        x, y, bw, bh = stats[i, cv2.CC_STAT_LEFT], stats[i, cv2.CC_STAT_TOP], stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT]
        if (x == 0 or y == 0 or x+bw >= w or y+bh >= h) and stats[i, cv2.CC_STAT_AREA] >= MIN_WHITE_AREA:
            edge_mask[labels == i] = 255
    overlay[edge_mask > 0] = [0, 0, 255]  # 板外红
    # 内部丝印标蓝
    internal_mask = np.zeros_like(white_mask)
    for i in range(1, num_labels):
        x, y, bw, bh = stats[i, cv2.CC_STAT_LEFT], stats[i, cv2.CC_STAT_TOP], stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT]
        if not (x == 0 or y == 0 or x+bw >= w or y+bh >= h) and stats[i, cv2.CC_STAT_AREA] >= MIN_WHITE_AREA:
            internal_mask[labels == i] = 255
    overlay[internal_mask > 0] = [255, 0, 0]  # 丝印蓝

    cv2.rectangle(overlay, (0,0), (w-1, h-1), (255,255,0), 1)

    stats_dict = {
        "patch_white_ratio_pct": round(total_white_ratio * 100, 2),
        "patch_edge_white_ratio_pct": round(edge_white_ratio * 100, 2),
        "patch_internal_white_ratio_pct": round(internal_white_ratio * 100, 2),
        "patch_touch_edge_count": touch_edge_count,
        "patch_is_valid": is_valid,
        "patch_fail_reason": fail_reason
    }
    return is_valid, fail_reason, stats_dict, overlay


# ==================================================
# 二、修正相位计算：峰值位移法，输出真正相位差
# ==================================================
def compute_texture_features(patch_gray, theta_deg, src_proj_ref=None, region_mask=None, reference_period=None):
    """沿走线法向提取掩码区域周期与循环相位差；phase_diff范围[0, 0.5]。"""
    h, w = patch_gray.shape
    if h < 10 or w < 10:
        return np.nan, np.nan, 0.0, np.nan, None
    if region_mask is None:
        region_mask = np.ones((h, w), dtype=np.uint8)
    else:
        region_mask = np.asarray(region_mask, dtype=np.uint8)
        if region_mask.shape != (h, w):
            raise ValueError(f"region_mask shape {region_mask.shape} != patch shape {(h, w)}")
    rot = cv2.getRotationMatrix2D((w/2.0, h/2.0), -float(theta_deg), 1.0)
    image_r = cv2.warpAffine(patch_gray, rot, (w,h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    mask_r = cv2.warpAffine(region_mask, rot, (w,h), flags=cv2.INTER_NEAREST, borderMode=cv2.BORDER_CONSTANT, borderValue=0) > 0
    counts = mask_r.sum(axis=1)
    good = counts > 0
    if int(good.sum()) < 8:
        return float(theta_deg), np.nan, 0.0, np.nan, None
    proj = np.zeros(h, dtype=np.float64)
    proj[good] = (image_r.astype(np.float64) * mask_r).sum(axis=1)[good] / counts[good]
    rows=np.arange(h)
    proj[~good]=np.interp(rows[~good],rows[good],proj[good])
    proj=proj.astype(np.float32)
    smooth=cv2.GaussianBlur(proj.reshape(-1,1),(1,0),sigmaX=0,sigmaY=max(2.0,h/20.0)).ravel()
    proj=proj-smooth
    proj_norm=proj-float(proj.mean())
    std=float(proj_norm.std())
    if std < 1e-8:
        return float(theta_deg),np.nan,0.0,np.nan,proj_norm
    proj_norm=proj_norm/std
    ac=np.correlate(proj_norm,proj_norm,mode='full')[len(proj_norm)-1:]
    if len(ac)<5 or ac[0]<=1e-8:
        return float(theta_deg),np.nan,0.0,np.nan,proj_norm
    peaks=[(k,ac[k]) for k in range(2,min(len(ac)-2,80)) if ac[k]>ac[k-1] and ac[k]>=ac[k+1] and ac[k]>0.25*ac[0]]
    period,conf=np.nan,0.0
    if peaks:
        p,pval=min(peaks,key=lambda z:z[0])
        if 2<=p<=60:
            period=float(p); conf=float(np.clip(pval/(ac[0]+1e-8),0.0,1.0))
    phase=np.nan
    if src_proj_ref is not None and len(src_proj_ref)==len(proj_norm) and np.isfinite(period) and period>0:
        ref=np.asarray(src_proj_ref,dtype=np.float32); rs=float(ref.std())
        if rs>1e-8:
            ref=(ref-float(ref.mean()))/rs
            corr=np.correlate(proj_norm,ref,mode='full')
            shift=int(np.argmax(corr)-(len(ref)-1))
            p_ref=float(reference_period) if reference_period is not None and np.isfinite(reference_period) and reference_period>0 else float(period)
            cycles=(shift/p_ref)%1.0
            phase=float(min(cycles,1.0-cycles))
    return float(theta_deg),period,conf,phase,proj_norm


def axial_mean_deg(deg_values):
    """轴向（[0,180)）角度均值，避免 179° 与 1° 被平均成 90°。"""
    vals = np.asarray(list(deg_values), dtype=np.float64)
    if vals.size == 0:
        return None
    if vals.size == 1:
        return float(vals[0])
    rad = np.radians(2.0 * vals)
    mean = float(np.degrees(np.arctan2(np.sin(rad).sum(), np.cos(rad).sum())) / 2.0)
    return mean % 180.0


def aggregate_source_trace_texture(src_region_feats):
    """从源端 8 区特征聚合出 (走线切向角, 周期)。

    角度取方向可靠区的轴向均值；周期取周期可靠区的中位数。
    任一缺失时返回 (None, None)，调用方应跳过残差提取。
    """
    thetas = [f["theta_deg"] for f in src_region_feats
              if f.get("valid") and f.get("trace_ok")]
    periods = [float(f["period"]) for f in src_region_feats
               if f.get("valid") and f.get("period_ok")]
    if not thetas or not periods:
        return None, None
    return axial_mean_deg(thetas), float(np.median(periods))


def compute_source_region_texture(src_gray, src_gx, src_gy, src_bbox, margin):
    """独立计算源端 8 区走线/纹理特征（残差分支与诊断 runner 复用）。

    与 _run_placement_for_target 内的逐区特征循环逻辑一致，产出相同的
    src_region_feats / valid_trace_idx / valid_period_idx，供
    aggregate_source_trace_texture 与 compute_trace_texture_support 使用。
    不改动基线选址分支的任何代码路径。
    """
    src_h, src_w = src_gray.shape
    src_regions, ex1s, ey1s, ex2s, ey2s, offset_x, offset_y = extract_8_regions(
        src_bbox, margin, src_h, src_w
    )
    feats = []
    valid_trace_idx = []
    valid_period_idx = []
    valid_phase_idx = []

    for i, (mask, name, valid, _) in enumerate(src_regions):
        if not valid:
            feats.append({"valid": False})
            continue

        r_gx = src_gx[ey1s:ey2s, ex1s:ex2s][mask]
        r_gy = src_gy[ey1s:ey2s, ex1s:ex2s][mask]
        theta, coh = compute_region_trace_feat(r_gx, r_gy)
        theta_deg = np.degrees(theta) % 180
        trace_ok = coh >= COH_THRESH

        src_patch_region = src_gray[ey1s:ey2s, ex1s:ex2s].copy()
        _, period, period_conf, _, proj_ref = compute_texture_features(src_patch_region, theta_deg, region_mask=mask)
        period_ok = period_conf >= PERIOD_CONF_THRESH and not np.isnan(period)

        feats.append({
            "valid": True,
            "theta_deg": theta_deg,
            "coherence": coh,
            "trace_ok": trace_ok,
            "period": period,
            "period_conf": period_conf,
            "period_ok": period_ok,
            "proj_ref": proj_ref
        })

        if trace_ok:
            valid_trace_idx.append(i)
        if period_ok:
            valid_period_idx.append(i)
            valid_phase_idx.append(i)  # 相位有效与周期有效一致

    return feats, valid_trace_idx, valid_period_idx, valid_phase_idx


def _save_residual_diag_images(rdir, residual_images):
    """把 run_residual_branch 返回的诊断图按固定文件名写入新目录。"""
    for key, fname in RESIDUAL_DIAG_FILE_MAP:
        img = residual_images.get(key)
        if img is None:
            continue
        arr = np.asarray(img)
        if arr.dtype != np.uint8:
            arr = np.clip(arr, 0, 255).astype(np.uint8)
        cv2.imwrite(os.path.join(rdir, fname), arr)


def _write_residual_label_preview(rdir, dst_lbl_path, dst_w, dst_h, record):
    """写 10_labels_existing_plus_new.txt：原有标签全部保留 + 残差新增标签。

    仅为预览文件，写入残差诊断新目录，绝不覆盖原始标签文件。
    """
    lines = []
    existing = load_bboxes(dst_lbl_path, dst_w, dst_h)
    for cls_id, x, y, w, h in existing:
        lines.append("{} {:.6f} {:.6f} {:.6f} {:.6f}".format(
            int(cls_id), (x + w / 2.0) / dst_w, (y + h / 2.0) / dst_h,
            w / dst_w, h / dst_h))
    new_yolo = record.get("new_label_yolo", "")
    if new_yolo:
        lines.append(new_yolo)
    with open(os.path.join(rdir, "10_labels_existing_plus_new.txt"),
              "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def match_patch_lab_to_target(src_patch, dst_img, bbox, strength=0.65, ring_px=8):
    """用源patch外圈与目标框外围的稳健统计做温和LAB颜色匹配。"""
    x, y, w, h = map(int, bbox)
    ph, pw = src_patch.shape[:2]
    if ph < 3 or pw < 3:
        return src_patch.copy()

    band = max(1, min(8, int(round(0.12 * min(ph, pw)))))
    src_lab = cv2.cvtColor(src_patch, cv2.COLOR_BGR2LAB).astype(np.float32)
    dst_lab = cv2.cvtColor(dst_img, cv2.COLOR_BGR2LAB).astype(np.float32)

    # 源patch外圈作为正常背景统计，避免中心缺陷主导颜色校正。
    src_ring = np.zeros((ph, pw), dtype=bool)
    src_ring[:band, :] = True
    src_ring[-band:, :] = True
    src_ring[:, :band] = True
    src_ring[:, -band:] = True

    # 目标框外围背景环；不把目标框内部像素纳入匹配统计。
    dh, dw = dst_img.shape[:2]
    x0, y0 = max(0, x - ring_px), max(0, y - ring_px)
    x1, y1 = min(dw, x + w + ring_px), min(dh, y + h + ring_px)
    dst_ring = np.zeros((dh, dw), dtype=bool)
    dst_ring[y0:y1, x0:x1] = True
    dst_ring[max(0, y):min(dh, y+h), max(0, x):min(dw, x+w)] = False

    src_pixels = src_lab[src_ring]
    dst_pixels = dst_lab[dst_ring]
    if len(src_pixels) < 16 or len(dst_pixels) < 16:
        return src_patch.copy()

    src_med = np.median(src_pixels, axis=0)
    dst_med = np.median(dst_pixels, axis=0)
    src_scale = 1.4826 * np.median(np.abs(src_pixels - src_med), axis=0)
    dst_scale = 1.4826 * np.median(np.abs(dst_pixels - dst_med), axis=0)
    gain = np.clip((dst_scale + 1.0) / (src_scale + 1.0), 0.75, 1.33)

    adjusted = (src_lab - src_med) * gain + dst_med
    matched_lab = src_lab + float(strength) * (adjusted - src_lab)
    matched_lab = np.clip(matched_lab, 0, 255).astype(np.uint8)
    return cv2.cvtColor(matched_lab, cv2.COLOR_LAB2BGR)


def poisson_clone_with_feather(src_patch, dst_img, bbox, feather_px=None):
    """先按原设置做泊松融合，再对外缘做羽化；不改变patch中心区域。"""
    x, y, w, h = map(int, bbox)
    ph, pw = src_patch.shape[:2]
    if (pw, ph) != (w, h):
        raise ValueError(f"patch尺寸{pw}x{ph}与目标框{w}x{h}不一致")
    if x < 0 or y < 0 or x + w > dst_img.shape[1] or y + h > dst_img.shape[0]:
        raise ValueError(f"目标框越界：bbox={(x, y, w, h)}")

    if feather_px is None:
        feather_px = max(3, min(8, int(round(0.12 * min(w, h)))))

    # seamlessClone 的mask是区域mask，不是透明度mask，所以仍传二值mask。
    binary_mask = np.full((h, w), 255, dtype=np.uint8)
    center = (x + w // 2, y + h // 2)
    poisson = cv2.seamlessClone(src_patch, dst_img, binary_mask, center, cv2.NORMAL_CLONE)

    yy, xx = np.mgrid[0:h, 0:w]
    distance = np.minimum.reduce([xx + 1, w - xx, yy + 1, h - yy]).astype(np.float32)
    t = np.clip((distance - 1.0) / max(1.0, float(feather_px - 1)), 0.0, 1.0)
    alpha = t * t * (3.0 - 2.0 * t)
    alpha = np.clip(cv2.GaussianBlur(alpha, (0, 0), sigmaX=0.8), 0.0, 1.0)[..., None]

    out = dst_img.copy()
    target_roi = dst_img[y:y+h, x:x+w].astype(np.float32)
    poisson_roi = poisson[y:y+h, x:x+w].astype(np.float32)
    out[y:y+h, x:x+w] = np.clip(
        alpha * poisson_roi + (1.0 - alpha) * target_roi, 0, 255
    ).astype(np.uint8)
    return out


# 三、候选评分主逻辑
# ==================================================
def _run_placement_for_target(sample_row, target_name, enable_residual_branch=True):
    sample_idx = sample_row["sample_idx"]
    src_name = sample_row["src_image"]
    dst_name = target_name
    sx = int(float(sample_row["src_bbox_x"]))
    sy = int(float(sample_row["src_bbox_y"]))
    sw = int(float(sample_row["src_bbox_w"]))
    sh = int(float(sample_row["src_bbox_h"]))
    src_bbox = (sx, sy, sw, sh)

    src_path = os.path.join(TRAIN_IMG_DIR, src_name)
    dst_path = os.path.join(TRAIN_IMG_DIR, dst_name)
    dst_lbl_path = os.path.join(TRAIN_LBL_DIR, os.path.splitext(dst_name)[0] + ".txt")

    src_color = cv2.imread(src_path)
    dst_color = cv2.imread(dst_path)
    if src_color is None or dst_color is None:
        return None, f"图像读取失败：src={src_path}, dst={dst_path}", None
    src_gray = cv2.cvtColor(src_color, cv2.COLOR_BGR2GRAY)
    dst_gray = cv2.cvtColor(dst_color, cv2.COLOR_BGR2GRAY)

    dst_h, dst_w = dst_gray.shape
    dst_bboxes = load_bboxes(dst_lbl_path, dst_w, dst_h)
    valid_mask = build_valid_mask(dst_h, dst_w, dst_bboxes, SAFE_MARGIN)
    valid_mask = valid_mask & build_board_white_mask(dst_color)

    src_gx, src_gy, _, _ = precompute_gradient_full(src_gray)
    dst_gx, dst_gy, _, _ = precompute_gradient_full(dst_gray)

    src_h, src_w = src_gray.shape
    m = max(MIN_MARGIN, int(MARGIN_RATIO * min(sw, sh)))
    src_regions, ex1s, ey1s, ex2s, ey2s, offset_x, offset_y = extract_8_regions(
        src_bbox, m, src_h, src_w
    )
    win_w = ex2s - ex1s
    win_h = ey2s - ey1s

    max_x = dst_w - win_w - SAFE_MARGIN
    max_y = dst_h - win_h - SAFE_MARGIN

    sample_dir = os.path.join(OUTPUT_DIR, f"sample_{sample_idx}__target_{Path(dst_name).stem}")
    Path(sample_dir).mkdir(parents=True, exist_ok=True)

    # 1. 源patch板边筛查（仅bbox patch内）
    src_patch_color = src_color[sy:sy+sh, sx:sx+sw].copy()
    patch_valid, patch_reason, patch_stats, patch_overlay = check_pcb_edge_refined(src_patch_color)
    cv2.imwrite(os.path.join(sample_dir, "00_patch_edge_check.jpg"), patch_overlay)

    # 注意：本分支中的 d_sccp 是分区平均梯度幅值差代理，不是原论文完整 SCCP 评分器。
    # 统一字段：无论是否淘汰，都写入相同列
    base_metrics = {
        "sample_idx": sample_idx,
        "patch_white_ratio_pct": patch_stats["patch_white_ratio_pct"],
        "patch_edge_white_ratio_pct": patch_stats["patch_edge_white_ratio_pct"],
        "patch_internal_white_ratio_pct": patch_stats["patch_internal_white_ratio_pct"],
        "patch_touch_edge_count": patch_stats["patch_touch_edge_count"],
    }

    if not patch_valid:
        base_metrics.update({
            "status": "源patch无效",
            "fail_reason": patch_reason
        })
        return base_metrics, None

    # 2. 源端8区纹理特征预计算（固定可靠区域集合）
    src_region_feats = []
    valid_trace_idx = []
    valid_period_idx = []
    valid_phase_idx = []

    for i, (mask, name, valid, _) in enumerate(src_regions):
        if not valid:
            src_region_feats.append({"valid": False})
            continue

        r_gx = src_gx[ey1s:ey2s, ex1s:ex2s][mask]
        r_gy = src_gy[ey1s:ey2s, ex1s:ex2s][mask]
        theta, coh = compute_region_trace_feat(r_gx, r_gy)
        theta_deg = np.degrees(theta) % 180
        trace_ok = coh >= COH_THRESH

        src_patch_region = src_gray[ey1s:ey2s, ex1s:ex2s].copy()
        _, period, period_conf, _, proj_ref = compute_texture_features(src_patch_region, theta_deg, region_mask=mask)
        period_ok = period_conf >= PERIOD_CONF_THRESH and not np.isnan(period)

        src_region_feats.append({
            "valid": True,
            "theta_deg": theta_deg,
            "coherence": coh,
            "trace_ok": trace_ok,
            "period": period,
            "period_conf": period_conf,
            "period_ok": period_ok,
            "proj_ref": proj_ref
        })

        if trace_ok:
            valid_trace_idx.append(i)
        if period_ok:
            valid_period_idx.append(i)
            valid_phase_idx.append(i)  # 相位有效与周期有效一致

    trace_enabled = len(valid_trace_idx) >= 2
    # 1-2个可靠周期区域以 limited 模式运行；至少3个为 full；0个则禁用周期匹配。
    period_support_mode = ("full" if len(valid_period_idx) >= MIN_VALID_TEXTURE_REGIONS
                           else "limited" if len(valid_period_idx) >= 1 else "none")
    period_enabled = len(valid_period_idx) >= 1
    phase_enabled = len(valid_phase_idx) >= 1
    min_period_cover = max(1, int(np.ceil(len(valid_period_idx) * CANDIDATE_COVERAGE)))
    min_phase_cover = max(1, int(np.ceil(len(valid_phase_idx) * CANDIDATE_COVERAGE)))

    # 3. 遍历所有候选
    candidates = []
    for y in range(SAFE_MARGIN, max_y + 1, COARSE_STRIDE):
        for x in range(SAFE_MARGIN, max_x + 1, COARSE_STRIDE):
            if not valid_mask[y:y+win_h, x:x+win_w].all():
                continue

            d_sccp = 0.0
            d_trace = np.nan
            d_period = np.nan
            d_phase = np.nan
            trace_hit = 0
            trace_weight_sum = 0.0
            period_hit = 0
            phase_hit = 0
            period_diffs = []
            phase_diffs = []

            for i in range(8):
                feat = src_region_feats[i]
                if not feat["valid"]:
                    continue
                mask = src_regions[i][0]

                dst_r_gx = dst_gx[y:y+win_h, x:x+win_w][mask]
                dst_r_gy = dst_gy[y:y+win_h, x:x+win_w][mask]
                dst_theta, dst_coh = compute_region_trace_feat(dst_r_gx, dst_r_gy)
                dst_theta_deg = np.degrees(dst_theta) % 180

                # SCCP分项
                src_mag = np.sqrt(src_gx[ey1s:ey2s, ex1s:ex2s][mask]**2 + src_gy[ey1s:ey2s, ex1s:ex2s][mask]**2)
                dst_mag = np.sqrt(dst_r_gx**2 + dst_r_gy**2)
                d_sccp += abs(np.mean(src_mag) - np.mean(dst_mag))

                # 方向分项
                if feat["trace_ok"] and dst_coh >= COH_THRESH:
                    raw_diff = abs(feat["theta_deg"] - dst_theta_deg) % 180.0
                    axial_diff = min(raw_diff, 180.0 - raw_diff)
                    trace_weight = min(float(feat["coherence"]), float(dst_coh))
                    if trace_hit == 0:
                        d_trace = 0.0
                    d_trace += axial_diff * trace_weight
                    trace_weight_sum += trace_weight
                    trace_hit += 1

                # 周期 + 相位分项
                if feat["period_ok"]:
                    dst_patch_region = dst_gray[y:y+win_h, x:x+win_w].copy()
                    _, dst_period, dst_period_conf, dst_phase_diff, _ = compute_texture_features(
                        dst_patch_region, dst_theta_deg, src_proj_ref=feat["proj_ref"],
                        region_mask=mask, reference_period=feat["period"]
                    )
                    if dst_period_conf >= PERIOD_CONF_THRESH and not np.isnan(dst_period):
                        pdiff = abs(feat["period"] - dst_period) / (feat["period"] + 1e-8)
                        period_diffs.append(min(pdiff, 1.0))
                        period_hit += 1

                        if not np.isnan(dst_phase_diff):
                            phase_diffs.append(dst_phase_diff)
                            phase_hit += 1

            d_sccp /= 8
            if trace_weight_sum > 0:
                d_trace /= trace_weight_sum
            if period_hit >= min_period_cover:
                d_period = float(np.mean(period_diffs))
            if phase_hit >= min_phase_cover:
                d_phase = float(np.mean(phase_diffs))

            period_valid = period_hit >= min_period_cover
            phase_valid = phase_hit >= min_phase_cover

            candidates.append({
                "x": x, "y": y,
                "d_sccp": d_sccp,
                "d_trace": d_trace,
                "d_period": d_period,
                "d_phase": d_phase,
                "trace_regions": trace_hit,
                "period_regions": period_hit,
                "phase_regions": phase_hit,
                "period_valid": period_valid,
                "phase_valid": phase_valid
            })

    if not candidates:
        base_metrics["status"] = "无合法候选"
        return base_metrics, None

    # 4. 稳健百分位归一化
    def robust_norm(values):
        arr = np.array(values, dtype=np.float64)
        valid_mask = ~np.isnan(arr)
        valid_vals = arr[valid_mask]
        if len(valid_vals) < 10:
            return np.full_like(arr, np.nan), np.nan, np.nan
        pl = np.percentile(valid_vals, NORM_LOW_P)
        ph = np.percentile(valid_vals, NORM_HIGH_P)
        if ph - pl < 1e-8:
            normed = np.where(valid_mask, 0.0, np.nan)
            return normed, pl, ph
        normed = np.full_like(arr, np.nan)
        normed[valid_mask] = np.clip((valid_vals - pl) / (ph - pl), 0.0, 1.0)
        return normed, pl, ph

    sccp_norm, sccp_p5, sccp_p95 = robust_norm([c["d_sccp"] for c in candidates])
    trace_norm, trace_p5, trace_p95 = robust_norm([c["d_trace"] for c in candidates])
    period_norm, period_p5, period_p95 = robust_norm([c["d_period"] for c in candidates])
    phase_norm, phase_p5, phase_p95 = robust_norm([c["d_phase"] for c in candidates])

    for i, c in enumerate(candidates):
        c["d_sccp_norm"] = float(sccp_norm[i])
        c["d_trace_norm"] = float(trace_norm[i])
        c["d_period_norm"] = float(period_norm[i]) if c["period_valid"] and not np.isnan(period_norm[i]) else np.nan
        c["d_phase_norm"] = float(phase_norm[i]) if c["phase_valid"] and not np.isnan(phase_norm[i]) else np.nan

    # 5. 分阶段统计拒绝原因，再进行纹理准入
    trace_required = max(2, int(np.ceil(len(valid_trace_idx) * MIN_TRACE_COVERAGE)))
    trace_cover_cands = [
        c for c in candidates
        if np.isfinite(c["d_trace"]) and c["trace_regions"] >= trace_required
    ]
    direction_gate_cands = [c for c in trace_cover_cands if c["d_trace"] <= MAX_TRACE_DIFF_DEG]
    period_valid_cands = [
        c for c in candidates if c["period_valid"] and np.isfinite(c["d_period"])
    ]
    period_gate_cands = [c for c in period_valid_cands if c["d_period"] <= MAX_PERIOD_REL_DIFF]
    compatible_cands = [
        c for c in candidates
        if c["period_valid"]
        and np.isfinite(c["d_trace"])
        and c["trace_regions"] >= trace_required
        and c["d_trace"] <= MAX_TRACE_DIFF_DEG
        and np.isfinite(c["d_period"])
        and c["d_period"] <= MAX_PERIOD_REL_DIFF
    ]

    # 6. 三种模式选最优
    best_sccp = min(candidates, key=lambda c: c["d_sccp_norm"])

    if trace_enabled:
        valid_trace_cands = [c for c in candidates if not np.isnan(c["d_trace_norm"])]
        if valid_trace_cands:
            for c in valid_trace_cands:
                c["score_sccpto"] = (1 - LAMBDA_TRACE) * c["d_sccp_norm"] + LAMBDA_TRACE * c["d_trace_norm"]
            best_sccpto = min(valid_trace_cands, key=lambda c: c["score_sccpto"])
        else:
            best_sccpto = best_sccp
    else:
        best_sccpto = best_sccp

    # 方向和周期用于硬准入；相位估计对局部裁剪/旋转更敏感，只作可用时的软评分项。
    fpc_enabled = trace_enabled and period_enabled
    if fpc_enabled:
        # 硬兼容门槛：不允许综合分把明显方向/周期冲突的候选“平均”成可用位置。
        valid_fpc_cands = [c for c in compatible_cands if np.isfinite(c["d_trace_norm"])]
        if valid_fpc_cands:
            w_s = 1 - LAMBDA_TRACE - LAMBDA_PERIOD - LAMBDA_PHASE
            for c in valid_fpc_cands:
                phase_score = c["d_phase_norm"] if np.isfinite(c["d_phase_norm"]) else 0.5
                c["score_fpc"] = (
                    w_s * c["d_sccp_norm"]
                    + LAMBDA_TRACE * c["d_trace_norm"]
                    + LAMBDA_PERIOD * c["d_period_norm"]
                    + LAMBDA_PHASE * phase_score
                )
            best_fpc = min(valid_fpc_cands, key=lambda c: c["score_fpc"])
            fpc_fallback = False
            phase_valid_rate = sum(1 for c in candidates if c["phase_valid"]) / len(candidates)
        else:
            best_fpc = None
            fpc_fallback = True
            phase_valid_rate = 0.0
    else:
        best_fpc = None
        fpc_fallback = True
        phase_valid_rate = 0.0

    if best_fpc is None:
        base_metrics.update({
            "status": "无纹理兼容候选",
            "placement_status": "failed",
            "placement_reason": "无纹理兼容候选",
            "target_image": dst_name,
            "total_candidates": len(candidates),
            "compatible_candidate_count": len(compatible_cands),
            "scoreable_candidate_count": len(valid_fpc_cands) if fpc_enabled else 0,
            "source_trace_regions": len(valid_trace_idx),
            "source_period_regions": len(valid_period_idx),
            "period_support_mode": period_support_mode,
            "trace_coverage_candidate_count": len(trace_cover_cands),
            "direction_gate_candidate_count": len(direction_gate_cands),
            "period_valid_candidate_count": len(period_valid_cands),
            "period_gate_candidate_count": len(period_gate_cands),
            "joint_gate_candidate_count": len(compatible_cands),
            "min_trace_diff_with_coverage_deg": round(min((c["d_trace"] for c in trace_cover_cands), default=np.nan), 4),
            "min_period_rel_diff": round(min((c["d_period"] for c in period_valid_cands), default=np.nan), 4),
            "period_enabled": period_enabled,
            "trace_enabled": trace_enabled,
            "max_trace_diff_deg": MAX_TRACE_DIFF_DEG,
            "max_period_rel_diff": MAX_PERIOD_REL_DIFF,
            "max_phase_diff_cycles": "soft-term-only",
        })
        return base_metrics, {
            "sample_idx": sample_idx,
            "target_image": dst_name,
            "source_period_regions": len(valid_period_idx),
            "period_support_mode": period_support_mode,
            "total_candidates": len(candidates),
            "compatible_candidate_count": len(compatible_cands),
            "scoreable_candidate_count": len(valid_fpc_cands) if fpc_enabled else 0,
            "trace_coverage_candidate_count": len(trace_cover_cands),
            "direction_gate_candidate_count": len(direction_gate_cands),
            "period_valid_candidate_count": len(period_valid_cands),
            "period_gate_candidate_count": len(period_gate_cands),
            "joint_gate_candidate_count": len(compatible_cands),
            "min_trace_diff_with_coverage_deg": round(min((c["d_trace"] for c in trace_cover_cands), default=np.nan), 4),
            "min_period_rel_diff": round(min((c["d_period"] for c in period_valid_cands), default=np.nan), 4),
        }

    def to_dst(cand):
        dx = cand["x"] + offset_x
        dy = cand["y"] + offset_y
        return dx, dy

    dx_sccp, dy_sccp = to_dst(best_sccp)
    dx_sccpto, dy_sccpto = to_dst(best_sccpto)
    dx_fpc, dy_fpc = to_dst(best_fpc)

    # 6. 可视化与融合对照
    diag = dst_color.copy()
    cv2.rectangle(diag, (dx_sccp, dy_sccp), (dx_sccp+sw, dy_sccp+sh), (255,0,0), 2)
    cv2.rectangle(diag, (dx_sccpto, dy_sccpto), (dx_sccpto+sw, dy_sccpto+sh), (0,255,0), 2)
    cv2.rectangle(diag, (dx_fpc, dy_fpc), (dx_fpc+sw, dy_fpc+sh), (0,255,255), 2)
    cv2.putText(diag, "SCCP", (dx_sccp, dy_sccp-8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,0,0), 2)
    cv2.putText(diag, "SCCP-TO", (dx_sccpto, dy_sccpto-8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 2)
    cv2.putText(diag, "+Period+Phase", (dx_fpc, dy_fpc-8), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,255,255), 2)
    cv2.imwrite(os.path.join(sample_dir, "01_placement_compare.jpg"), diag)

    # 融合对照：旧版泊松作为参照；新版本只增加颜色匹配和外缘羽化。
    center_sccpto = (dx_sccpto + sw//2, dy_sccpto + sh//2)
    center_fpc = (dx_fpc + sw//2, dy_fpc + sh//2)
    mask_rect = 255 * np.ones((sh, sw), dtype=np.uint8)

    blend_sccpto_old = cv2.seamlessClone(src_patch_color, dst_color, mask_rect, center_sccpto, cv2.NORMAL_CLONE)
    blend_fpc_old = cv2.seamlessClone(src_patch_color, dst_color, mask_rect, center_fpc, cv2.NORMAL_CLONE)

    src_patch_sccpto = match_patch_lab_to_target(
        src_patch_color, dst_color, (dx_sccpto, dy_sccpto, sw, sh)
    )
    src_patch_fpc = match_patch_lab_to_target(
        src_patch_color, dst_color, (dx_fpc, dy_fpc, sw, sh)
    )
    blend_sccpto = poisson_clone_with_feather(
        src_patch_sccpto, dst_color, (dx_sccpto, dy_sccpto, sw, sh)
    )
    blend_fpc = poisson_clone_with_feather(
        src_patch_fpc, dst_color, (dx_fpc, dy_fpc, sw, sh)
    )

    pad = 40
    crop_w, crop_h = sw + 2*pad, sh + 2*pad
    def fixed_crop(image, bx, by):
        x0,y0=bx-pad,by-pad; x1,y1=x0+crop_w,y0+crop_h
        out=np.zeros((crop_h,crop_w,3),dtype=image.dtype)
        sx0,sy0,sx1,sy1=max(0,x0),max(0,y0),min(dst_w,x1),min(dst_h,y1)
        if sx1>sx0 and sy1>sy0:
            out[sy0-y0:sy1-y0,sx0-x0:sx1-x0]=image[sy0:sy1,sx0:sx1]
        return out
    panels=[fixed_crop(dst_color,dx_sccpto,dy_sccpto),fixed_crop(blend_sccpto,dx_sccpto,dy_sccpto),
            fixed_crop(dst_color,dx_fpc,dy_fpc),fixed_crop(blend_fpc,dx_fpc,dy_fpc)]
    labels=["Original @ TO","Blend @ TO","Original @ FPC","Blend @ FPC"]
    for panel,title in zip(panels,labels):
        cv2.putText(panel,title,(5,20),cv2.FONT_HERSHEY_SIMPLEX,0.45,(0,255,0),1,cv2.LINE_AA)
    compare=np.hstack(panels)
    cv2.imwrite(os.path.join(sample_dir,"02_blend_compare.jpg"),compare)

    # 同一落点下对照旧泊松与新融合，便于直接判断边界色块是否减轻。
    for mode, bx, by, old_img, new_img in [
        ("SCCP_TO", dx_sccpto, dy_sccpto, blend_sccpto_old, blend_sccpto),
        ("SCCP_TO_FPC", dx_fpc, dy_fpc, blend_fpc_old, blend_fpc),
    ]:
        old_new_panels = [
            fixed_crop(dst_color, bx, by),
            fixed_crop(old_img, bx, by),
            fixed_crop(new_img, bx, by),
        ]
        titles = ["Original", "Poisson", "ColorMatch+Feather"]
        for panel, title in zip(old_new_panels, titles):
            cv2.putText(panel, title, (5, 20), cv2.FONT_HERSHEY_SIMPLEX,
                        0.42, (0, 255, 0), 1, cv2.LINE_AA)
        cv2.imwrite(
            os.path.join(sample_dir, f"03_fusion_ab_{mode}.jpg"),
            np.hstack(old_new_panels)
        )

    # 6.5 周期性纹理残差迁移（实验分支，仅迁移异常残差，保留目标自身纹理）
    # 走线「切向」正角（+theta）与 compute_texture_features 内部取 -theta 的约定相反，
    # 不能直接混用。compute_ok / quality_pass / transfer_effective 三字段分开记录，
    # 不允许合并成一个 ok：quality_pass 通过才迁移，transfer_effective 才记录为成功。
    # enable_residual_branch=False 时（小样本两阶段诊断 runner 使用）此处完全跳过，
    # 由诊断 runner 自行组织「阶段A源端mask + 阶段B目标迁移」，不改动选址规则。
    if enable_residual_branch:
        theta_bar, period_bar = aggregate_source_trace_texture(src_region_feats)
        residual_record, residual_images = run_residual_branch(
            source_bgr=src_color,
            src_bbox=src_bbox,
            destination_bgr=dst_color,
            dst_bbox=(dx_fpc, dy_fpc, sw, sh),
            theta_bar=theta_bar,
            period_bar=period_bar,
            src_region_feats=src_region_feats,
            thresholds=RESIDUAL_THRESHOLDS,
            strength=RESIDUAL_STRENGTH,
            sample_id=sample_idx,
            src_image=src_name,
            dst_image=dst_name,
            baseline_fusion_bgr=blend_fpc,
        )
        RESIDUAL_RECORDS.append(residual_record)
        residual_result = residual_images.get("residual_fusion")
        defect_mask = residual_images.get("mask_bin")

        # 残差诊断输出写入新目录（不覆盖 OUTPUT_DIR 的基线结果）
        rdir = os.path.join(RESIDUAL_DIAG_DIR, f"sample_{sample_idx}__target_{Path(dst_name).stem}")
        os.makedirs(rdir, exist_ok=True)
        _save_residual_diag_images(rdir, residual_images)
        if (residual_record.get("transfer_effective")
                and residual_record.get("label_bounds_ok")
                and residual_record.get("new_label_yolo")):
            _write_residual_label_preview(rdir, dst_lbl_path, dst_w, dst_h, residual_record)

        if not residual_record.get("compute_ok"):
            print(f"[residual skip] {residual_record.get('compute_reason')} "
                  f"({residual_record.get('compute_reason_code')}) ", end="")
        elif not residual_record.get("quality_pass"):
            print(f"[residual quality_reject] {residual_record.get('quality_reject_reasons')} ", end="")
        elif not residual_record.get("transfer_effective"):
            print(f"[residual transfer_reject] {residual_record.get('transfer_reason')} ", end="")
        else:
            print(f"[residual OK] new_label={residual_record.get('new_label_yolo')} ", end="")
    else:
        # 诊断 runner 接管残差分支；这里仅留占位记录，保证 metrics 字段齐全。
        theta_bar, period_bar = None, None
        residual_record = fallback_residual_record(
            sample_idx, src_name, dst_name, src_bbox, (dx_fpc, dy_fpc, sw, sh),
            reason="deferred_to_diag_runner", code="deferred",
            thresholds=RESIDUAL_THRESHOLDS)
        residual_result = None
        defect_mask = None

    # 7. 组装统一字段
    shift_px = round(np.sqrt((dx_fpc-dx_sccpto)**2 + (dy_fpc-dy_sccpto)**2), 1)
    metrics = base_metrics.copy()
    metrics.update({
        "status": "成功",
        "placement_status": "ok",
        "placement_reason": "",
        "fusion_method": "LAB_local_match+Poisson+outer_feather",
        "target_image": dst_name,
        "source_trace_regions": len(valid_trace_idx),
        "source_period_regions": len(valid_period_idx),
        "period_support_mode": period_support_mode,
        "source_phase_regions": len(valid_phase_idx),
        "trace_enabled": trace_enabled,
        "period_enabled": period_enabled,
        "phase_enabled": phase_enabled,
        "total_candidates": len(candidates),
        "period_valid_candidate_rate": round(sum(1 for c in candidates if c["period_valid"]) / len(candidates), 4),
        "phase_valid_candidate_rate": round(phase_valid_rate, 4),
        "fpc_fallback": fpc_fallback,
        # SCCP
        "sccp_dst_x": dx_sccp,
        "sccp_dst_y": dy_sccp,
        "sccp_d_sccp": round(best_sccp["d_sccp"], 6),
        # SCCP-TO
        "sccpto_dst_x": dx_sccpto,
        "sccpto_dst_y": dy_sccpto,
        "sccpto_d_sccp": round(best_sccpto["d_sccp"], 6),
        "sccpto_d_trace": round(best_sccpto["d_trace"], 6) if not np.isnan(best_sccpto["d_trace"]) else "",
        "sccpto_d_sccp_norm": round(best_sccpto["d_sccp_norm"], 6),
        "sccpto_d_trace_norm": round(best_sccpto["d_trace_norm"], 6) if not np.isnan(best_sccpto["d_trace_norm"]) else "",
        "sccpto_weighted_sccp": round((1-LAMBDA_TRACE)*best_sccpto["d_sccp_norm"], 6),
        "sccpto_weighted_trace": round(LAMBDA_TRACE*best_sccpto["d_trace_norm"], 6) if not np.isnan(best_sccpto["d_trace_norm"]) else "",
        # FPC全项
        "fpc_dst_x": dx_fpc,
        "fpc_dst_y": dy_fpc,
        "fpc_d_sccp": round(best_fpc["d_sccp"], 6),
        "fpc_d_trace": round(best_fpc["d_trace"], 6) if not np.isnan(best_fpc["d_trace"]) else "",
        "fpc_d_period": round(best_fpc["d_period"], 6) if not np.isnan(best_fpc["d_period"]) else "",
        "fpc_d_phase": round(best_fpc["d_phase"], 6) if not np.isnan(best_fpc["d_phase"]) else "",
        "fpc_d_sccp_norm": round(best_fpc["d_sccp_norm"], 6),
        "fpc_d_trace_norm": round(best_fpc["d_trace_norm"], 6) if not np.isnan(best_fpc["d_trace_norm"]) else "",
        "fpc_d_period_norm": round(best_fpc["d_period_norm"], 6) if not np.isnan(best_fpc["d_period_norm"]) else "",
        "fpc_d_phase_norm": round(best_fpc["d_phase_norm"], 6) if not np.isnan(best_fpc["d_phase_norm"]) else "",
        "fpc_weighted_sccp": round((1-LAMBDA_TRACE-LAMBDA_PERIOD-LAMBDA_PHASE)*best_fpc["d_sccp_norm"], 6),
        "fpc_weighted_trace": round(LAMBDA_TRACE*best_fpc["d_trace_norm"], 6) if not np.isnan(best_fpc["d_trace_norm"]) else "",
        "fpc_weighted_period": round(LAMBDA_PERIOD*best_fpc["d_period_norm"], 6) if not np.isnan(best_fpc["d_period_norm"]) else "",
        "fpc_weighted_phase": round(LAMBDA_PHASE*best_fpc["d_phase_norm"], 6) if not np.isnan(best_fpc["d_phase_norm"]) else "",
        "fpc_vs_sccpto_shift_px": shift_px,
        "fpc_phase_regions": best_fpc["phase_regions"],
        "compatible_candidate_count": len(valid_fpc_cands) if fpc_enabled else 0,
        "max_trace_diff_deg": MAX_TRACE_DIFF_DEG,
        "max_period_rel_diff": MAX_PERIOD_REL_DIFF,
        "max_phase_diff_cycles": "soft-term-only",
        "fpc_local_score": round(best_fpc["score_fpc"], 6) if "score_fpc" in best_fpc else "",
        # 残差迁移诊断（compute_ok / quality_pass / transfer_effective 三字段分离）
        "residual_trace_angle_deg": "" if theta_bar is None else round(theta_bar, 3),
        "residual_period_px": "" if period_bar is None else round(period_bar, 3),
        "residual_ok": bool(residual_record.get("compute_ok")),
        "residual_reason": residual_record.get("compute_reason", ""),
        "residual_reason_code": residual_record.get("compute_reason_code", ""),
        "residual_quality_pass": bool(residual_record.get("quality_pass")),
        "residual_quality_reject_reasons": residual_record.get("quality_reject_reasons", ""),
        "residual_transfer_effective": bool(residual_record.get("transfer_effective")),
        "residual_transfer_reason": residual_record.get("transfer_reason", ""),
        "residual_baseline_fallback": bool(residual_record.get("baseline_fallback")),
        "residual_fallback_reason": residual_record.get("fallback_reason", ""),
        "residual_placement_status": residual_record.get("placement_status", ""),
        "residual_placement_reason": residual_record.get("placement_reason", ""),
        "residual_source_feature_status": residual_record.get("source_feature_status", ""),
        "residual_source_feature_reason": residual_record.get("source_feature_reason", ""),
        "residual_source_mask_compute_ok": bool(residual_record.get("source_mask_compute_ok")),
        "residual_source_mask_compute_reason": residual_record.get("source_mask_compute_reason", ""),
        "residual_source_mask_quality_pass": bool(residual_record.get("source_mask_quality_pass")),
        "residual_source_mask_quality_reasons": residual_record.get("source_mask_quality_reasons", ""),
        "residual_mask_ratio": residual_record.get("mask_area_ratio", ""),
        "residual_coverage": residual_record.get("coverage", ""),
        "residual_reference_uncertainty": residual_record.get("reference_uncertainty", ""),
        "residual_largest_component_ratio": residual_record.get("largest_component_ratio", ""),
        "residual_mask_span_w_ratio": residual_record.get("mask_span_w_ratio", ""),
        "residual_mask_span_h_ratio": residual_record.get("mask_span_h_ratio", ""),
        "residual_edge_touch_ratio": residual_record.get("edge_touch_ratio", ""),
        "residual_delta_median_all": residual_record.get("delta_median_all", ""),
        "residual_delta_p95_all": residual_record.get("delta_p95_all", ""),
        "residual_delta_median_changed": residual_record.get("delta_median_changed", ""),
        "residual_delta_p95_changed": residual_record.get("delta_p95_changed", ""),
        "residual_modified_pixel_ratio": residual_record.get("modified_pixel_ratio", ""),
        "residual_new_label_bbox_px": residual_record.get("new_label_bbox_px", ""),
        "residual_new_label_yolo": residual_record.get("new_label_yolo", ""),
        "residual_label_bounds_ok": residual_record.get("label_bounds_ok", ""),
        "residual_strength": RESIDUAL_STRENGTH,
    })

    dist_stats = {
        "sample_idx": sample_idx,
        "target_image": dst_name,
        "total_candidates": len(candidates),
        "sccp_p5": round(sccp_p5, 6),
        "sccp_p95": round(sccp_p95, 6),
        "trace_p5": round(trace_p5, 6) if not np.isnan(trace_p5) else "",
        "trace_p95": round(trace_p95, 6) if not np.isnan(trace_p95) else "",
        "period_p5": round(period_p5, 6) if not np.isnan(period_p5) else "",
        "period_p95": round(period_p95, 6) if not np.isnan(period_p95) else "",
        "phase_p5": round(phase_p5, 6) if not np.isnan(phase_p5) else "",
        "phase_p95": round(phase_p95, 6) if not np.isnan(phase_p95) else "",
        "trace_coverage_candidate_count": len(trace_cover_cands),
        "direction_gate_candidate_count": len(direction_gate_cands),
        "period_valid_candidate_count": len(period_valid_cands),
        "period_gate_candidate_count": len(period_gate_cands),
        "joint_gate_candidate_count": len(compatible_cands),
        "min_trace_diff_with_coverage_deg": round(min((c["d_trace"] for c in trace_cover_cands), default=np.nan), 4),
        "min_period_rel_diff": round(min((c["d_period"] for c in period_valid_cands), default=np.nan), 4),
    }

    return metrics, dist_stats


def run_placement_sample(sample_row):
    """在多个背景图中搜索；无纹理兼容候选时明确跳过，不强行粘贴。"""
    src_name = sample_row["src_image"]
    preferred_dst = sample_row.get("dst_image", "")
    all_names = sorted(
        p.name for p in Path(TRAIN_IMG_DIR).iterdir()
        if p.is_file() and p.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}
    )
    src_key = os.path.normcase(os.path.basename(src_name))
    pool = [n for n in all_names if os.path.normcase(n) != src_key]
    if not pool:
        return {"sample_idx": sample_row.get("sample_idx"), "status": "无其他目标背景图"}, None

    # 保留 CSV 指定目标图，并用样本索引固定随机种子补充其他背景，保证本次候选池可复现。
    chosen = []
    if preferred_dst and os.path.basename(preferred_dst) in pool:
        chosen.append(os.path.basename(preferred_dst))
    remaining = [n for n in pool if n not in chosen]
    rng = random.Random(int(sample_row.get("sample_idx", 0)))
    take = max(0, min(TARGET_POOL_SIZE, len(pool)) - len(chosen))
    if take:
        chosen.extend(rng.sample(remaining, take))

    attempts = []
    distributions = []
    for dst_name in chosen:
        result, dist = _run_placement_for_target(sample_row, dst_name)
        if result:
            attempts.append(result)
        if dist:
            distributions.append(dist)

    good = [r for r in attempts if r.get("status") == "成功"]
    if not good:
        attempt_dist = {
            "sample_idx": sample_row.get("sample_idx"),
            "target_pool_size": len(chosen),
            "target_pool_images": ";".join(chosen),
            "trace_coverage_candidate_count": sum(int(r.get("trace_coverage_candidate_count", 0) or 0) for r in attempts),
            "direction_gate_candidate_count": sum(int(r.get("direction_gate_candidate_count", 0) or 0) for r in attempts),
            "period_valid_candidate_count": sum(int(r.get("period_valid_candidate_count", 0) or 0) for r in attempts),
            "period_gate_candidate_count": sum(int(r.get("period_gate_candidate_count", 0) or 0) for r in attempts),
            "joint_gate_candidate_count": sum(int(r.get("joint_gate_candidate_count", 0) or 0) for r in attempts),
            "target_attempt_diagnostics": ";".join(
                f"{r.get('target_image','')}:trace_cov={r.get('trace_coverage_candidate_count',0)}"
                f",source_period_regions={r.get('source_period_regions','')}"
                f",period_support={r.get('period_support_mode','')}"
                f",angle_ok={r.get('direction_gate_candidate_count',0)}"
                f",period_valid={r.get('period_valid_candidate_count',0)}"
                f",period_ok={r.get('period_gate_candidate_count',0)}"
                f",joint={r.get('joint_gate_candidate_count',0)}"
                f",scoreable={r.get('scoreable_candidate_count',0)}"
                f",min_angle={r.get('min_trace_diff_with_coverage_deg','')}"
                f",min_period={r.get('min_period_rel_diff','')}"
                for r in attempts
            ),
        }
        return {
            "sample_idx": sample_row.get("sample_idx"),
            "status": "多背景池无纹理兼容候选",
            "target_pool_size": len(chosen),
            "target_pool_images": ";".join(chosen),
            "target_pool_attempts": ";".join(f"{r.get('target_image','')}={r.get('status','')}:{r.get('compatible_candidate_count',0)}" for r in attempts),
        }, attempt_dist

    # 跨背景比较时，对各背景的局部最优解统一归一化，避免直接比较不同图像的原始梯度尺度。
    keys = ["fpc_d_sccp", "fpc_d_trace", "fpc_d_period", "fpc_d_phase"]
    arrays = {}
    for key in keys:
        vals = np.asarray([
            float(r[key]) if r.get(key, "") not in ("", None) and np.isfinite(float(r[key])) else np.nan
            for r in good
        ], dtype=np.float64)
        valid = np.isfinite(vals)
        normed = np.full(len(vals), 0.5, dtype=np.float64)  # 缺失分项按中性值处理，不奖励缺失
        if valid.any():
            lo, hi = float(vals[valid].min()), float(vals[valid].max())
            normed[valid] = 0.0 if hi - lo < 1e-12 else (vals[valid] - lo) / (hi - lo)
        arrays[key] = normed
    weights = (1 - LAMBDA_TRACE - LAMBDA_PERIOD - LAMBDA_PHASE,
               LAMBDA_TRACE, LAMBDA_PERIOD, LAMBDA_PHASE)
    for i, r in enumerate(good):
        r["multi_bg_score"] = float(sum(w * arrays[k][i] for w, k in zip(weights, keys)))
    winner = min(good, key=lambda r: r["multi_bg_score"])
    winner["target_pool_size"] = len(chosen)
    winner["target_pool_images"] = ";".join(chosen)
    winner["target_pool_compatible_images"] = ";".join(r["target_image"] for r in good)
    winner["target_pool_attempts"] = ";".join(
        f"{r.get('target_image','')}={r.get('status','')}:{r.get('compatible_candidate_count',0)}" for r in attempts
    )
    winner["multi_bg_score"] = round(winner["multi_bg_score"], 6)
    return winner, next((d for d in distributions if d.get("target_image") == winner.get("target_image")), None)


# ==================================================
# 主流程
# ==================================================
def main():
    print("=" * 70)
    print("SCCP-TO-FPC V1.4.3 软过渡融合版（诊断用途）")
    print("=" * 70)
    print(f"固定权重：λtrace={LAMBDA_TRACE}, λperiod={LAMBDA_PERIOD}, λphase={LAMBDA_PHASE}")
    print(f"多背景池：最多{TARGET_POOL_SIZE}张；准入条件：方向≤{MAX_TRACE_DIFF_DEG:.1f}°且方向有效区覆盖≥{MIN_TRACE_COVERAGE:.0%}、周期相对差≤{MAX_PERIOD_REL_DIFF:.2f}；相位仅作软评分")
    print(f"板边判定阈值：边界相连白色占比 > {EDGE_CONNECTED_WHITE_MAX*100:.0f}% 淘汰")
    print()

    with open(INPUT_CSV, 'r', encoding='utf-8-sig') as f:
        samples = list(csv.DictReader(f))
    print(f"待处理样本数：{len(samples)}")
    print()

    all_metrics = []
    all_dist = []
    patch_reject = 0
    fpc_fallback_count = 0
    position_changed = 0

    for row in samples:
        idx = row["sample_idx"]
        print(f"样本 {idx} ... ", end="")
        metrics, dist = run_placement_sample(row)
        all_metrics.append(metrics)
        if dist:
            all_dist.append(dist)

        if metrics["status"] == "源patch无效":
            patch_reject += 1
            print(f"淘汰 - {metrics['fail_reason']}")
        elif metrics["status"] == "成功":
            if metrics["fpc_fallback"]:
                fpc_fallback_count += 1
            if metrics["fpc_vs_sccpto_shift_px"] > 1:
                position_changed += 1
            print(f"完成，落点偏移{metrics['fpc_vs_sccpto_shift_px']}像素")
        else:
            print(metrics["status"])

    # 统一字段写入CSV
    all_fields = set()
    for row in all_metrics:
        all_fields.update(row.keys())
    fieldnames = sorted(list(all_fields))

    metrics_csv = os.path.join(OUTPUT_DIR, "experiment_metrics.csv")
    with open(metrics_csv, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_metrics)

    if all_dist:
        dist_fields = set()
        for row in all_dist:
            dist_fields.update(row.keys())
        dist_fieldnames = sorted(list(dist_fields))
        dist_csv = os.path.join(OUTPUT_DIR, "candidate_distribution_stats.csv")
        with open(dist_csv, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.DictWriter(f, fieldnames=dist_fieldnames)
            writer.writeheader()
            writer.writerows(all_dist)

    # 残差分支逐样本诊断 CSV（compute_ok / quality_pass / transfer_effective 分列）
    if RESIDUAL_RECORDS:
        write_residual_diagnosis_csv(RESIDUAL_RECORDS, RESIDUAL_CSV)
        residual_pass = sum(1 for r in RESIDUAL_RECORDS
                            if r.get("quality_pass") and r.get("transfer_effective"))
        residual_quality_pass = sum(1 for r in RESIDUAL_RECORDS if r.get("quality_pass"))
        residual_compute_ok = sum(1 for r in RESIDUAL_RECORDS if r.get("compute_ok"))
        print()
        print(f"残差分支诊断：记录数={len(RESIDUAL_RECORDS)}，"
              f"compute_ok={residual_compute_ok}，quality_pass={residual_quality_pass}，"
              f"transfer_effective={residual_pass}")
        print(f"残差诊断CSV：{RESIDUAL_CSV}")

    # 代码差异说明
    diff_path = os.path.join(OUTPUT_DIR, "code_diff_v143_soft_fusion.txt")
    with open(diff_path, 'w', encoding='utf-8') as f:
        f.write("V1.4.3 多背景候选与软过渡融合修正\n")
        f.write("=" * 60 + "\n\n")
        f.write("1. 板边筛查修正\n")
        f.write("  - 仅统计源bbox patch内像素，不使用整图比例\n")
        f.write("  - 连通域分析：区分边界相连板外区域（红）和内部丝印区域（蓝）\n")
        f.write("  - 淘汰规则：仅边界相连白色占比超标判定跨板边；内部高占比白色为丝印，保留\n")
        f.write("  - 统一字段名 patch_white_ratio_pct，淘汰样本同字段写入\n\n")
        f.write("2. 相位计算修正\n")
        f.write("  - 采用互相关峰值位移法计算相位差，范围[0, 0.5]，越小越好\n")
        f.write("  - 不再使用最大互相关值冒充相位差\n\n")
        f.write("3. 统计补全\n")
        f.write("  - 新增 phase_valid_candidate_rate、source_phase_regions、fpc_phase_regions\n")
        f.write("  - 新增各分项加权贡献值\n")
        f.write("  - 报告写入完整评分公式\n\n")
        f.write("4. 评分公式（均为归一化后距离，越小越优）\n")
        f.write(f"  score = (1-λt-λp-λph) * D_sccp + λt * D_trace + λp * D_period + λph * D_phase\n")
        f.write(f"  λt={LAMBDA_TRACE}, λp={LAMBDA_PERIOD}, λph={LAMBDA_PHASE}\n\n")
        f.write("5. 多背景候选池\n")
        f.write(f"  - 每个源样本最多检索{TARGET_POOL_SIZE}张目标图；包含CSV指定目标图并用样本索引固定随机补充\n")
        f.write(f"  - 目标图逐张排除源图自身，并按现有目标缺陷框与安全边距构造合法区域\n")
        f.write(f"  - 先要求加权轴向差≤{MAX_TRACE_DIFF_DEG}°、方向有效区覆盖≥{MIN_TRACE_COVERAGE:.0%}、周期相对差≤{MAX_PERIOD_REL_DIFF}\n")
        f.write("  - 相位仅在可用时作为软评分项；多背景池无合格候选时跳过，不回退到不兼容位置\n\n")
        f.write("  - 新增按方向覆盖、方向门槛、周期有效、周期门槛、联合门槛分阶段计数\n")
        f.write("  - 对无合格候选样本也写出 candidate_distribution_stats.csv，报告拒绝阶段和最小方向/周期差\n\n")
        f.write("6. 源端周期支持\n")
        f.write("  - 源端有效周期区≥3标记为full，1-2标记为limited，0则关闭方向+周期模式\n")
        f.write("  - limited模式仍须通过逐候选方向/周期硬门槛；结果表显式记录period_support_mode\n\n")
        f.write("7. 融合边界优化\n")
        f.write("  - 保留旧版整矩形泊松输出作为对照\n")
        f.write("  - 新版先按源patch外圈与目标框外围的LAB稳健统计做温和颜色匹配\n")
        f.write("  - 泊松融合后仅对patch外缘羽化，中心区域保持原融合结果\n")
        f.write("  - 输出03_fusion_ab_SCCP_TO.jpg与03_fusion_ab_SCCP_TO_FPC.jpg作同落点对照\n\n")

    # 实验报告
    report_path = os.path.join(OUTPUT_DIR, "experiment_report.txt")
    valid_samples = [m for m in all_metrics if m["status"] == "成功"]
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("SCCP-TO-FPC V1.4.3 软过渡融合版（诊断用途）\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"总样本数：{len(all_metrics)}\n")
        f.write(f"源patch淘汰数：{patch_reject}\n")
        f.write(f"有效完成数：{len(valid_samples)}\n")
        f.write(f"FPC模式回退数：{fpc_fallback_count}\n")
        f.write(f"落点发生变化样本数：{position_changed}\n\n")
        f.write(f"每样本目标背景上限：{TARGET_POOL_SIZE}\n")
        f.write(f"方向准入阈值：{MAX_TRACE_DIFF_DEG}°；方向区覆盖：{MIN_TRACE_COVERAGE:.0%}\n")
        f.write(f"周期准入阈值：相对差≤{MAX_PERIOD_REL_DIFF}；相位作为软项\n\n")
        f.write("源端周期支持：≥3个有效区域为full，1-2个为limited，0个时不启用周期匹配\n\n")
        f.write("融合：旧版Poisson与LAB颜色匹配+Poisson+外缘羽化并行输出；仅用于小样本目视对照\n\n")

        f.write("一、板边筛查结论\n")
        f.write("-" * 40 + "\n")
        f.write("1. 仅统计源bbox patch内像素，未使用整图比例\n")
        f.write("2. 通过连通域区分边界相连板外区域和内部分散丝印\n")
        f.write("3. 仅边界相连白色占比超标的样本判定跨板边淘汰\n")
        f.write("4. 样本2：若内部白色占比高但边界占比低，属于丝印误判，已修正为保留\n\n")

        f.write("二、相位指标说明\n")
        f.write("-" * 40 + "\n")
        f.write("1. 计算方法：互相关峰值位移 / 估计周期，取最小相位差\n")
        f.write("2. 取值范围：[0, 0.5]，数值越小表示相位对齐越好\n")
        f.write("3. 为距离型指标，和方向差、周期差口径一致，均为越小越优\n\n")

        f.write("三、评分公式\n")
        f.write("-" * 40 + "\n")
        f.write("所有分项先做5/95百分位稳健归一化到[0,1]，再加权求和：\n")
        f.write(f"score = (1-{LAMBDA_TRACE}-{LAMBDA_PERIOD}-{LAMBDA_PHASE}) * D_sccp_norm\n")
        f.write(f"        + {LAMBDA_TRACE} * D_trace_norm\n")
        f.write(f"        + {LAMBDA_PERIOD} * D_period_norm\n")
        f.write(f"        + {LAMBDA_PHASE} * D_phase_norm\n")
        f.write("分数越低表示整体匹配度越好\n\n")

        f.write("四、边界声明\n")
        f.write("-" * 40 + "\n")
        f.write("0. 本脚本 d_sccp 是分区平均梯度幅值差代理，不是原论文 SCCP 评分器；结果仅供诊断\n")
        f.write("1. 权重为固定实验值，未基于本次样本调参\n")
        f.write("2. 落点变化不代表合成质量提升，需结合融合图目视判断\n")
        f.write("3. 仅5组小样本，不足以证明模块整体有效\n")
        f.write("4. 不扩量、不训练检测器、不写入论文结论\n\n")

        f.write("五、输出文件\n")
        f.write("-" * 40 + "\n")
        f.write(f"- 逐样本指标：{metrics_csv}\n")
        f.write(f"- 候选分布统计：{dist_csv if all_dist else '无'}\n")
        f.write(f"- 代码修正说明：{diff_path}\n")
        f.write(f"- 各样本目录：{OUTPUT_DIR}/sample_XX/\n")
        f.write("  00_patch_edge_check.jpg   板边筛查可视化（红=板外，蓝=丝印）\n")
        f.write("  01_placement_compare.jpg  三种模式选址对照\n")
        f.write("  02_blend_compare.jpg      融合效果对照\n")
        f.write("  03_fusion_ab_SCCP_TO.jpg  TO同落点旧/新融合对照\n")
        f.write("  03_fusion_ab_SCCP_TO_FPC.jpg  TO-FPC同落点旧/新融合对照\n")
        f.write(f"- 本报告：{report_path}\n")

    print()
    print("=" * 70)
    print("实验完成")
    print(f"输出目录：{OUTPUT_DIR}")
    print(f"逐样本指标：{metrics_csv}")
    print(f"报告：{report_path}")
    print()
    print(f"源patch淘汰：{patch_reject}/5")
    print(f"FPC回退：{fpc_fallback_count}/5")
    print(f"落点变化：{position_changed}/5")
    if RESIDUAL_RECORDS:
        _rp = sum(1 for r in RESIDUAL_RECORDS if r.get("quality_pass") and r.get("transfer_effective"))
        _rq = sum(1 for r in RESIDUAL_RECORDS if r.get("quality_pass"))
        _rc = sum(1 for r in RESIDUAL_RECORDS if r.get("compute_ok"))
        print(f"残差分支：compute_ok={_rc}/{len(RESIDUAL_RECORDS)}，"
              f"quality_pass={_rq}/{len(RESIDUAL_RECORDS)}，"
              f"transfer_effective={_rp}/{len(RESIDUAL_RECORDS)}")
        print(f"残差诊断目录：{RESIDUAL_DIAG_DIR}")
        print(f"残差诊断CSV：{RESIDUAL_CSV}")
    print("样本1、4均含选址图与融合对照图，可目视对比")


if __name__ == "__main__":
    main()
