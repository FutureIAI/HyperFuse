# -*- coding: utf-8 -*-
"""SCCP-TO-FPC 全训练集全局选址。

与 yuhua.py 的差异仅在搜索范围与归一化作用域：
- 遍历 TRAIN_IMG_DIR 下全部背景图（按 basename 排除源图，即不会贴回原图），
- 对每张图的全部合法窗口（valid_mask 全真的粗步长窗口）计算四项距离，
- 收集所有通过方向+周期硬门槛的合格窗口，作为一个并集，
- 在并集上分别按第 5/95 百分位归一化（相位项只在相位有效的合格窗口上统计，不足 10 个统一 0.5），
- 在并集上取综合分最低的位置。

无损失加速：方向门槛不合格的窗口不进入周期/相位计算（周期门槛独立判定，
合格集合不变），并把源端各区分量幅值均值预计算一次。
"""
import os
import math
import cv2
import numpy as np
from pathlib import Path

import poisson_fusion as Y

IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def list_train_images():
    return sorted(
        p.name for p in Path(Y.TRAIN_IMG_DIR).iterdir()
        if p.is_file() and p.suffix.lower() in IMAGE_SUFFIXES
    )


def prepare_source(sample_row):
    """源端特征、窗口几何、门槛一次性准备（每样本只做一次）。"""
    sx = int(float(sample_row["src_bbox_x"]))
    sy = int(float(sample_row["src_bbox_y"]))
    sw = int(float(sample_row["src_bbox_w"]))
    sh = int(float(sample_row["src_bbox_h"]))
    src_bbox = (sx, sy, sw, sh)

    src_path = os.path.join(Y.TRAIN_IMG_DIR, sample_row["src_image"])
    src_color = cv2.imread(src_path)
    if src_color is None:
        return None
    src_gray = cv2.cvtColor(src_color, cv2.COLOR_BGR2GRAY)
    src_gx, src_gy, _, _ = Y.precompute_gradient_full(src_gray)
    src_h, src_w = src_gray.shape

    m = max(Y.MIN_MARGIN, int(Y.MARGIN_RATIO * min(sw, sh)))
    src_regions, ex1s, ey1s, ex2s, ey2s, offset_x, offset_y = Y.extract_8_regions(
        src_bbox, m, src_h, src_w
    )
    win_w = ex2s - ex1s
    win_h = ey2s - ey1s

    patch_color = src_color[sy:sy + sh, sx:sx + sw].copy()
    patch_valid, patch_reason, patch_stats, _ = Y.check_pcb_edge_refined(patch_color)
    if not patch_valid:
        return {"invalid": True, "reason": patch_reason, "patch_stats": patch_stats}

    feats, valid_trace_idx, valid_period_idx, valid_phase_idx = [], [], [], []
    mag_means = [np.nan] * 8
    for i, (mask, _name, valid, _m) in enumerate(src_regions):
        if not valid:
            feats.append({"valid": False})
            continue
        r_gx = src_gx[ey1s:ey2s, ex1s:ex2s][mask]
        r_gy = src_gy[ey1s:ey2s, ex1s:ex2s][mask]
        theta, coh = Y.compute_region_trace_feat(r_gx, r_gy)
        theta_deg = np.degrees(theta) % 180
        trace_ok = coh >= Y.COH_THRESH
        region_gray = src_gray[ey1s:ey2s, ex1s:ex2s].copy()
        _, period, period_conf, _, proj_ref = Y.compute_texture_features(
            region_gray, theta_deg, region_mask=mask)
        period_ok = period_conf >= Y.PERIOD_CONF_THRESH and not np.isnan(period)
        mag_means[i] = float(np.mean(np.sqrt(r_gx ** 2 + r_gy ** 2)))
        feats.append({
            "valid": True, "theta_deg": theta_deg, "coherence": coh,
            "trace_ok": trace_ok, "period": period, "period_conf": period_conf,
            "period_ok": period_ok, "proj_ref": proj_ref,
        })
        if trace_ok:
            valid_trace_idx.append(i)
        if period_ok:
            valid_period_idx.append(i)
            valid_phase_idx.append(i)

    return {
        "invalid": False,
        "src_bbox": src_bbox, "sw": sw, "sh": sh,
        "src_color": src_color, "src_gray": src_gray,
        "src_gx": src_gx, "src_gy": src_gy,
        "src_regions": src_regions, "feats": feats, "mag_means": mag_means,
        "ex1s": ex1s, "ey1s": ey1s, "ex2s": ex2s, "ey2s": ey2s,
        "offset_x": offset_x, "offset_y": offset_y,
        "win_w": win_w, "win_h": win_h,
        "valid_trace_idx": valid_trace_idx,
        "valid_period_idx": valid_period_idx,
        "valid_phase_idx": valid_phase_idx,
        "trace_enabled": len(valid_trace_idx) >= 2,
        "period_enabled": len(valid_period_idx) >= 1,
        "trace_required": max(2, int(np.ceil(len(valid_trace_idx) * Y.MIN_TRACE_COVERAGE))),
        "min_period_cover": max(1, int(np.ceil(len(valid_period_idx) * Y.CANDIDATE_COVERAGE))),
        "min_phase_cover": max(1, int(np.ceil(len(valid_phase_idx) * Y.CANDIDATE_COVERAGE))),
        "patch_stats": patch_stats,
    }


def eval_target(pack, dst_name, collect_eligible=True):
    """评估单张背景图：返回 (合格窗口列表, 诊断计数)。不含周期计算的窗口即方向不合格窗口。"""
    dst_path = os.path.join(Y.TRAIN_IMG_DIR, dst_name)
    dst_color = cv2.imread(dst_path)
    if dst_color is None:
        return [], {"target_image": dst_name, "status": "读取失败"}

    dst_gray = cv2.cvtColor(dst_color, cv2.COLOR_BGR2GRAY)
    dst_h, dst_w = dst_gray.shape
    dst_gx, dst_gy, _, _ = Y.precompute_gradient_full(dst_gray)
    dst_bboxes = Y.load_bboxes(
        os.path.join(Y.TRAIN_LBL_DIR, os.path.splitext(dst_name)[0] + ".txt"), dst_w, dst_h)
    valid_mask = Y.build_valid_mask(dst_h, dst_w, dst_bboxes, Y.SAFE_MARGIN)
    valid_mask = valid_mask & Y.build_board_white_mask(dst_color)

    win_w, win_h = pack["win_w"], pack["win_h"]
    max_x = dst_w - win_w - Y.SAFE_MARGIN
    max_y = dst_h - win_h - Y.SAFE_MARGIN
    if max_x < Y.SAFE_MARGIN or max_y < Y.SAFE_MARGIN:
        return [], {"target_image": dst_name, "status": "窗口超出目标图", "total": 0}

    feats = pack["feats"]
    mag_means = pack["mag_means"]
    regions = pack["src_regions"]
    ex1s, ey1s, ex2s, ey2s = pack["ex1s"], pack["ey1s"], pack["ex2s"], pack["ey2s"]
    trace_required = pack["trace_required"]
    min_period_cover = pack["min_period_cover"]
    min_phase_cover = pack["min_phase_cover"]

    eligible = []
    total = 0
    trace_pass = 0
    period_pass = 0
    for y in range(Y.SAFE_MARGIN, max_y + 1, Y.COARSE_STRIDE):
        for x in range(Y.SAFE_MARGIN, max_x + 1, Y.COARSE_STRIDE):
            if not valid_mask[y:y + win_h, x:x + win_w].all():
                continue
            total += 1
            d_sccp = 0.0
            d_trace = 0.0
            trace_hit = 0
            trace_weight_sum = 0.0

            for i in range(8):
                feat = feats[i]
                if not feat["valid"]:
                    continue
                mask = regions[i][0]
                dst_r_gx = dst_gx[y:y + win_h, x:x + win_w][mask]
                dst_r_gy = dst_gy[y:y + win_h, x:x + win_w][mask]
                dst_theta, dst_coh = Y.compute_region_trace_feat(dst_r_gx, dst_r_gy)
                dst_theta_deg = np.degrees(dst_theta) % 180
                dst_mag = np.sqrt(dst_r_gx ** 2 + dst_r_gy ** 2)
                d_sccp += abs(mag_means[i] - float(np.mean(dst_mag)))
                if feat["trace_ok"] and dst_coh >= Y.COH_THRESH:
                    raw_diff = abs(feat["theta_deg"] - dst_theta_deg) % 180.0
                    axial_diff = min(raw_diff, 180.0 - raw_diff)
                    w = min(float(feat["coherence"]), float(dst_coh))
                    d_trace += axial_diff * w
                    trace_weight_sum += w
                    trace_hit += 1
            d_sccp /= 8.0
            if trace_weight_sum > 0:
                d_trace /= trace_weight_sum

            # 方向硬门槛：不通过则该窗口不可能进入合格并集（周期门槛独立判定，故跳过周期计算无损）
            if trace_hit < trace_required or not np.isfinite(d_trace) or d_trace > Y.MAX_TRACE_DIFF_DEG:
                continue
            trace_pass += 1

            period_diffs = []
            phase_diffs = []
            for i in range(8):
                feat = feats[i]
                if not feat["valid"] or not feat["period_ok"]:
                    continue
                mask = regions[i][0]
                dst_r_gx = dst_gx[y:y + win_h, x:x + win_w][mask]
                dst_r_gy = dst_gy[y:y + win_h, x:x + win_w][mask]
                dst_theta, _coh = Y.compute_region_trace_feat(dst_r_gx, dst_r_gy)
                dst_theta_deg = np.degrees(dst_theta) % 180
                dst_region = dst_gray[y:y + win_h, x:x + win_w].copy()
                _, dst_period, dst_period_conf, dst_phase_diff, _ = Y.compute_texture_features(
                    dst_region, dst_theta_deg, src_proj_ref=feat["proj_ref"],
                    region_mask=mask, reference_period=feat["period"])
                if dst_period_conf >= Y.PERIOD_CONF_THRESH and not np.isnan(dst_period):
                    pdiff = abs(feat["period"] - dst_period) / (feat["period"] + 1e-8)
                    period_diffs.append(min(pdiff, 1.0))
                    if not np.isnan(dst_phase_diff):
                        phase_diffs.append(dst_phase_diff)

            if len(period_diffs) < min_period_cover:
                continue
            d_period = float(np.mean(period_diffs))
            if d_period > Y.MAX_PERIOD_REL_DIFF:
                continue
            period_pass += 1

            if not collect_eligible:
                continue
            eligible.append({
                "target_image": dst_name, "x": x, "y": y,
                "d_sccp": float(d_sccp), "d_trace": float(d_trace),
                "d_period": d_period,
                "d_phase": float(np.mean(phase_diffs)) if len(phase_diffs) >= min_phase_cover else np.nan,
                "phase_regions": len(phase_diffs),
            })

    diag = {"target_image": dst_name, "status": "ok", "total": total,
            "trace_pass": trace_pass, "period_pass": period_pass}
    return eligible, diag


def _robust_norm(vals):
    """返回 (归一化数组, p5, p95)；有效值不足 10 个时返回全 NaN（该分项不归一化）。"""
    arr = np.asarray(vals, dtype=np.float64)
    valid = np.isfinite(arr)
    if valid.sum() < 10:
        return np.full(arr.shape, np.nan), np.nan, np.nan
    lo = float(np.percentile(arr[valid], Y.NORM_LOW_P))
    hi = float(np.percentile(arr[valid], Y.NORM_HIGH_P))
    if hi - lo < 1e-8:
        out = np.full(arr.shape, np.nan)
        out[valid] = 0.0
        return out, lo, hi
    out = np.full(arr.shape, np.nan)
    out[valid] = np.clip((arr[valid] - lo) / (hi - lo), 0.0, 1.0)
    return out, lo, hi


_WORKER_PACK = None


def _init_worker(pack):
    global _WORKER_PACK
    _WORKER_PACK = pack
    try:
        cv2.setNumThreads(1)  # 避免与多进程争抢线程，显著提升吞吐
    except Exception:
        pass


def _worker_task(dst_name):
    return eval_target(_WORKER_PACK, dst_name)


def search_all_parallel(sample_row, workers=8, pool=None):
    """与 search_all 同口径，按背景图并行评估（结果与串行一致）。"""
    pack = prepare_source(sample_row)
    if pack is None:
        return {"status": "源图读取失败"}, None
    if pack.get("invalid"):
        return {"status": "源patch无效", "fail_reason": pack.get("reason")}, None

    if pool is None:
        all_names = list_train_images()
        src_key = os.path.normcase(os.path.basename(sample_row["src_image"]))
        pool = [n for n in all_names if os.path.normcase(n) != src_key]
    if not pool:
        return {"status": "无其他目标背景图"}, None

    all_elig = []
    diags = []
    if workers and workers > 1:
        from concurrent.futures import ProcessPoolExecutor
        with ProcessPoolExecutor(max_workers=workers, initializer=_init_worker,
                                 initargs=(pack,)) as ex:
            for elig, diag in ex.map(_worker_task, pool, chunksize=16):
                all_elig.extend(elig)
                diags.append(diag)
    else:
        for name in pool:
            elig, diag = eval_target(pack, name)
            all_elig.extend(elig)
            diags.append(diag)

    if not all_elig:
        return {
            "status": "全训练集无合格选址窗口",
            "evaluated_images": len(pool),
            "total_windows": int(sum(d.get("total", 0) or 0 for d in diags)),
            "direction_pass_windows": int(sum(d.get("trace_pass", 0) or 0 for d in diags)),
            "period_pass_windows": int(sum(d.get("period_pass", 0) or 0 for d in diags)),
        }, {"sample_idx": sample_row.get("sample_idx"), "evaluated_images": len(pool)}

    sccp_n, sccp_lo, sccp_hi = _robust_norm([c["d_sccp"] for c in all_elig])
    trace_n, trace_lo, trace_hi = _robust_norm([c["d_trace"] for c in all_elig])
    period_n, period_lo, period_hi = _robust_norm([c["d_period"] for c in all_elig])
    phase_n, phase_lo, phase_hi = _robust_norm([c["d_phase"] for c in all_elig])

    w_sccp = 1 - Y.LAMBDA_TRACE - Y.LAMBDA_PERIOD - Y.LAMBDA_PHASE
    for i, c in enumerate(all_elig):
        c["d_sccp_norm"] = float(sccp_n[i])
        c["d_trace_norm"] = float(trace_n[i])
        c["d_period_norm"] = float(period_n[i]) if np.isfinite(period_n[i]) else np.nan
        c["d_phase_norm"] = float(phase_n[i]) if np.isfinite(phase_n[i]) else np.nan
        phase_score = c["d_phase_norm"] if np.isfinite(c["d_phase_norm"]) else 0.5
        c["score_fpc"] = (w_sccp * c["d_sccp_norm"]
                          + Y.LAMBDA_TRACE * c["d_trace_norm"]
                          + Y.LAMBDA_PERIOD * c["d_period_norm"]
                          + Y.LAMBDA_PHASE * phase_score)

    best = min(all_elig, key=lambda c: c["score_fpc"])
    winner = dict(best)
    winner.update({
        "status": "成功",
        "pool_size": len(pool),
        "evaluated_images": len(pool),
        "eligible_window_count": len(all_elig),
        "total_window_count": int(sum(d.get("total", 0) or 0 for d in diags)),
        "direction_pass_count": int(sum(d.get("trace_pass", 0) or 0 for d in diags)),
        "period_gate_count": int(sum(d.get("period_pass", 0) or 0 for d in diags)),
        "eligible_images": ";".join(sorted({c["target_image"] for c in all_elig})),
        "norm_scope": "union_of_eligible_windows",
        "norm_p5p95": {
            "sccp": [sccp_lo, sccp_hi], "trace": [trace_lo, trace_hi],
            "period": [period_lo, period_hi], "phase": [phase_lo, phase_hi],
        },
        "phase_norm_count": int(np.isfinite(np.asarray([c["d_phase"] for c in all_elig])).sum()),
        "workers": workers,
    })
    return winner, {"sample_idx": sample_row.get("sample_idx"),
                    "evaluated_images": len(pool), "eligible_window_count": len(all_elig)}


def search_all(sample_row, pool=None, keep_eligible_report=True):
    """全训练集背景 × 全部合法窗口；并集 p5/p95 归一化后取综合分最低的位置。"""
    pack = prepare_source(sample_row)
    if pack is None:
        return {"status": "源图读取失败"}, None
    if pack.get("invalid"):
        return {"status": "源patch无效", "fail_reason": pack.get("reason")}, None

    if pool is None:
        all_names = list_train_images()
        src_key = os.path.normcase(os.path.basename(sample_row["src_image"]))
        pool = [n for n in all_names if os.path.normcase(n) != src_key]
    if not pool:
        return {"status": "无其他目标背景图"}, None

    all_elig = []
    diags = []
    for name in pool:
        elig, diag = eval_target(pack, name)
        all_elig.extend(elig)
        diags.append(diag)

    if not all_elig:
        return {
            "status": "全训练集无合格选址窗口",
            "evaluated_images": len(pool),
            "total_windows": int(sum(d.get("total", 0) or 0 for d in diags)),
            "direction_pass_windows": int(sum(d.get("trace_pass", 0) or 0 for d in diags)),
            "period_pass_windows": int(sum(d.get("period_pass", 0) or 0 for d in diags)),
        }, {"sample_idx": sample_row.get("sample_idx"), "evaluated_images": len(pool)}

    sccp_n, sccp_lo, sccp_hi = _robust_norm([c["d_sccp"] for c in all_elig])
    trace_n, trace_lo, trace_hi = _robust_norm([c["d_trace"] for c in all_elig])
    period_n, period_lo, period_hi = _robust_norm([c["d_period"] for c in all_elig])
    phase_n, phase_lo, phase_hi = _robust_norm([c["d_phase"] for c in all_elig])

    w_sccp = 1 - Y.LAMBDA_TRACE - Y.LAMBDA_PERIOD - Y.LAMBDA_PHASE
    for i, c in enumerate(all_elig):
        c["d_sccp_norm"] = float(sccp_n[i])
        c["d_trace_norm"] = float(trace_n[i])
        c["d_period_norm"] = float(period_n[i]) if np.isfinite(period_n[i]) else np.nan
        c["d_phase_norm"] = float(phase_n[i]) if np.isfinite(phase_n[i]) else np.nan
        phase_score = c["d_phase_norm"] if np.isfinite(c["d_phase_norm"]) else 0.5
        c["score_fpc"] = (w_sccp * c["d_sccp_norm"]
                          + Y.LAMBDA_TRACE * c["d_trace_norm"]
                          + Y.LAMBDA_PERIOD * c["d_period_norm"]
                          + Y.LAMBDA_PHASE * phase_score)

    best = min(all_elig, key=lambda c: c["score_fpc"])
    winner = dict(best)
    winner.update({
        "status": "成功",
        "pool_size": len(pool),
        "evaluated_images": len(pool),
        "eligible_window_count": len(all_elig),
        "total_window_count": int(sum(d.get("total", 0) or 0 for d in diags)),
        "direction_pass_count": int(sum(d.get("trace_pass", 0) or 0 for d in diags)),
        "period_gate_count": int(sum(d.get("period_pass", 0) or 0 for d in diags)),
        "eligible_images": ";".join(sorted({c["target_image"] for c in all_elig})),
        "norm_scope": "union_of_eligible_windows",
        "norm_p5p95": {
            "sccp": [sccp_lo, sccp_hi], "trace": [trace_lo, trace_hi],
            "period": [period_lo, period_hi], "phase": [phase_lo, phase_hi],
        },
        "phase_norm_count": int(np.isfinite(np.asarray([c["d_phase"] for c in all_elig])).sum()),
    })
    if not keep_eligible_report:
        winner.pop("eligible_report", None)
    return winner, {"sample_idx": sample_row.get("sample_idx"), "evaluated_images": len(pool),
                    "eligible_window_count": len(all_elig)}
