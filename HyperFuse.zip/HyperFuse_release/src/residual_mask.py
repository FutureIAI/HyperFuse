"""FPC periodic-texture residual mask and residual transfer.

This is an experimental, model-free helper. It estimates normal periodic
texture from pixels outside a labeled defect box, detects the residual inside
the box, and transfers only that residual to a destination patch.

Three-way status contract (fail-closed, never merged into one flag):
  * ``info["ok"]``            -> compute_ok: the algorithm ran to completion.
  * ``validate_residual_mask`` -> quality_pass: the produced mask is acceptable
                                  for transfer.
  * ``run_residual_branch``   -> transfer_effective: the destination actually
                                  changed enough, locally, and a legal new
                                  label could be derived.
``apply_lab_residual`` / ``apply_lab_residual_with_stats`` must only be called
when ``quality_pass`` is True.

Every rejection carries a stable machine-readable ``reason_code``
(e.g. invalid_period, low_coverage, high_reference_uncertainty, empty_mask)
next to the human-readable ``reason``.

Angle convention:
  ``trace_angle_deg`` is the trace TANGENT angle returned by
  ``compute_region_trace_feat`` (gradient orientation + 90 deg), taken as an
  axial angle in [0, 180). It is NOT the negated angle that
  ``compute_texture_features`` uses internally for its own rotation.
"""

from __future__ import annotations

import csv
import os
import warnings
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

from placement_features import extract_8_regions


def _component_filter(mask: np.ndarray, min_area: int) -> np.ndarray:
    """Keep connected components with at least min_area pixels."""
    src = (mask > 0).astype(np.uint8)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(src, connectivity=8)
    kept = np.zeros_like(src)
    for i in range(1, n):
        if int(stats[i, cv2.CC_STAT_AREA]) >= min_area:
            kept[labels == i] = 1
    return kept


def _sanitize(arr: np.ndarray) -> Tuple[np.ndarray, int]:
    """Replace NaN/Inf with 0.0; return (clean float32 array, replaced count)."""
    a = np.asarray(arr, dtype=np.float32)
    bad = ~np.isfinite(a)
    count = int(bad.sum())
    if count:
        a = np.where(bad, 0.0, a).astype(np.float32)
    return a, count


def _lab_score(residual: np.ndarray) -> np.ndarray:
    """Scalar deviation magnitude of a LAB residual, L weighted higher."""
    return np.sqrt(
        residual[..., 0] ** 2
        + 0.5 * residual[..., 1] ** 2
        + 0.5 * residual[..., 2] ** 2
    )


# ---------------------------------------------------------------------------
# Axial-angle helpers (standalone; no import from yuhua to avoid cycles)
# ---------------------------------------------------------------------------
def _axial_mean_deg(deg_values) -> Optional[float]:
    """Axial ([0,180)) angle mean, avoiding 179 deg + 1 deg averaging to 90."""
    vals = np.asarray(list(deg_values), dtype=np.float64)
    if vals.size == 0:
        return None
    if vals.size == 1:
        return float(vals[0]) % 180.0
    rad = np.radians(2.0 * vals)
    mean = float(np.degrees(np.arctan2(np.sin(rad).sum(), np.cos(rad).sum())) / 2.0)
    return float(mean % 180.0)


def _axial_diff_deg(a: float, b: float) -> float:
    raw = abs(a - b) % 180.0
    return float(min(raw, 180.0 - raw))


def compute_trace_texture_support(src_region_feats: List[Dict]) -> Dict:
    """Aggregate per-region trace/texture features into support statistics.

    Args:
        src_region_feats: list of dicts produced by the SCCP-TO-FPC pipeline;
            each valid entry has keys ``valid``, ``trace_ok``, ``theta_deg``,
            ``period_ok``, ``period``.

    Returns:
        dict with ``angle_support`` (reliable trace regions), ``period_support``
        (reliable period regions), ``angle_spread_deg`` (mean axial deviation
        of reliable angles from their axial mean; NaN when no support),
        ``theta_bar`` / ``period_bar`` (the aggregated tangent angle and pitch).
    """
    thetas = [float(f["theta_deg"]) for f in src_region_feats
              if f.get("valid") and f.get("trace_ok") and np.isfinite(float(f["theta_deg"]))]
    periods = [float(f["period"]) for f in src_region_feats
               if f.get("valid") and f.get("period_ok")
               and np.isfinite(float(f["period"])) and float(f["period"]) > 0]
    angle_support = len(thetas)
    period_support = len(periods)
    theta_bar = _axial_mean_deg(thetas) if angle_support else None
    period_bar = float(np.median(periods)) if period_support else None
    angle_spread = float("nan")
    if angle_support and theta_bar is not None:
        angle_spread = float(np.mean([_axial_diff_deg(t, theta_bar) for t in thetas]))
    return {
        "angle_support": angle_support,
        "period_support": period_support,
        "angle_spread_deg": angle_spread,
        "theta_bar": theta_bar,
        "period_bar": period_bar,
    }


def estimate_fpc_defect_residual(
    source_bgr: np.ndarray,
    bbox: Tuple[int, int, int, int],
    trace_angle_deg: float,
    period_px: float,
    *,
    threshold_k: float = 3.0,
    min_residual: float = 7.0,
    min_mask_ratio: float = 0.003,
    max_mask_ratio: float = 0.45,
    min_reconstruction_coverage: float = 0.70,
    min_ref_samples: int = 3,
    max_ref_spread: float = 26.0,
    max_uncertain_ratio: float = 0.35,
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray], Optional[np.ndarray], Dict]:
    """Estimate a defect mask and LAB residual within an annotated bbox.

    Args:
        source_bgr: Full source image, uint8 BGR.
        bbox: (x, y, w, h) pixel coordinates of the defect annotation.
        trace_angle_deg: Dominant trace TANGENT angle in degrees, axial [0,180).
        period_px: Trace pitch in pixels, measured normal to the traces.
        min_ref_samples: Minimum out-of-box same-phase reference pixels required
            before a reconstructed pixel counts as trustworthy.
        max_ref_spread: Maximum robust dispersion (MAD-based) of the reference
            pixels around their own reconstructed median.
        max_uncertain_ratio: Maximum share of in-box pixels allowed to be
            high-uncertainty (too few references or too dispersed).

    Returns:
        mask: uint8 0/255 mask with shape (h,w), or None if unreliable.
        residual_lab: float32 LAB residual (source - reconstructed normal),
            shape (h,w,3), zero outside the mask; or None if unreliable.
        alpha: float32 soft mask [0,1], shape (h,w), or None if unreliable.
        info: status and diagnostic measurements. ``info["ok"]`` means the
            computation completed; it does NOT mean the mask is good. Use
            ``validate_residual_mask`` for the quality decision. On success
            ``info`` additionally carries ``reason_code`` (== "computed") and a
            diagnostic-only ``reconstruction_patch_bgr`` image (uint8 BGR,
            h x w) of the reconstructed normal texture back in source patch
            coordinates.

    The function assumes locally periodic traces. It should skip areas with
    weak periodic structure, strong bends, or insufficient intact context.
    """
    if source_bgr is None or source_bgr.ndim != 3 or source_bgr.shape[2] != 3:
        return None, None, None, {"ok": False, "quality_pass": False,
                                  "reason": "source must be HxWx3 BGR",
                                  "reason_code": "invalid_input"}

    x, y, w, h = map(int, bbox)
    img_h, img_w = source_bgr.shape[:2]
    if w < 3 or h < 3 or x < 0 or y < 0 or x + w > img_w or y + h > img_h:
        return None, None, None, {"ok": False, "quality_pass": False,
                                  "reason": "invalid bbox", "reason_code": "invalid_bbox"}
    if not np.isfinite(period_px) or float(period_px) < 2.0:
        return None, None, None, {"ok": False, "quality_pass": False,
                                  "reason": "invalid or too-small period",
                                  "reason_code": "invalid_period"}
    if not np.isfinite(trace_angle_deg):
        return None, None, None, {"ok": False, "quality_pass": False,
                                  "reason": "invalid trace angle",
                                  "reason_code": "invalid_angle"}

    period_px = float(period_px)
    diagonal = float(np.hypot(w, h))
    margin = max(24, int(np.ceil(diagonal / 2.0 + 4.0 * period_px)))
    cx0, cy0 = max(0, x - margin), max(0, y - margin)
    cx1, cy1 = min(img_w, x + w + margin), min(img_h, y + h + margin)
    crop = source_bgr[cy0:cy1, cx0:cx1]
    crop_h, crop_w = crop.shape[:2]
    bx, by = x - cx0, y - cy0

    # Rectangular annotation mask in the expanded source crop.
    box_mask = np.zeros((crop_h, crop_w), dtype=np.uint8)
    box_mask[by:by+h, bx:bx+w] = 255

    # Rotate so the dominant trace tangent is horizontal; the normal/pitch axis is y.
    center = (bx + w / 2.0, by + h / 2.0)
    # OpenCV's positive angle rotates image-coordinate vectors (y downward)
    # by -angle in the array; +theta therefore makes a tangent measured with
    # atan2(gy, gx) horizontal.
    matrix = cv2.getRotationMatrix2D(center, float(trace_angle_deg), 1.0)
    lab_crop = cv2.cvtColor(crop, cv2.COLOR_BGR2LAB).astype(np.float32)
    lab_rot = cv2.warpAffine(
        lab_crop, matrix, (crop_w, crop_h), flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_REFLECT_101
    )
    box_rot = cv2.warpAffine(
        box_mask, matrix, (crop_w, crop_h), flags=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT, borderValue=0
    ) > 0

    ys, xs = np.where(box_rot)
    if len(xs) < 9:
        return None, None, None, {"ok": False, "quality_pass": False,
                                  "reason": "rotated bbox is too small",
                                  "reason_code": "rotated_bbox_too_small"}
    rx0, rx1 = int(xs.min()), int(xs.max()) + 1
    ry0, ry1 = int(ys.min()), int(ys.max()) + 1
    target_mask = box_rot[ry0:ry1, rx0:rx1]

    # For each point in the bbox, sample same-phase locations one or more
    # periods above/below it. Samples inside the annotated box are excluded.
    max_k = max(2, int(np.ceil((diagonal / 2.0 + 2.0 * period_px) / period_px)))
    max_k = min(max_k, 48)
    yy = np.arange(ry0, ry1, dtype=np.int32)
    xx = np.arange(rx0, rx1, dtype=np.int32)
    samples = []

    for k in range(1, max_k + 1):
        dy = max(1, int(round(k * period_px)))
        for sign in (-1, 1):
            sample_y = yy + sign * dy
            inside_y = (sample_y >= 0) & (sample_y < crop_h)
            safe_y = np.clip(sample_y, 0, crop_h - 1)
            sample_lab = lab_rot[safe_y[:, None], xx[None, :], :]
            sample_box = box_rot[safe_y[:, None], xx[None, :]]
            valid = target_mask & inside_y[:, None] & (~sample_box)
            sample_lab = sample_lab.astype(np.float32)
            sample_lab[~valid] = np.nan
            samples.append(sample_lab)

    if not samples:
        return None, None, None, {"ok": False, "quality_pass": False,
                                  "reason": "no context samples",
                                  "reason_code": "no_context_samples"}

    stack = np.stack(samples, axis=0)
    finite = np.isfinite(stack[..., 0])
    valid_count = finite.sum(axis=0)
    coverage = float(np.mean(valid_count[target_mask] >= 2))

    # ---- Reconstruction confidence -------------------------------------
    # Having >=2 references is necessary but NOT sufficient: the references
    # must also agree with each other. Measure their robust dispersion around
    # the reconstructed median and flag pixels that are under-determined.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)
        normal_lab = np.nanmedian(stack, axis=0).astype(np.float32)
        abs_dev = np.abs(stack - normal_lab[None, ...])
        # finite is (N,H,W); broadcast to (N,H,W,3) so invalid samples are excluded.
        abs_dev = np.where(finite[..., None], abs_dev, np.nan).astype(np.float32)
        ref_mad = 1.4826 * np.nanmedian(abs_dev, axis=0).astype(np.float32)

    ref_spread = _lab_score(np.where(np.isfinite(ref_mad), ref_mad, 0.0))
    spread_finite = np.isfinite(ref_spread) & np.isfinite(normal_lab).all(axis=2)

    uncertain = (
        (valid_count < int(min_ref_samples))
        | (~spread_finite)
        | (ref_spread > float(max_ref_spread))
    )
    in_box = target_mask
    uncertain_ratio = float(np.mean(uncertain[in_box])) if in_box.any() else 1.0
    spread_vals = ref_spread[in_box & spread_finite]
    ref_spread_median = float(np.median(spread_vals)) if spread_vals.size else float("nan")
    ref_spread_p95 = float(np.percentile(spread_vals, 95)) if spread_vals.size else float("nan")
    ref_count_vals = valid_count[in_box].astype(np.float32)
    ref_count_median = float(np.median(ref_count_vals)) if ref_count_vals.size else 0.0

    base_info = {
        "reconstruction_coverage": round(coverage, 4),
        "required_coverage": min_reconstruction_coverage,
        "uncertain_ratio": round(uncertain_ratio, 4),
        "max_uncertain_ratio": float(max_uncertain_ratio),
        "ref_spread_median": None if not np.isfinite(ref_spread_median) else round(ref_spread_median, 3),
        "ref_spread_p95": None if not np.isfinite(ref_spread_p95) else round(ref_spread_p95, 3),
        "max_ref_spread": float(max_ref_spread),
        "ref_count_median": round(ref_count_median, 2),
        "min_ref_samples": int(min_ref_samples),
    }

    reject = None
    reject_code = None
    if coverage < min_reconstruction_coverage:
        reject = "insufficient intact periodic context"
        reject_code = "low_coverage"
    elif uncertain_ratio > float(max_uncertain_ratio):
        reject = "too many high-uncertainty reconstruction pixels"
        reject_code = "high_reference_uncertainty"
    elif np.isfinite(ref_spread_median) and ref_spread_median > float(max_ref_spread):
        reject = "reference dispersion too large"
        reject_code = "high_ref_spread"
    if reject is not None:
        info = {"ok": False, "quality_pass": False, "reason": reject,
                "reason_code": reject_code}
        info.update(base_info)
        return None, None, None, info

    # ---- Residual detection -------------------------------------------
    observed_lab = lab_rot[ry0:ry1, rx0:rx1]
    # Pixels whose references are all inside the box / outside the crop have no
    # normal estimate. Force them finite and exclude them from the mask so they
    # can never reach the fusion step.
    reconstructible = np.isfinite(normal_lab).all(axis=2) & (valid_count >= int(min_ref_samples))
    normal_lab = np.where(np.isfinite(normal_lab), normal_lab, observed_lab)
    residual = observed_lab - normal_lab
    residual, _ = _sanitize(residual)
    residual[~reconstructible] = 0.0

    score = _lab_score(residual)
    score_values = score[target_mask & reconstructible]
    if len(score_values) < 16:
        info = {"ok": False, "quality_pass": False, "reason": "too few residual pixels",
                "reason_code": "too_few_residual_pixels"}
        info.update(base_info)
        return None, None, None, info

    med = float(np.median(score_values))
    mad = float(1.4826 * np.median(np.abs(score_values - med)))
    threshold = max(float(min_residual), med + float(threshold_k) * mad)
    raw_mask = ((score > threshold) & target_mask & reconstructible).astype(np.uint8)
    raw_mask = cv2.morphologyEx(
        raw_mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=1
    )
    raw_mask = _component_filter(raw_mask, min_area=max(3, int(round(0.002 * w * h))))
    # Morphology/component filtering must not resurrect excluded pixels.
    raw_mask = (raw_mask & reconstructible.astype(np.uint8)).astype(np.uint8)

    mask_ratio = float(raw_mask.sum()) / float(max(1, target_mask.sum()))
    # mask 面积范围属于质量门槛，由 validate 阶段（min/max_mask_ratio）判定；
    # estimate 只负责把候选 mask 算出来，面积超限不再在此提前拒绝，保证
    # compute_ok=True、quality_pass=False 的语义分离，并保留面积指标。

    # Store only defect residuals and create a narrow soft edge.
    residual_masked = residual.copy()
    residual_masked[raw_mask == 0] = 0.0
    alpha_rot = cv2.GaussianBlur(raw_mask.astype(np.float32), (0, 0), sigmaX=1.0)
    alpha_rot = np.clip(alpha_rot, 0.0, 1.0)

    full_mask_rot = np.zeros((crop_h, crop_w), dtype=np.uint8)
    full_residual_rot = np.zeros((crop_h, crop_w, 3), dtype=np.float32)
    full_alpha_rot = np.zeros((crop_h, crop_w), dtype=np.float32)
    full_mask_rot[ry0:ry1, rx0:rx1] = raw_mask
    full_residual_rot[ry0:ry1, rx0:rx1] = residual_masked
    full_alpha_rot[ry0:ry1, rx0:rx1] = alpha_rot

    inverse = cv2.invertAffineTransform(matrix)
    mask_src = cv2.warpAffine(
        full_mask_rot, inverse, (crop_w, crop_h), flags=cv2.INTER_NEAREST,
        borderMode=cv2.BORDER_CONSTANT, borderValue=0
    )
    residual_src = cv2.warpAffine(
        full_residual_rot, inverse, (crop_w, crop_h), flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT, borderValue=0
    )
    alpha_src = cv2.warpAffine(
        full_alpha_rot, inverse, (crop_w, crop_h), flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT, borderValue=0
    )

    mask_out = mask_src[by:by+h, bx:bx+w]
    residual_out = residual_src[by:by+h, bx:bx+w]
    alpha_out = np.clip(alpha_src[by:by+h, bx:bx+w], 0.0, 1.0)
    residual_out, nan_fixed = _sanitize(residual_out)
    alpha_out, alpha_fixed = _sanitize(alpha_out)
    alpha_out = np.clip(alpha_out, 0.0, 1.0)
    # Anything that was not finite must not survive as a defect pixel.
    mask_out = np.where(np.isfinite(residual_out).all(axis=2), mask_out, 0).astype(np.uint8)

    if mask_out.shape != (h, w) or int(mask_out.sum()) == 0:
        info = {"ok": False, "quality_pass": False,
                "reason": "mask vanished after inverse rotation",
                "reason_code": "empty_mask"}
        info.update(base_info)
        # 逆旋转后仍为空 → 如实拒绝，不强行填充；但保留三张诊断图供定位：
        # 旋转坐标系候选 mask / 逆旋转完整 mask / 裁剪回源 bbox 的 mask。
        info["diag_mask_rot"] = (raw_mask.astype(np.uint8) * 255)
        info["diag_mask_inv_full"] = (mask_src.astype(np.uint8) * 255)
        info["diag_mask_bbox"] = (mask_out.astype(np.uint8) * 255)
        return None, None, None, info

    # Diagnostic-only reconstruction of the normal texture, back in source
    # patch coordinates (LAB -> BGR, clipped). Pixels without a normal estimate
    # fall back to the observed value by construction (see normal_lab above).
    full_normal_rot = np.zeros((crop_h, crop_w, 3), dtype=np.float32)
    full_normal_rot[ry0:ry1, rx0:rx1] = normal_lab
    normal_src = cv2.warpAffine(
        full_normal_rot, inverse, (crop_w, crop_h), flags=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT, borderValue=0
    )
    normal_patch = normal_src[by:by+h, bx:bx+w]
    normal_patch, _ = _sanitize(normal_patch)
    # LAB 值来自 uint8 BGR2LAB（L/a/b 均按 [0,255] 刻度）；转回也必须走 uint8
    # 约定。float32 的 COLOR_LAB2BGR 要求 L∈[0,100]、a/b∈[-128,127]，数值
    # 越界会把整幅重建图输出成全黑。
    recon_bgr = cv2.cvtColor(
        np.clip(normal_patch, 0, 255).astype(np.uint8),
        cv2.COLOR_LAB2BGR
    )

    info = {
        "ok": True,
        "quality_pass": False,  # set by validate_residual_mask
        "reason": "computed",
        "reason_code": "computed",
        "threshold": round(threshold, 3),
        "residual_median": round(med, 3),
        "residual_mad": round(mad, 3),
        "mask_ratio": round(float(np.mean(mask_out > 0)), 5),
        "mask_ratio_in_rotated_box": round(mask_ratio, 5),
        "residual_nan_fixed": nan_fixed,
        "alpha_nan_fixed": alpha_fixed,
        "residual_mag_median_in_mask": round(float(np.median(_lab_score(residual_out)[mask_out > 0])), 3)
            if int(mask_out.sum()) else 0.0,
        "residual_mag_p95_in_mask": round(float(np.percentile(_lab_score(residual_out)[mask_out > 0], 95)), 3)
            if int(mask_out.sum()) else 0.0,
        "period_px": round(period_px, 3),
        "trace_angle_deg": round(float(trace_angle_deg) % 180.0, 3),
        "reconstruction_patch_bgr": recon_bgr,
        # 旋转诊断三视图：旋转坐标系候选 mask / 逆旋转完整 mask / 裁剪回源 bbox mask
        "diag_mask_rot": (raw_mask.astype(np.uint8) * 255),
        "diag_mask_inv_full": (mask_src.astype(np.uint8) * 255),
        "diag_mask_bbox": (mask_out.astype(np.uint8) * 255),
    }
    info.update(base_info)
    return (mask_out.astype(np.uint8) * 255,
            residual_out.astype(np.float32),
            alpha_out.astype(np.float32),
            info)


def validate_residual_mask(
    mask: Optional[np.ndarray],
    residual_lab: Optional[np.ndarray],
    info: Dict,
    *,
    min_mask_ratio: float = 0.003,
    max_mask_ratio: float = 0.45,
    min_largest_component_ratio: float = 0.60,
    max_tight_w_ratio: float = 0.80,
    max_tight_h_ratio: float = 0.80,
    max_uncertain_ratio: float = 0.35,
    min_residual_mag_median: float = 6.0,
    max_residual_mag_p95: Optional[float] = 130.0,
    max_edge_touch_ratio: Optional[float] = 0.30,
    edge_strip_px: int = 1,
    reject_on_border_touch: bool = False,
) -> Tuple[bool, Dict, List[str]]:
    """Decide whether a computed mask is good enough to transfer.

    Separates "the algorithm finished" (``info["ok"]``) from "the result is
    acceptable" (the returned ``quality_pass``). Fail-closed: when this returns
    False the caller must NOT run ``apply_lab_residual``.

    Quality gates are engineering screening values, not proven universal
    thresholds; every gate threshold is echoed back in ``stats`` and recorded
    per sample in the diagnosis CSV.

    Returns:
        quality_pass: bool
        stats: measured mask/residual statistics (all thresholds echoed back;
               ``reject_reason_codes`` lists stable machine codes)
        reasons: list of human-readable rejection reasons (empty when passing)
    """
    stats: Dict = {
        "quality_pass": False,
        "mask_ratio": "",
        "component_count": "",
        "largest_component_ratio": "",
        "tight_w_ratio": "",
        "tight_h_ratio": "",
        "edge_touch_ratio": "",
        "touches_border": "",
        "residual_mag_median_in_mask": "",
        "residual_mag_p95_in_mask": "",
        "reconstruction_uncertainty": info.get("uncertain_ratio", ""),
        "reconstruction_coverage": info.get("reconstruction_coverage", ""),
        "ref_spread_median": info.get("ref_spread_median", ""),
        "ref_count_median": info.get("ref_count_median", ""),
        "th_min_mask_ratio": min_mask_ratio,
        "th_max_mask_ratio": max_mask_ratio,
        "th_min_largest_component_ratio": min_largest_component_ratio,
        "th_max_tight_w_ratio": max_tight_w_ratio,
        "th_max_tight_h_ratio": max_tight_h_ratio,
        "th_max_uncertain_ratio": max_uncertain_ratio,
        "th_min_residual_mag_median": min_residual_mag_median,
        "th_max_residual_mag_p95": max_residual_mag_p95,
        "th_max_edge_touch_ratio": max_edge_touch_ratio,
        "th_edge_strip_px": edge_strip_px,
        "th_reject_on_border_touch": bool(reject_on_border_touch),
    }
    reasons: List[str] = []
    reason_codes: List[str] = []

    if not info.get("ok"):
        reasons.append(f"estimation_failed:{info.get('reason', 'unknown')}")
        reason_codes.append(info.get("reason_code", "unknown"))
        stats["reject_reasons"] = ";".join(reasons)
        stats["reject_reason_codes"] = ";".join(reason_codes)
        return False, stats, reasons

    if mask is None or residual_lab is None:
        reasons.append("estimation_returned_no_mask")
        reason_codes.append("no_mask_returned")
        stats["reject_reasons"] = ";".join(reasons)
        stats["reject_reason_codes"] = ";".join(reason_codes)
        return False, stats, reasons

    binmask = (np.asarray(mask) > 0).astype(np.uint8)
    ph, pw = binmask.shape
    total = int(binmask.sum())
    if total == 0:
        reasons.append("empty_mask")
        reason_codes.append("empty_mask")
        stats["reject_reasons"] = ";".join(reasons)
        stats["reject_reason_codes"] = ";".join(reason_codes)
        return False, stats, reasons

    ratio = total / float(max(1, pw * ph))
    n, _labels, cc_stats, _ = cv2.connectedComponentsWithStats(binmask, connectivity=8)
    comp_count = max(0, n - 1)
    areas = [int(cc_stats[i, cv2.CC_STAT_AREA]) for i in range(1, n)] or [0]
    largest_ratio = max(areas) / float(total)

    ys, xs = np.where(binmask > 0)
    tw = int(xs.max() - xs.min() + 1)
    th_ = int(ys.max() - ys.min() + 1)
    tight_w_ratio = tw / float(max(1, pw))
    tight_h_ratio = th_ / float(max(1, ph))
    touches_border = bool(xs.min() <= 0 or ys.min() <= 0
                          or xs.max() >= pw - 1 or ys.max() >= ph - 1)

    # Share of mask pixels sitting inside a thin strip along the patch border.
    strip = max(1, int(edge_strip_px))
    border = np.zeros_like(binmask)
    border[:strip, :] = 1
    border[-strip:, :] = 1
    border[:, :strip] = 1
    border[:, -strip:] = 1
    edge_touch_ratio = float(np.sum((binmask > 0) & (border > 0))) / float(max(1, total))

    mag = _lab_score(np.asarray(residual_lab, dtype=np.float32))
    inside = binmask > 0
    mag_vals = mag[inside]
    mag_median = float(np.median(mag_vals)) if mag_vals.size else 0.0
    mag_p95 = float(np.percentile(mag_vals, 95)) if mag_vals.size else 0.0

    uncertain = info.get("uncertain_ratio", None)

    stats.update({
        "mask_ratio": round(ratio, 5),
        "component_count": comp_count,
        "largest_component_ratio": round(largest_ratio, 4),
        "tight_w_ratio": round(tight_w_ratio, 4),
        "tight_h_ratio": round(tight_h_ratio, 4),
        "edge_touch_ratio": round(edge_touch_ratio, 4),
        "touches_border": touches_border,
        "residual_mag_median_in_mask": round(mag_median, 3),
        "residual_mag_p95_in_mask": round(mag_p95, 3),
    })

    if ratio < min_mask_ratio:
        reasons.append(f"mask_too_small:{ratio:.4f}<{min_mask_ratio}")
        reason_codes.append("mask_too_small")
    if ratio > max_mask_ratio:
        reasons.append(f"mask_too_large:{ratio:.4f}>{max_mask_ratio}")
        reason_codes.append("mask_too_large")
    if largest_ratio < min_largest_component_ratio:
        reasons.append(f"fragmented_mask:largest={largest_ratio:.3f}<{min_largest_component_ratio}")
        reason_codes.append("fragmented_mask")
    if tight_w_ratio > max_tight_w_ratio:
        reasons.append(f"spans_full_width:{tight_w_ratio:.3f}>{max_tight_w_ratio}")
        reason_codes.append("mask_spans_width")
    if tight_h_ratio > max_tight_h_ratio:
        reasons.append(f"spans_full_height:{tight_h_ratio:.3f}>{max_tight_h_ratio}")
        reason_codes.append("mask_spans_height")
    if uncertain is not None and uncertain != "" and float(uncertain) > max_uncertain_ratio:
        reasons.append(f"reconstruction_uncertain:{float(uncertain):.3f}>{max_uncertain_ratio}")
        reason_codes.append("high_reference_uncertainty")
    if mag_median < min_residual_mag_median:
        reasons.append(f"weak_residual:{mag_median:.2f}<{min_residual_mag_median}")
        reason_codes.append("weak_residual")
    if max_residual_mag_p95 is not None and mag_p95 > float(max_residual_mag_p95):
        reasons.append(f"residual_too_strong:p95={mag_p95:.2f}>{max_residual_mag_p95}")
        reason_codes.append("residual_too_strong")
    if max_edge_touch_ratio is not None and edge_touch_ratio > float(max_edge_touch_ratio):
        reasons.append(f"mask_touches_border:edge_ratio={edge_touch_ratio:.3f}>{max_edge_touch_ratio}")
        reason_codes.append("mask_touches_border")
    if touches_border and reject_on_border_touch:
        reasons.append("mask_touches_bbox_border")
        reason_codes.append("mask_touches_border")

    quality_pass = not reasons
    stats["quality_pass"] = bool(quality_pass)
    stats["reject_reasons"] = ";".join(reasons)
    stats["reject_reason_codes"] = ";".join(reason_codes)
    return bool(quality_pass), stats, reasons


def apply_lab_residual_with_stats(
    destination_bgr: np.ndarray,
    destination_bbox: Tuple[int, int, int, int],
    residual_lab: np.ndarray,
    alpha: np.ndarray,
    strength: float = 0.85,
    change_epsilon: float = 1.0,
) -> Tuple[np.ndarray, Dict]:
    """Add only the source defect residual to the destination's own texture.

    Sanitizes NaN/Inf in residual and alpha, clamps alpha to [0,1], and reports
    how much the destination LAB actually changed so that a near-invisible
    transfer cannot be recorded as a success.
    """
    x, y, w, h = map(int, destination_bbox)
    residual_lab = np.asarray(residual_lab)
    alpha = np.asarray(alpha)
    if residual_lab.shape != (h, w, 3) or alpha.shape != (h, w):
        raise ValueError("residual/alpha dimensions must match destination bbox")
    if x < 0 or y < 0 or x + w > destination_bgr.shape[1] or y + h > destination_bgr.shape[0]:
        raise ValueError("destination bbox is out of image bounds")

    res, res_fixed = _sanitize(residual_lab)
    alp, alp_fixed = _sanitize(alpha)
    out_of_range = int(np.sum((alp < 0.0) | (alp > 1.0)))
    alp = np.clip(alp, 0.0, 1.0)

    out = destination_bgr.copy()
    before = cv2.cvtColor(destination_bgr[y:y+h, x:x+w], cv2.COLOR_BGR2LAB).astype(np.float32)
    updated = before + float(strength) * alp[..., None] * res
    clip_low = int(np.sum(updated < 0.0))
    clip_high = int(np.sum(updated > 255.0))
    updated = np.clip(updated, 0, 255).astype(np.uint8)
    out[y:y+h, x:x+w] = cv2.cvtColor(updated, cv2.COLOR_LAB2BGR)

    after = cv2.cvtColor(out[y:y+h, x:x+w], cv2.COLOR_BGR2LAB).astype(np.float32)
    delta = np.abs(after - before).max(axis=2)
    changed_mask = delta > float(change_epsilon)
    changed_delta = delta[changed_mask]
    n_px = max(1, int(delta.size))

    stats = {
        # 全框口径（含大量未改动像素，中位数会被压向 0，仅用于对照）
        "lab_delta_median_all": round(float(np.median(delta)), 3),
        "lab_delta_p95_all": round(float(np.percentile(delta, 95)), 3),
        # 仅"被改动"像素口径（changed = delta > change_epsilon）
        "lab_delta_median_changed": (round(float(np.median(changed_delta)), 3)
                                     if changed_delta.size else 0.0),
        "lab_delta_p95_changed": (round(float(np.percentile(changed_delta, 95)), 3)
                                  if changed_delta.size else 0.0),
        # 兼容别名（全框口径，老调用方）
        "lab_delta_median": round(float(np.median(delta)), 3),
        "lab_delta_p95": round(float(np.percentile(delta, 95)), 3),
        "lab_delta_max": round(float(delta.max()), 3),
        "changed_pixel_ratio": round(float(changed_mask.sum()) / n_px, 5),
        "clipped_value_ratio": round((clip_low + clip_high) / float(max(1, updated.size)), 5),
        "residual_nan_fixed": res_fixed,
        "alpha_nan_fixed": alp_fixed,
        "alpha_out_of_range_fixed": out_of_range,
        "change_epsilon": float(change_epsilon),
    }
    return out, stats


def apply_lab_residual(
    destination_bgr: np.ndarray,
    destination_bbox: Tuple[int, int, int, int],
    residual_lab: np.ndarray,
    alpha: np.ndarray,
    strength: float = 0.85,
) -> np.ndarray:
    """Backward-compatible wrapper: image only, no statistics."""
    out, _ = apply_lab_residual_with_stats(
        destination_bgr, destination_bbox, residual_lab, alpha, strength
    )
    return out


def changed_region_bbox(
    before_bgr: np.ndarray,
    after_bgr: np.ndarray,
    destination_bbox: Tuple[int, int, int, int],
    min_lab_delta: float = 3.0,
) -> Tuple[Optional[Tuple[int, int, int, int]], Dict]:
    """Threshold the ACTUAL modified region and return its bbox in patch coords.

    The label must describe the pixels that really changed, not the whole
    source rectangle. Returns (bbox_or_None, stats).
    """
    x, y, w, h = map(int, destination_bbox)
    before = cv2.cvtColor(before_bgr[y:y+h, x:x+w], cv2.COLOR_BGR2LAB).astype(np.float32)
    after = cv2.cvtColor(after_bgr[y:y+h, x:x+w], cv2.COLOR_BGR2LAB).astype(np.float32)
    delta = np.abs(after - before).max(axis=2)
    changed = (delta >= float(min_lab_delta)).astype(np.uint8)
    changed = cv2.morphologyEx(changed, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=1)

    stats = {
        "changed_pixel_ratio": round(float(changed.mean()), 5),
        "changed_pixel_count": int(changed.sum()),
        "min_lab_delta": float(min_lab_delta),
    }
    bb = mask_bbox(changed)
    if bb is None:
        stats["reason"] = "no_pixel_exceeded_delta_threshold"
        return None, stats
    stats["tight_bbox"] = bb
    return bb, stats


def mask_bbox(mask: np.ndarray) -> Optional[Tuple[int, int, int, int]]:
    """Return tight (x,y,w,h) bbox of a nonempty binary mask."""
    ys, xs = np.where(mask > 0)
    if len(xs) == 0:
        return None
    return int(xs.min()), int(ys.min()), int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1)


# ---------------------------------------------------------------------------
# Residual-branch orchestration
# ---------------------------------------------------------------------------
RESIDUAL_THRESHOLD_DEFAULTS: Dict = {
    "min_trace_regions": 2,
    "min_period_regions": 2,
    "max_angle_spread_deg": 12.0,
    "estimate": {
        "threshold_k": 3.0,
        "min_residual": 7.0,
        "min_mask_ratio": 0.003,
        "max_mask_ratio": 0.45,
        "min_reconstruction_coverage": 0.70,
        "min_ref_samples": 3,
        "max_ref_spread": 26.0,
        "max_uncertain_ratio": 0.35,
    },
    "validate": {
        "min_mask_ratio": 0.003,
        "max_mask_ratio": 0.45,
        "min_largest_component_ratio": 0.60,
        "max_tight_w_ratio": 0.95,
        "max_tight_h_ratio": 0.95,
        "max_uncertain_ratio": 0.35,
        "min_residual_mag_median": 6.0,
        "max_residual_mag_p95": 180.0,
        "max_edge_touch_ratio": 0.30,
        "edge_strip_px": 1,
        "reject_on_border_touch": False,
    },
    "transfer": {
        "lab_delta_epsilon": 1.0,   # changed 判定：单像素 LAB delta > 该阈值为"被改动"
        "min_lab_delta_median": 2.0,  # 仅对被改动像素的中位数 delta 判定弱迁移
        "min_changed_pixel_ratio": 0.002,
        "max_clipped_ratio": 0.05,
        "label_min_w": 4,
        "label_min_h": 4,
        "label_min_lab_delta": 3.0,
        "label_min_fill_ratio": 0.20,
        "label_class_id": 0,
    },
}


def _deep_merge(base: Dict, override: Dict) -> None:
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v


def _threshold_echo(thresholds: Dict) -> Dict:
    """把门槛配置拍平成 th_* 前缀的 CSV 回显列。"""
    th = dict(RESIDUAL_THRESHOLD_DEFAULTS)
    if thresholds:
        _deep_merge(th, thresholds)
    out: Dict = {}
    for k, v in th.items():
        if k in ("estimate", "validate", "transfer"):
            for kk, vv in v.items():
                out[f"th_{kk}"] = vv
        else:
            out[f"th_{k}"] = v
    return out


def _new_residual_record(sample_id, src_image, dst_image, src_bbox, dst_bbox,
                         theta_bar, period_bar) -> Dict:
    rec = {
        "sample_id": sample_id,
        "src_image": src_image,
        "dst_image": dst_image,
        "src_bbox": "" if src_bbox is None else ",".join(str(int(v)) for v in src_bbox),
        "dst_bbox": "" if dst_bbox is None else ",".join(str(int(v)) for v in dst_bbox),
        "theta_trace": "" if theta_bar is None else round(float(theta_bar), 3),
        "period_px": "" if period_bar is None else round(float(period_bar), 3),
        "angle_support": "",
        "period_support": "",
        "angle_spread_deg": "",
        "compute_ok": False,
        "compute_reason": "",
        "compute_reason_code": "",
        "coverage": "",
        "reference_uncertainty": "",
        "ref_spread_median": "",
        "ref_count_median": "",
        "residual_nan_fixed": "",
        "mask_area_ratio": "",
        "component_count": "",
        "largest_component_ratio": "",
        "mask_span_w_ratio": "",
        "mask_span_h_ratio": "",
        "edge_touch_ratio": "",
        "residual_median": "",
        "residual_p95": "",
        "quality_pass": False,
        "quality_reject_reasons": "",
        "quality_reject_codes": "",
        "delta_median_all": "",
        "delta_p95_all": "",
        "delta_median_changed": "",
        "delta_p95_changed": "",
        "modified_pixel_ratio": "",
        "clipped_value_ratio": "",
        "transfer_effective": False,
        "transfer_reason": "",
        "new_label_bbox_px": "",
        "new_label_yolo": "",
        "label_bounds_ok": "",
        "new_label_class_id": "",
        "label_fill_ratio": "",
        "baseline_fallback": True,
        "fallback_reason": "",
        # 阶段A/阶段B 分离诊断字段（placement 失败不得抹掉 source mask 结果）
        "placement_status": "ok",
        "placement_reason": "",
        "source_feature_status": "",
        "source_feature_reason": "",
        "source_mask_compute_ok": False,
        "source_mask_compute_reason": "",
        "source_mask_compute_reason_code": "",
        "source_mask_quality_pass": False,
        "source_mask_quality_reasons": "",
        "local_theta_deg": "",
        "local_period_px": "",
        "local_coherence": "",
        "local_period_conf": "",
    }
    return rec


def fallback_residual_record(sample_id, src_image, dst_image, src_bbox, dst_bbox,
                             reason: str, code: str = "placement_failed",
                             theta_bar=None, period_bar=None,
                             thresholds: Optional[Dict] = None) -> Dict:
    """Build a residual record that never reached transfer (fail-closed)."""
    t = thresholds if thresholds is not None else RESIDUAL_THRESHOLD_DEFAULTS
    rec = _new_residual_record(sample_id, src_image, dst_image, src_bbox, dst_bbox,
                               theta_bar, period_bar)
    rec["compute_reason"] = reason
    rec["compute_reason_code"] = code
    rec["fallback_reason"] = reason
    rec["baseline_fallback"] = True
    rec.update(_threshold_echo(t))
    return rec


def local_trace_period_estimate(src_gray: np.ndarray, src_bbox: Tuple[int, int, int, int],
                                margin: int, coh_threshold: float = 0.3,
                                period_conf_threshold: float = 0.4) -> Dict:
    """bbox 外上下文的局部主方向 / 周期估计（诊断候选，标记 local_estimate）。

    方法：结构张量估计走线切向角（梯度张量主轴 + 90°，与 compute_region_trace_feat
    约定一致）；沿法线方向做 1px 投影剖面，再对剖面做自相关，取首个显著峰的 lag
    作为周期。只返回 ok=True 当方向一致性(coh>=coh_threshold) 与周期峰置信度
    (period_conf>=period_conf_threshold) 均达标；否则返回 reason_code 明确拒绝。
    该估计只在全局方向/周期支持不足时作为诊断候选，不静默替代原估计。
    """
    h, w = src_gray.shape
    regions, ex1, ey1, ex2, ey2, ox, oy = extract_8_regions(src_bbox, margin, h, w)
    ctx_win = np.zeros((ey2 - ey1, ex2 - ex1), dtype=bool)
    for mask, _name, valid, _pc in regions:
        if valid:
            ctx_win |= mask
    ctx = np.zeros((h, w), dtype=bool)
    ctx[ey1:ey2, ex1:ex2] = ctx_win
    nctx = int(ctx.sum())
    if nctx < 64:
        return {"ok": False, "reason_code": "local_context_too_small"}

    gx = cv2.Sobel(src_gray, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(src_gray, cv2.CV_64F, 0, 1, ksize=3)
    gx_c, gy_c = gx[ctx], gy[ctx]
    jxx = float((gx_c * gx_c).mean())
    jyy = float((gy_c * gy_c).mean())
    jxy = float((gx_c * gy_c).mean())
    denom = jxx + jyy + 1e-12
    coh = float(np.hypot(jxx - jyy, 2.0 * jxy) / denom)
    theta_main_rad = 0.5 * np.arctan2(2.0 * jxy, jxx - jyy)
    trace_theta = float((np.degrees(theta_main_rad) + 90.0) % 180.0)

    base = {"coherence": round(coh, 4), "theta_local": round(trace_theta, 3),
            "method": "local_estimate"}
    if coh < coh_threshold:
        return dict(base, ok=False, reason_code="local_low_coherence")

    # 法线方向投影：n = x*cos(phi)+y*sin(phi)，phi = 切向+90°
    phi = np.radians((trace_theta + 90.0) % 180.0)
    ys, xs = np.nonzero(ctx)
    n = xs * np.cos(phi) + ys * np.sin(phi)
    n0 = int(np.floor(n.min())); n1 = int(np.ceil(n.max()))
    nbins = max(4, n1 - n0 + 1)
    bin_idx = np.clip(np.floor(n - n0).astype(np.int64), 0, nbins - 1)
    prof = np.zeros(nbins, dtype=np.float64)
    cnt = np.zeros(nbins, dtype=np.float64)
    vals = src_gray[ctx].astype(np.float64)
    np.add.at(prof, bin_idx, vals)
    np.add.at(cnt, bin_idx, 1.0)
    ok_bin = cnt > 0
    prof[ok_bin] /= np.maximum(cnt[ok_bin], 1.0)
    if int(ok_bin.sum()) < 20:
        return dict(base, ok=False, reason_code="local_profile_too_short")

    sig = prof - np.median(prof[ok_bin])
    sig[~ok_bin] = 0.0
    den = float(np.dot(sig, sig))
    if den <= 1e-12:
        return dict(base, ok=False, reason_code="local_flat_profile")
    maxlag = min(int(60), nbins // 3)
    if maxlag < 3:
        return dict(base, ok=False, reason_code="local_profile_too_short")
    acf = np.array([float(np.dot(sig[:nbins - l], sig[l:])) / den
                    for l in range(1, maxlag + 1)])
    # 周期峰 = 首个谷后的首个峰（跳过 lag=1 的平滑相关；真周期峰是谷后回升的峰）
    imin = None
    for l in range(1, len(acf) - 1):
        if acf[l] < acf[l - 1] and acf[l] <= acf[l + 1]:
            imin = l
            break
    start = (imin + 1) if imin is not None else 2
    if start >= len(acf) - 1:
        return dict(base, ok=False, reason_code="local_period_no_peak")
    peak_lag = None
    for l in range(start, len(acf) - 1):
        if acf[l] >= acf[l - 1] and acf[l] >= acf[l + 1]:
            peak_lag = l
            break
    if peak_lag is None:
        peak_lag = int(np.argmax(acf[start:])) + start
    peak_lag += 1  # acf 下标 l 对应 lag = l+1
    peak_val = float(acf[peak_lag - 1])
    if peak_lag < 3:
        return dict(base, ok=False, reason_code="local_period_too_small",
                    period_local=float(peak_lag), period_conf=round(peak_val, 4))
    if peak_val < period_conf_threshold:
        return dict(base, ok=False, reason_code="local_period_conf_insufficient",
                    period_local=float(peak_lag), period_conf=round(peak_val, 4))
    return dict(base, ok=True, period_local=float(peak_lag),
                period_conf=round(peak_val, 4), profile_length=int(ok_bin.sum()))


def run_source_mask_diagnosis(source_bgr: np.ndarray,
                              src_bbox: Tuple[int, int, int, int],
                              src_region_feats: List[Dict],
                              thresholds: Optional[Dict] = None,
                              coh_threshold: float = 0.3,
                              period_conf_threshold: float = 0.4,
                              sample_id: str = "",
                              src_image: str = "",
                              dst_image: str = "") -> Tuple[Dict, Dict, Dict]:
    """阶段A：源端候选 mask 诊断，与目标选址完全解耦。

    无论 placement 是否成功都会执行：全局方向/周期/支持检查 → （不足时）
    局部上下文估计（标记 local_estimate，不静默替代）→ estimate →
    validate。source_feature_status / source_mask_compute_ok /
    source_mask_quality_pass 三组状态各自独立记录。

    Returns:
        record: 源端诊断记录（含全部 mask 指标与门槛回显）。
        images: src_patch / normal_reconstruction / mask_bin / mask_overlay /
                residual_visual（其余键为 None）。
        payload: 供阶段B复用的估计产物（theta/period/mask/residual_lab/alpha/
                 estimate_info/各状态），quality_pass=False 时不可用于迁移。
    """
    th = dict(RESIDUAL_THRESHOLD_DEFAULTS)
    if thresholds:
        _deep_merge(th, thresholds)
    est_th = dict(th["estimate"])
    val_th = dict(th["validate"])

    record = _new_residual_record(sample_id, src_image, dst_image, src_bbox, None,
                                  None, None)
    record.update(_threshold_echo(th))
    record["placement_status"] = "pending"  # 由阶段B runner 回填

    images: Dict = {
        "src_patch": None,
        "mask_bin": None,
        "mask_overlay": None,
        "normal_reconstruction": None,
        "residual_visual": None,
        "mask_rot": None,
        "mask_inv_full": None,
        "mask_bbox": None,
        "dst_original": None,
        "baseline_fusion": None,
        "residual_fusion": None,
        "compare": None,
    }
    if source_bgr is not None:
        sx, sy, sw, sh = map(int, src_bbox)
        images["src_patch"] = source_bgr[sy:sy + sh, sx:sx + sw].copy()

    payload: Dict = {
        "src_bbox": tuple(int(v) for v in src_bbox),
        "theta": None, "period": None,
        "feature_status": "", "feature_reason": "",
        "compute_ok": False, "compute_reason": "", "compute_reason_code": "",
        "quality_pass": False, "quality_reasons": "",
        "defect_mask": None, "residual_lab": None, "alpha": None,
        "estimate_info": None, "thresholds": th,
    }

    support = compute_trace_texture_support(src_region_feats or [])
    record["angle_support"] = support["angle_support"]
    record["period_support"] = support["period_support"]
    record["angle_spread_deg"] = ("" if not np.isfinite(support["angle_spread_deg"])
                                  else round(float(support["angle_spread_deg"]), 3))

    theta, period = support["theta_bar"], support["period_bar"]
    fail_reasons: List[str] = []
    if theta is None or not np.isfinite(float(theta)):
        fail_reasons.append("invalid_angle")
    if period is None or not np.isfinite(float(period)) or float(period) < 2.0:
        fail_reasons.append("invalid_period")
    if int(support["angle_support"]) < int(th["min_trace_regions"]):
        fail_reasons.append(
            f"angle_support:{support['angle_support']}<{th['min_trace_regions']}")
    if int(support["period_support"]) < int(th["min_period_regions"]):
        fail_reasons.append(
            f"period_support:{support['period_support']}<{th['min_period_regions']}")
    if (np.isfinite(support["angle_spread_deg"])
            and support["angle_spread_deg"] > float(th["max_angle_spread_deg"])):
        fail_reasons.append(
            f"angle_spread:{support['angle_spread_deg']:.2f}>{th['max_angle_spread_deg']}")

    used_local = False
    if fail_reasons:
        # 全局支持不足 → 局部上下文估计诊断候选（不静默替代原估计）
        sx, sy, sw, sh = map(int, src_bbox)
        margin = max(8, int(0.25 * min(sw, sh)))  # 与 yuhua.MIN_MARGIN/MARGIN_RATIO 一致
        gray = cv2.cvtColor(source_bgr, cv2.COLOR_BGR2GRAY)
        local = local_trace_period_estimate(gray, (sx, sy, sw, sh), margin,
                                            coh_threshold, period_conf_threshold)
        if local.get("ok"):
            theta, period = float(local["theta_local"]), float(local["period_local"])
            used_local = True
            record["local_theta_deg"] = round(theta, 3)
            record["local_period_px"] = round(period, 3)
            record["local_coherence"] = local["coherence"]
            record["local_period_conf"] = local["period_conf"]
            record["source_feature_status"] = "local_estimate"
            record["source_feature_reason"] = (
                "global_support_insufficient:" + ";".join(fail_reasons)
                + f";local_estimate(coh={local['coherence']},"
                  f"period_conf={local['period_conf']})")
        else:
            record["source_feature_status"] = "failed"
            record["source_feature_reason"] = (
                "global_support_insufficient:" + ";".join(fail_reasons)
                + f";local_estimate_failed:{local.get('reason_code', '')}")
            record["source_mask_compute_ok"] = False
            record["source_mask_compute_reason"] = record["source_feature_reason"]
            record["source_mask_compute_reason_code"] = local.get(
                "reason_code", "feature_insufficient")
            record["compute_ok"] = False
            record["compute_reason"] = record["source_feature_reason"]
            record["compute_reason_code"] = record["source_mask_compute_reason_code"]
            record["fallback_reason"] = record["source_feature_reason"]
            payload["feature_status"] = "failed"
            payload["feature_reason"] = record["source_feature_reason"]
            return record, images, payload

    record["source_feature_status"] = "ok" if not used_local else "local_estimate"
    record["theta_trace"] = round(float(theta), 3)
    record["period_px"] = round(float(period), 3)
    payload["theta"] = float(theta)
    payload["period"] = float(period)
    payload["feature_status"] = record["source_feature_status"]
    payload["feature_reason"] = record["source_feature_reason"]

    # ---- estimate ----
    mask, residual_lab, alpha, info = estimate_fpc_defect_residual(
        source_bgr, src_bbox, float(theta), float(period), **est_th
    )
    record["compute_ok"] = bool(info.get("ok"))
    record["source_mask_compute_ok"] = bool(info.get("ok"))
    record["compute_reason"] = info.get("reason", "")
    record["compute_reason_code"] = info.get("reason_code", "")
    record["source_mask_compute_reason"] = info.get("reason", "")
    record["source_mask_compute_reason_code"] = info.get("reason_code", "")
    record["coverage"] = info.get("reconstruction_coverage", "")
    record["reference_uncertainty"] = info.get("uncertain_ratio", "")
    record["ref_spread_median"] = info.get("ref_spread_median", "")
    record["ref_count_median"] = info.get("ref_count_median", "")
    record["residual_nan_fixed"] = info.get("residual_nan_fixed", "")
    payload["compute_ok"] = bool(info.get("ok"))
    payload["compute_reason"] = info.get("reason", "")
    payload["compute_reason_code"] = info.get("reason_code", "")
    if not info.get("ok"):
        record["fallback_reason"] = (f"estimation_failed:{info.get('reason', '')}"
                                     f":{info.get('reason_code', '')}")
        # estimate 失败也尽量保留旋转诊断三视图（逆旋转后为空时用于定位）。
        for key, ikey in (("mask_rot", "diag_mask_rot"),
                          ("mask_inv_full", "diag_mask_inv_full"),
                          ("mask_bbox", "diag_mask_bbox")):
            arr = info.get(ikey)
            if arr is not None:
                images[key] = np.asarray(arr)
        return record, images, payload

    images["mask_bin"] = (np.asarray(mask) > 0).astype(np.uint8) * 255
    for key, ikey in (("mask_rot", "diag_mask_rot"),
                      ("mask_inv_full", "diag_mask_inv_full"),
                      ("mask_bbox", "diag_mask_bbox")):
        arr = info.get(ikey)
        if arr is not None:
            images[key] = np.asarray(arr)
    if images.get("src_patch") is not None:
        overlay = images["src_patch"].copy()
        overlay[images["mask_bin"] > 0] = (0, 0, 255)
        hh, ww = overlay.shape[:2]
        cv2.rectangle(overlay, (0, 0), (ww - 1, hh - 1), (0, 255, 255), 1)
        images["mask_overlay"] = overlay
    recon = info.get("reconstruction_patch_bgr")
    if recon is not None:
        images["normal_reconstruction"] = recon
    mag = _lab_score(np.asarray(residual_lab, dtype=np.float32))
    mag = np.where(np.isfinite(mag), mag, 0.0)
    vals = mag[np.asarray(mask) > 0]
    vmax = float(np.percentile(vals, 99)) if vals.size else 1.0
    if not np.isfinite(vmax) or vmax < 1e-6:
        vmax = 1.0
    heat_u8 = (np.clip(mag / vmax, 0.0, 1.0) * 255.0).astype(np.uint8)
    vis = cv2.applyColorMap(heat_u8, cv2.COLORMAP_JET)
    cnt, _ = cv2.findContours((np.asarray(mask) > 0).astype(np.uint8),
                              cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(vis, cnt, -1, (255, 255, 255), 1)
    images["residual_visual"] = vis

    # ---- validate ----
    quality_pass, qstats, qreasons = validate_residual_mask(
        mask, residual_lab, info, **val_th
    )
    for k in ("mask_ratio", "component_count", "largest_component_ratio",
              "tight_w_ratio", "tight_h_ratio", "edge_touch_ratio",
              "residual_mag_median_in_mask", "residual_mag_p95_in_mask"):
        record[k] = qstats.get(k, "")
    record["mask_area_ratio"] = qstats.get("mask_ratio", "")
    record["component_count"] = qstats.get("component_count", "")
    record["largest_component_ratio"] = qstats.get("largest_component_ratio", "")
    record["mask_span_w_ratio"] = qstats.get("tight_w_ratio", "")
    record["mask_span_h_ratio"] = qstats.get("tight_h_ratio", "")
    record["edge_touch_ratio"] = qstats.get("edge_touch_ratio", "")
    record["residual_median"] = qstats.get("residual_mag_median_in_mask", "")
    record["residual_p95"] = qstats.get("residual_mag_p95_in_mask", "")
    record["quality_pass"] = bool(quality_pass)
    record["source_mask_quality_pass"] = bool(quality_pass)
    record["quality_reject_reasons"] = ";".join(qreasons)
    record["source_mask_quality_reasons"] = ";".join(qreasons)
    record["quality_reject_codes"] = qstats.get("reject_reason_codes", "")
    if not quality_pass:
        record["fallback_reason"] = f"quality_gate_failed:{';'.join(qreasons)}"

    payload["quality_pass"] = bool(quality_pass)
    payload["quality_reasons"] = ";".join(qreasons)
    payload["defect_mask"] = mask
    payload["residual_lab"] = residual_lab
    payload["alpha"] = alpha
    payload["estimate_info"] = info
    return record, images, payload


def _stageB(destination_bgr: np.ndarray, dst_bbox: Tuple[int, int, int, int],
            residual_lab: np.ndarray, alpha: np.ndarray, strength: float,
            tr_th: Dict, record: Dict, images: Dict) -> Tuple[Dict, Dict]:
    """transfer + 实际变化有效性 + 新增标签（run_residual_branch 与阶段B共用）。

    任一步失败即 fail-closed：transfer_effective=False 并记录 reason。
    """
    out, tstats = apply_lab_residual_with_stats(
        destination_bgr, dst_bbox, residual_lab, alpha, strength,
        change_epsilon=float(tr_th["lab_delta_epsilon"])
    )
    record["delta_median_all"] = tstats["lab_delta_median_all"]
    record["delta_p95_all"] = tstats["lab_delta_p95_all"]
    record["delta_median_changed"] = tstats["lab_delta_median_changed"]
    record["delta_p95_changed"] = tstats["lab_delta_p95_changed"]
    record["modified_pixel_ratio"] = tstats["changed_pixel_ratio"]
    record["clipped_value_ratio"] = tstats["clipped_value_ratio"]
    images["residual_fusion"] = out

    transfer_fail = None
    # weak_actual_change 必须基于"被改动像素"的中位数 delta，不能基于包含大量
    # 未修改零值的全框中位数（全框中位数会被未改动像素压向 0，掩盖局部真实改动）。
    if float(tstats["lab_delta_median_changed"]) < float(tr_th["min_lab_delta_median"]):
        transfer_fail = (f"weak_actual_change:{tstats['lab_delta_median_changed']}"
                         f"<{tr_th['min_lab_delta_median']}")
    elif float(tstats["changed_pixel_ratio"]) < float(tr_th["min_changed_pixel_ratio"]):
        transfer_fail = (f"no_substantial_change:{tstats['changed_pixel_ratio']}"
                         f"<{tr_th['min_changed_pixel_ratio']}")
    elif float(tstats["clipped_value_ratio"]) > float(tr_th["max_clipped_ratio"]):
        transfer_fail = (f"excessive_clipping:{tstats['clipped_value_ratio']}"
                         f">{tr_th['max_clipped_ratio']}")
    if transfer_fail:
        record["transfer_effective"] = False
        record["transfer_reason"] = transfer_fail
        record["fallback_reason"] = transfer_fail
        record["baseline_fallback"] = True
        _build_compare_panel(images, dst_bbox)
        return record, images

    bb, cstats = changed_region_bbox(
        destination_bgr, out, dst_bbox, min_lab_delta=float(tr_th["label_min_lab_delta"])
    )
    if bb is None:
        record["transfer_effective"] = False
        record["transfer_reason"] = "no_modified_region_after_transfer"
        record["fallback_reason"] = "no_modified_region_after_transfer"
        record["baseline_fallback"] = True
        _build_compare_panel(images, dst_bbox)
        return record, images

    px_x, px_y = int(dst_bbox[0]) + int(bb[0]), int(dst_bbox[1]) + int(bb[1])
    px_w, px_h = int(bb[2]), int(bb[3])
    fill_ratio = float(cstats["changed_pixel_count"]) / max(1.0, float(px_w * px_h))
    record["label_fill_ratio"] = round(fill_ratio, 4)
    img_h, img_w = destination_bgr.shape[:2]

    label_problem = None
    if px_w < int(tr_th["label_min_w"]) or px_h < int(tr_th["label_min_h"]):
        label_problem = f"label_bbox_too_small:{px_w}x{px_h}"
    elif fill_ratio < float(tr_th["label_min_fill_ratio"]):
        label_problem = (f"label_region_too_scattered:fill={fill_ratio:.3f}"
                         f"<{tr_th['label_min_fill_ratio']}")
    elif px_x < 0 or px_y < 0 or px_x + px_w > img_w or px_y + px_h > img_h:
        label_problem = (f"label_bbox_out_of_bounds:{px_x},{px_y},{px_w},{px_h} "
                         f"img={img_w}x{img_h}")
    if label_problem:
        record["transfer_effective"] = False
        record["transfer_reason"] = label_problem
        record["fallback_reason"] = label_problem
        record["baseline_fallback"] = True
        _build_compare_panel(images, dst_bbox)
        return record, images

    cls_id = int(tr_th.get("label_class_id", 0))
    yolo = (cls_id,
            round((px_x + px_w / 2.0) / img_w, 6),
            round((px_y + px_h / 2.0) / img_h, 6),
            round(px_w / img_w, 6),
            round(px_h / img_h, 6))
    r_x = int(round((yolo[1] - yolo[3] / 2.0) * img_w))
    r_y = int(round((yolo[2] - yolo[4] / 2.0) * img_h))
    r_w = max(1, int(round(yolo[3] * img_w)))
    r_h = max(1, int(round(yolo[4] * img_h)))
    bounds_ok = bool(
        r_x >= 0 and r_y >= 0 and r_x + r_w <= img_w and r_y + r_h <= img_h
        and abs(r_x - px_x) <= 1 and abs(r_y - px_y) <= 1
        and abs(r_w - px_w) <= 1 and abs(r_h - px_h) <= 1
    )
    record["new_label_bbox_px"] = f"{px_x},{px_y},{px_w},{px_h}"
    record["new_label_yolo"] = " ".join(str(v) for v in yolo)
    record["label_bounds_ok"] = bounds_ok
    record["new_label_class_id"] = cls_id
    if not bounds_ok:
        record["transfer_effective"] = False
        record["transfer_reason"] = "label_roundtrip_bounds_check_failed"
        record["fallback_reason"] = "label_roundtrip_bounds_check_failed"
        record["baseline_fallback"] = True
        _build_compare_panel(images, dst_bbox)
        return record, images

    record["transfer_effective"] = True
    record["transfer_reason"] = "ok"
    record["baseline_fallback"] = False
    record["fallback_reason"] = ""
    _build_compare_panel(images, dst_bbox)
    return record, images


def run_transfer_diagnosis(destination_bgr: np.ndarray,
                           dst_bbox: Tuple[int, int, int, int],
                           payload: Dict,
                           thresholds: Optional[Dict] = None,
                           strength: float = 0.85,
                           sample_id: str = "",
                           src_image: str = "",
                           dst_image: str = "",
                           baseline_fusion_bgr: Optional[np.ndarray] = None
                           ) -> Tuple[Dict, Dict]:
    """阶段B：目标迁移诊断（仅当阶段A source mask 通过质量门槛且选址合法时调用）。

    复用 _stageB 的 transfer + 实际变化有效性 + 标签生成逻辑；任一步失败均
    fail-closed 记录 reason，transfer_effective=False，baseline_fallback=True。
    """
    th = dict(RESIDUAL_THRESHOLD_DEFAULTS)
    if thresholds:
        _deep_merge(th, thresholds)
    tr_th = dict(th["transfer"])

    record = _new_residual_record(sample_id, src_image, dst_image,
                                  payload.get("src_bbox"),
                                  tuple(int(v) for v in dst_bbox),
                                  payload.get("theta"), payload.get("period"))
    record.update(_threshold_echo(th))
    record["placement_status"] = "ok"
    record["source_feature_status"] = payload.get("feature_status", "")
    record["source_feature_reason"] = payload.get("feature_reason", "")
    record["source_mask_compute_ok"] = bool(payload.get("compute_ok"))
    record["source_mask_compute_reason"] = payload.get("compute_reason", "")
    record["source_mask_compute_reason_code"] = payload.get("compute_reason_code", "")
    record["source_mask_quality_pass"] = bool(payload.get("quality_pass"))
    record["source_mask_quality_reasons"] = payload.get("quality_reasons", "")
    record["coverage"] = payload.get("estimate_info", {}).get("reconstruction_coverage", "") if payload.get("estimate_info") else ""
    record["reference_uncertainty"] = payload.get("estimate_info", {}).get("uncertain_ratio", "") if payload.get("estimate_info") else ""

    images: Dict = {
        "src_patch": None,
        "mask_bin": None,
        "mask_overlay": None,
        "normal_reconstruction": None,
        "residual_visual": None,
        "dst_original": destination_bgr.copy(),
        "baseline_fusion": baseline_fusion_bgr,
        "residual_fusion": None,
        "compare": None,
    }
    if not payload.get("quality_pass"):
        record["transfer_effective"] = False
        record["transfer_reason"] = "source_mask_quality_not_passed"
        record["fallback_reason"] = "source_mask_quality_not_passed"
        record["baseline_fallback"] = True
        _build_compare_panel(images, dst_bbox)
        return record, images
    return _stageB(destination_bgr, dst_bbox,
                   payload["residual_lab"], payload["alpha"],
                   strength, tr_th, record, images)


def run_residual_branch(
    source_bgr: np.ndarray,
    src_bbox: Tuple[int, int, int, int],
    destination_bgr: np.ndarray,
    dst_bbox: Tuple[int, int, int, int],
    theta_bar: Optional[float],
    period_bar: Optional[float],
    src_region_feats: List[Dict],
    thresholds: Optional[Dict] = None,
    strength: float = 0.85,
    sample_id: str = "",
    src_image: str = "",
    dst_image: str = "",
    baseline_fusion_bgr: Optional[np.ndarray] = None,
) -> Tuple[Dict, Dict]:
    """Run the full residual-mask branch and report compute/quality/transfer.

    Fail-closed: the destination is only touched when the candidate mask
    passes the quality gate, and the transfer is only recorded as effective
    when the actual pixel change is substantial and local and a legal new
    label can be derived. The returned record is never a success unless all
    three stages pass.

    Returns:
        record: flat dict of CSV fields (see RESIDUAL_CSV_FIELDS).
        images: dict of diagnostic arrays (uint8 BGR / binary) that the
            caller may save; keys are the ones listed in RESIDUAL_DIAG_KEYS.
    """
    th = dict(RESIDUAL_THRESHOLD_DEFAULTS)
    if thresholds:
        _deep_merge(th, thresholds)
    est_th = dict(th["estimate"])
    val_th = dict(th["validate"])
    tr_th = dict(th["transfer"])

    record = _new_residual_record(sample_id, src_image, dst_image, src_bbox, dst_bbox,
                                  theta_bar, period_bar)
    record.update(_threshold_echo(th))

    images: Dict = {
        "src_patch": None,
        "mask_bin": None,
        "mask_overlay": None,
        "normal_reconstruction": None,
        "residual_visual": None,
        "dst_original": None if destination_bgr is None else destination_bgr.copy(),
        "baseline_fusion": baseline_fusion_bgr,
        "residual_fusion": None,
        "compare": None,
    }
    if source_bgr is not None:
        sx, sy, sw, sh = map(int, src_bbox)
        images["src_patch"] = source_bgr[sy:sy+sh, sx:sx+sw].copy()

    def _fail(compute_ok: bool, reason: str, code: str) -> Tuple[Dict, Dict]:
        record["compute_ok"] = bool(compute_ok)
        record["compute_reason"] = reason
        record["compute_reason_code"] = code
        record["fallback_reason"] = reason
        record["baseline_fallback"] = True
        # 阶段0特征门槛失败：source 状态独立记录，与 placement 无关
        record["source_feature_status"] = "failed"
        record["source_feature_reason"] = reason
        record["source_mask_compute_ok"] = False
        record["source_mask_compute_reason"] = reason
        record["source_mask_compute_reason_code"] = code
        record["source_mask_quality_pass"] = False
        _build_compare_panel(images, dst_bbox)
        return record, images

    # ---- Stage 0: angle / period / support pre-checks --------------------
    support = compute_trace_texture_support(src_region_feats or [])
    record["angle_support"] = support["angle_support"]
    record["period_support"] = support["period_support"]
    record["angle_spread_deg"] = ("" if not np.isfinite(support["angle_spread_deg"])
                                  else round(float(support["angle_spread_deg"]), 3))
    if theta_bar is None or not np.isfinite(float(theta_bar)):
        return _fail(False, "invalid trace angle from source regions", "invalid_angle")
    if period_bar is None or not np.isfinite(float(period_bar)) or float(period_bar) < 2.0:
        return _fail(False, "invalid period from source regions", "invalid_period")
    if int(support["angle_support"]) < int(th["min_trace_regions"]):
        return _fail(False,
                     f"angle support insufficient: {support['angle_support']}<{th['min_trace_regions']}",
                     "angle_support_insufficient")
    if int(support["period_support"]) < int(th["min_period_regions"]):
        return _fail(False,
                     f"period support insufficient: {support['period_support']}<{th['min_period_regions']}",
                     "period_support_insufficient")
    if np.isfinite(support["angle_spread_deg"]) and support["angle_spread_deg"] > float(th["max_angle_spread_deg"]):
        return _fail(False,
                     f"angle spread too large: {support['angle_spread_deg']:.2f}>{th['max_angle_spread_deg']}",
                     "angle_spread_too_large")

    # ---- Stage 1: estimation ---------------------------------------------
    mask, residual_lab, alpha, info = estimate_fpc_defect_residual(
        source_bgr, src_bbox, float(theta_bar), float(period_bar), **est_th
    )
    record["compute_ok"] = bool(info.get("ok"))
    record["compute_reason"] = info.get("reason", "")
    record["compute_reason_code"] = info.get("reason_code", "")
    record["coverage"] = info.get("reconstruction_coverage", "")
    record["reference_uncertainty"] = info.get("uncertain_ratio", "")
    record["ref_spread_median"] = info.get("ref_spread_median", "")
    record["ref_count_median"] = info.get("ref_count_median", "")
    record["residual_nan_fixed"] = info.get("residual_nan_fixed", "")
    record["source_feature_status"] = "ok"   # 已通过阶段0全局特征检查
    record["source_mask_compute_ok"] = bool(info.get("ok"))
    record["source_mask_compute_reason"] = info.get("reason", "")
    record["source_mask_compute_reason_code"] = info.get("reason_code", "")
    if not info.get("ok"):
        record["fallback_reason"] = (f"estimation_failed:{info.get('reason', '')}"
                                     f":{info.get('reason_code', '')}")
        record["baseline_fallback"] = True
        _build_compare_panel(images, dst_bbox)
        return record, images

    # Diagnostic images that only exist once a mask was produced.
    images["mask_bin"] = (np.asarray(mask) > 0).astype(np.uint8) * 255
    if images.get("src_patch") is not None:
        overlay = images["src_patch"].copy()
        overlay[images["mask_bin"] > 0] = (0, 0, 255)
        hh, ww = overlay.shape[:2]
        cv2.rectangle(overlay, (0, 0), (ww - 1, hh - 1), (0, 255, 255), 1)
        images["mask_overlay"] = overlay
    recon = info.get("reconstruction_patch_bgr")
    if recon is not None:
        images["normal_reconstruction"] = recon
    mag = _lab_score(np.asarray(residual_lab, dtype=np.float32))
    mag = np.where(np.isfinite(mag), mag, 0.0)
    vals = mag[np.asarray(mask) > 0]
    vmax = float(np.percentile(vals, 99)) if vals.size else 1.0
    if not np.isfinite(vmax) or vmax < 1e-6:
        vmax = 1.0
    heat_u8 = (np.clip(mag / vmax, 0.0, 1.0) * 255.0).astype(np.uint8)
    vis = cv2.applyColorMap(heat_u8, cv2.COLORMAP_JET)
    cnt, _ = cv2.findContours((np.asarray(mask) > 0).astype(np.uint8),
                              cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(vis, cnt, -1, (255, 255, 255), 1)
    images["residual_visual"] = vis

    # ---- Stage 2: quality gate ------------------------------------------
    quality_pass, qstats, qreasons = validate_residual_mask(
        mask, residual_lab, info, **val_th
    )
    for k in ("mask_ratio", "component_count", "largest_component_ratio",
              "tight_w_ratio", "tight_h_ratio", "edge_touch_ratio",
              "residual_mag_median_in_mask", "residual_mag_p95_in_mask"):
        record[k] = qstats.get(k, "")
    record["mask_area_ratio"] = qstats.get("mask_ratio", "")
    record["component_count"] = qstats.get("component_count", "")
    record["largest_component_ratio"] = qstats.get("largest_component_ratio", "")
    record["mask_span_w_ratio"] = qstats.get("tight_w_ratio", "")
    record["mask_span_h_ratio"] = qstats.get("tight_h_ratio", "")
    record["edge_touch_ratio"] = qstats.get("edge_touch_ratio", "")
    record["residual_median"] = qstats.get("residual_mag_median_in_mask", "")
    record["residual_p95"] = qstats.get("residual_mag_p95_in_mask", "")
    record["quality_pass"] = bool(quality_pass)
    record["quality_reject_reasons"] = ";".join(qreasons)
    record["quality_reject_codes"] = qstats.get("reject_reason_codes", "")
    record["source_mask_quality_pass"] = bool(quality_pass)
    record["source_mask_quality_reasons"] = ";".join(qreasons)
    if not quality_pass:
        record["fallback_reason"] = f"quality_gate_failed:{';'.join(qreasons)}"
        record["baseline_fallback"] = True
        _build_compare_panel(images, dst_bbox)
        return record, images

    # ---- Stage 3+4: transfer + effectiveness + label (shared _stageB) ----
    return _stageB(destination_bgr, dst_bbox, residual_lab, alpha, strength,
                   tr_th, record, images)


def _build_compare_panel(images: Dict, dst_bbox: Tuple[int, int, int, int]) -> None:
    """Target | baseline full-box | residual-only, same-scale local crops."""
    dst = images.get("dst_original")
    if dst is None:
        return
    dh, dw = dst.shape[:2]
    pad = 40
    x0, y0 = int(dst_bbox[0]) - pad, int(dst_bbox[1]) - pad
    cw, ch = int(dst_bbox[2]) + 2 * pad, int(dst_bbox[3]) + 2 * pad

    def rcrop(img):
        if img is None:
            img = np.zeros((dh, dw, 3), dtype=np.uint8)
        # 已是同尺度局部 crop（如诊断 baseline 面板）则直接使用
        if img.shape[0] == ch and img.shape[1] == cw:
            return img.copy()
        out = np.zeros((ch, cw, 3), dtype=img.dtype)
        sx0, sy0 = max(0, x0), max(0, y0)
        sx1, sy1 = min(dw, x0 + cw), min(dh, y0 + ch)
        if sx1 > sx0 and sy1 > sy0:
            sub = img[sy0:sy1, sx0:sx1]
            if sub.shape[0] == sy1 - sy0 and sub.shape[1] == sx1 - sx0:
                out[sy0 - y0:sy1 - y0, sx0 - x0:sx1 - x0] = sub
        return out

    panels = [rcrop(dst), rcrop(images.get("baseline_fusion")),
              rcrop(images.get("residual_fusion"))]
    titles = ["Target", "Baseline full-box", "Residual-only"]
    for p, t in zip(panels, titles):
        cv2.putText(p, t, (5, 20), cv2.FONT_HERSHEY_SIMPLEX,
                    0.42, (0, 255, 0), 1, cv2.LINE_AA)
    images["compare"] = np.hstack(panels)


# ---------------------------------------------------------------------------
# CSV output
# ---------------------------------------------------------------------------
RESIDUAL_CSV_FIELDS: List[str] = [
    "sample_id", "src_image", "dst_image", "src_bbox", "dst_bbox",
    "theta_trace", "period_px",
    "angle_support", "period_support", "angle_spread_deg",
    "compute_ok", "compute_reason", "compute_reason_code",
    "coverage", "reference_uncertainty", "ref_spread_median", "ref_count_median",
    "residual_nan_fixed",
    "mask_area_ratio", "component_count", "largest_component_ratio",
    "mask_span_w_ratio", "mask_span_h_ratio", "edge_touch_ratio",
    "residual_median", "residual_p95",
    "quality_pass", "quality_reject_reasons", "quality_reject_codes",
    "delta_median_all", "delta_p95_all", "delta_median_changed",
    "delta_p95_changed", "modified_pixel_ratio",
    "clipped_value_ratio",
    "transfer_effective", "transfer_reason",
    "new_label_bbox_px", "new_label_yolo", "label_bounds_ok",
    "new_label_class_id", "label_fill_ratio",
    "baseline_fallback", "fallback_reason",
    "placement_status", "placement_reason",
    "source_feature_status", "source_feature_reason",
    "source_mask_compute_ok", "source_mask_compute_reason",
    "source_mask_compute_reason_code",
    "source_mask_quality_pass", "source_mask_quality_reasons",
    "local_theta_deg", "local_period_px", "local_coherence", "local_period_conf",
    "th_residual_strength",
    "th_min_trace_regions", "th_min_period_regions", "th_max_angle_spread_deg",
    "th_threshold_k", "th_min_residual", "th_min_mask_ratio", "th_max_mask_ratio",
    "th_min_reconstruction_coverage", "th_min_ref_samples", "th_max_ref_spread",
    "th_max_uncertain_ratio", "th_min_largest_component_ratio",
    "th_max_tight_w_ratio", "th_max_tight_h_ratio",
    "th_min_residual_mag_median", "th_max_residual_mag_p95",
    "th_max_edge_touch_ratio", "th_edge_strip_px", "th_reject_on_border_touch",
    "th_min_lab_delta_median", "th_lab_delta_epsilon",
    "th_min_changed_pixel_ratio", "th_max_clipped_ratio",
    "th_label_min_w", "th_label_min_h", "th_label_min_lab_delta",
    "th_label_min_fill_ratio", "th_label_class_id",
]


def write_residual_diagnosis_csv(records: List[Dict], csv_path: str) -> str:
    """Write the per-sample residual-branch diagnosis CSV (utf-8-sig).

    All requested fields plus threshold echoes are written; unknown keys in a
    record are appended as extra columns when they appear.
    """
    extra_keys: List[str] = []
    for rec in records:
        for k in rec.keys():
            if k not in RESIDUAL_CSV_FIELDS and k not in extra_keys:
                extra_keys.append(k)
    fieldnames = RESIDUAL_CSV_FIELDS + sorted(extra_keys)
    os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)
    with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for rec in records:
            row = {}
            for k in fieldnames:
                v = rec.get(k, "")
                if isinstance(v, (bool,)):
                    v = int(v)
                row[k] = v
            writer.writerow(row)
    return csv_path
