"""
gen_candidate_pool.py
Generate a candidate pool (default 10000) of synthetic FPC defect samples.

Pipeline (paper Sections 3.2 / 3.3):
1. Crop a real defect patch from the annotated training set.
2. Extract a pure background region that avoids the original defect area.
3. Use NCC template matching to find the globally best texture position.
4. White-pixel ratio check, so the patch is not pasted onto a bright region.
5. Poisson seamless cloning for gradient-domain fusion.
6. Save the fused image and its YOLO-format label.

All randomness is seeded (default 42) so the pool is reproducible.
Paths are passed through command-line arguments; no code edits needed.

Usage:
    python gen_candidate_pool.py --real_img <train images> --real_lbl <train labels> \
        --out <output dir> --num 10000
"""

import os
import random
import argparse

import cv2
import numpy as np
from tqdm import tqdm


def get_white_ratio(patch, threshold=200):
    """Ratio of near-white pixels; used to avoid pasting onto bright background."""
    gray = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY)
    white_pixels = np.sum(gray > threshold)
    return white_pixels / gray.size


def get_defect_crop(img, txt_path):
    """Crop the first defect bbox from a YOLO-txt label; return None if invalid."""
    if not os.path.exists(txt_path):
        return None
    with open(txt_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
        if not lines:
            return None
        cx, cy, bw, bh = map(float, lines[0].strip().split()[1:5])

    h_img, w_img = img.shape[:2]
    x1 = max(0, int((cx - bw / 2) * w_img))
    y1 = max(0, int((cy - bh / 2) * h_img))
    x2 = min(w_img, int((cx + bw / 2) * w_img))
    y2 = min(h_img, int((cy + bh / 2) * h_img))

    if x2 <= x1 or y2 <= y1:
        return None
    return img[y1:y2, x1:x2]


def get_pure_background_candidates(img, txt_path, margin):
    """Four background regions around the original defect bbox, with safe margin."""
    if not os.path.exists(txt_path):
        return []
    with open(txt_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
        if not lines:
            return []
        cx, cy, bw, bh = map(float, lines[0].strip().split()[1:5])

    h_img, w_img = img.shape[:2]
    x1 = int((cx - bw / 2) * w_img)
    y1 = int((cy - bh / 2) * h_img)
    x2 = int((cx + bw / 2) * w_img)
    y2 = int((cy + bh / 2) * h_img)

    safe_x1 = max(0, x1 - margin)
    safe_y1 = max(0, y1 - margin)
    safe_x2 = min(w_img, x2 + margin)
    safe_y2 = min(h_img, y2 + margin)

    candidates = [
        {"box": img[0:h_img, 0:safe_x1], "area": h_img * safe_x1},
        {"box": img[0:h_img, safe_x2:w_img], "area": h_img * (w_img - safe_x2)},
        {"box": img[0:safe_y1, 0:w_img], "area": safe_y1 * w_img},
        {"box": img[safe_y2:h_img, 0:w_img], "area": (h_img - safe_y2) * w_img},
    ]
    return [c for c in candidates if c["area"] > 0 and c["box"].size > 0]


def main():
    parser = argparse.ArgumentParser(description="NCC + Poisson candidate pool generation")
    parser.add_argument("--real_img", required=True, help="training image directory")
    parser.add_argument("--real_lbl", required=True, help="training YOLO label directory")
    parser.add_argument("--out", required=True, help="output directory, images/train and labels/train will be created")
    parser.add_argument("--num", type=int, default=10000, help="number of candidate samples")
    parser.add_argument("--margin", type=int, default=15, help="safe margin around original defect bbox")
    parser.add_argument("--white_thresh", type=float, default=0.01, help="max allowed white-pixel ratio")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)

    out_img = os.path.join(args.out, "images", "train")
    out_lbl = os.path.join(args.out, "labels", "train")
    os.makedirs(out_img, exist_ok=True)
    os.makedirs(out_lbl, exist_ok=True)

    base_images = [f for f in os.listdir(args.real_img) if f.lower().endswith((".png", ".jpg"))]
    if not base_images:
        print("[ERROR] No images found in", args.real_img)
        return

    success = 0
    print(f"[INFO] Generating {args.num} candidates -> {args.out}")

    with tqdm(total=args.num) as pbar:
        while success < args.num:
            try:
                def_name = random.choice(base_images)
                raw_def_img = cv2.imread(os.path.join(args.real_img, def_name))
                def_txt = os.path.join(args.real_lbl, os.path.splitext(def_name)[0] + ".txt")
                defect_crop = get_defect_crop(raw_def_img, def_txt)
                if defect_crop is None:
                    continue
                dh, dw = defect_crop.shape[:2]

                bg_name = random.choice(base_images)
                raw_bg = cv2.imread(os.path.join(args.real_img, bg_name))
                bg_txt = os.path.join(args.real_lbl, os.path.splitext(bg_name)[0] + ".txt")
                bg_candidates = get_pure_background_candidates(raw_bg, bg_txt, args.margin)
                valid_cands = [c for c in bg_candidates
                               if c["box"].shape[0] > dh and c["box"].shape[1] > dw]
                if not valid_cands:
                    continue
                pure_bg = max(valid_cands, key=lambda x: x["area"])["box"]
                ph, pw = pure_bg.shape[:2]

                gray_defect = cv2.cvtColor(defect_crop, cv2.COLOR_BGR2GRAY)
                gray_bg = cv2.cvtColor(pure_bg, cv2.COLOR_BGR2GRAY)
                if gray_bg.shape[0] <= gray_defect.shape[0] or gray_bg.shape[1] <= gray_defect.shape[1]:
                    continue

                ncc_heatmap = cv2.matchTemplate(gray_defect, gray_bg, cv2.TM_CCOEFF_NORMED)
                _, _, _, max_loc = cv2.minMaxLoc(ncc_heatmap)
                best_center = (max_loc[0] + dw // 2, max_loc[1] + dh // 2)

                target_patch = pure_bg[max_loc[1]:max_loc[1] + dh, max_loc[0]:max_loc[0] + dw]
                if get_white_ratio(target_patch) > args.white_thresh:
                    continue

                mask = 255 * np.ones(defect_crop.shape, defect_crop.dtype)
                mixed = cv2.seamlessClone(defect_crop, pure_bg, mask, best_center, cv2.NORMAL_CLONE)

                save_name = f"candidate_{success:05d}.jpg"
                cv2.imwrite(os.path.join(out_img, save_name), mixed)

                cx_norm = best_center[0] / pw
                cy_norm = best_center[1] / ph
                w_norm = dw / pw
                h_norm = dh / ph
                label_path = os.path.join(out_lbl, f"candidate_{success:05d}.txt")
                with open(label_path, "w", encoding="utf-8") as f:
                    f.write(f"0 {cx_norm:.6f} {cy_norm:.6f} {w_norm:.6f} {h_norm:.6f}\n")

                success += 1
                pbar.update(1)
            except Exception:
                continue

    print(f"[FINISH] Generated {success} candidates, saved to {args.out}")


if __name__ == "__main__":
    main()
