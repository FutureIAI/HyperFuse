# benchmark_wgan_pipeline.py
"""
Benchmark: WGAN‑GP Generator + NCC‑Poisson + Poincaré CFSD filter
Metrics:
1. Only WGAN‑GP generate defect patch (GPU inference only)
2. WGAN‑GP + NCC + Poisson full generate pipeline
3. WGAN full generate + Poincaré CFSD filter
Compare with previous NCC‑Candidate‑Pool benchmark.
"""
import os
import cv2
import time
import random
import numpy as np
import torch
import torch.nn as nn
from PIL import Image
from torchvision import models, transforms
from tqdm import tqdm

# ====================== WGAN‑GP Generator Definition ======================
class Generator(nn.Module):
    def __init__(self, latent_dim, img_size):
        super().__init__()
        self.init_size = img_size // 8
        self.l1 = nn.Sequential(nn.Linear(latent_dim, 128*self.init_size*self.init_size))
        self.conv_blocks = nn.Sequential(
            nn.BatchNorm2d(128),
            nn.Upsample(scale_factor=2),
            nn.Conv2d(128, 128, 3, stride=1, padding=1),
            nn.BatchNorm2d(128,0.8),
            nn.ReLU(inplace=True),
            nn.Upsample(scale_factor=2),
            nn.Conv2d(128,64,3,stride=1,padding=1),
            nn.BatchNorm2d(64,0.8),
            nn.ReLU(inplace=True),
            nn.Upsample(scale_factor=2),
            nn.Conv2d(64,3,3,stride=1,padding=1),
            nn.Tanh()
        )
    def forward(self,z):
        out = self.l1(z)
        out = out.view(out.shape[0],128,self.init_size,self.init_size)
        return self.conv_blocks(out)

# -------------------------- Config ----------------------------------------
LATENT_DIM = 128
IMG_SIZE_GAN = 128
WGAN_GEN_WEIGHT = os.path.expanduser(r"~/桌面/pangjialai/gan/weight/generator_best.pth")

BASE_IMG_DIR = os.path.expanduser(r"~/桌面/pangjialai/yolo_datasets/dataset_baseline/images/train")
BASE_LBL_DIR = os.path.expanduser(r"~/桌面/pangjialai/yolo_datasets/dataset_baseline/labels/train")

TMP_SAVE = "./benchmark_wgan_tmp"
TEST_SAMPLES = 30
WARMUP = 5
NUM_BG_SAMPLE = 3
WHITE_RATIO_THRESH = 0.01
MARGIN = 15
# ==========================================================================

# ===== from your code: helper functions =====
def get_white_ratio(patch, threshold=200):
    gray = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY)
    white_pixels = np.sum(gray > threshold)
    return white_pixels / gray.size

def get_pure_background_candidates(img, txt_path, margin=15):
    if not os.path.exists(txt_path):
        return []
    with open(txt_path, 'r', encoding="utf-8") as f:
        lines = f.readlines()
    if not lines:
        return []
    cx, cy, bw, bh = map(float, lines[0].strip().split()[1:5])
    h, w, _ = img.shape
    x1, y1 = int((cx - bw / 2) * w), int((cy - bh / 2) * h)
    x2, y2 = int((cx + bw / 2) * w), int((cy + bh / 2) * h)
    safe_x1, safe_y1 = max(0, x1 - margin), max(0, y1 - margin)
    safe_x2, safe_y2 = min(w, x2 + margin), min(h, y2 + margin)
    candidates = [
        {"box": img[0:h, 0:safe_x1], "area": h * safe_x1},
        {"box": img[0:h, safe_x2:w], "area": h * (w - safe_x2)},
        {"box": img[0:safe_y1, 0:w], "area": safe_y1 * w},
        {"box": img[safe_y2:h, 0:w], "area": (h - safe_y2) * w}
    ]
    return [c for c in candidates if c["area"] > 0 and c["box"].size > 0]

# ===== Poincaré CFSD module =====
def poincare_dist(u, v, eps=1e-5):
    norm_u = torch.clamp(torch.sum(u ** 2, dim=-1), max=1 - eps)
    norm_v = torch.clamp(torch.sum(v ** 2, dim=-1), max=1 - eps)
    sq_dist = torch.sum((u - v) ** 2, dim=-1)
    x = torch.clamp(1 + 2 * sq_dist / ((1 - norm_u) * (1 - norm_v)), min=1 + eps)
    return torch.acosh(x).item()

def sample_valid_bg_patches(img_obj, defect_bbox, patch_h, patch_w, num_sample=3):
    W, H = img_obj.size
    dx1, dy1, dx2, dy2 = defect_bbox
    bg_crops = []
    max_tries = 200
    tries = 0
    while len(bg_crops) < num_sample and tries < max_tries:
        tries += 1
        x1 = np.random.randint(0, max(W - patch_w, 1))
        y1 = np.random.randint(0, max(H - patch_h, 1))
        x2 = x1 + patch_w
        y2 = y1 + patch_h
        inter_x1 = max(x1, dx1)
        inter_y1 = max(y1, dy1)
        inter_x2 = min(x2, dx2)
        inter_y2 = min(y2, dy2)
        if not (inter_x1 < inter_x2 and inter_y1 < inter_y2):
            bg_crops.append((x1, y1, x2, y2))
    return bg_crops

def cfsd_inference_only(pil_img, label_str, model, tf, device, num_bg_sample=3):
    W, H = pil_img.size
    line0 = label_str.strip().splitlines()[0].strip()
    _, cx, cy, bw, bh = map(float, line0.split())
    x1 = max(0, int((cx - bw / 2) * W))
    y1 = max(0, int((cy - bh / 2) * H))
    x2 = min(W, int((cx + bw / 2) * W))
    y2 = min(H, int((cy + bh / 2) * H))
    patch_w = x2 - x1
    patch_h = y2 - y1
    d_patch = tf(pil_img.crop((x1, y1, x2, y2))).unsqueeze(0).to(device)
    bg_crops = sample_valid_bg_patches(pil_img, (x1, y1, x2, y2), patch_h, patch_w, num_bg_sample)

    bg_feats = []
    with torch.no_grad():
        f_d = torch.nn.functional.normalize(model(d_patch), p=2, dim=1) * 0.99
        for cc in bg_crops:
            bp = tf(pil_img.crop(cc)).unsqueeze(0).to(device)
            fb = torch.nn.functional.normalize(model(bp), p=2, dim=1) * 0.99
            bg_feats.append(fb)
        f_b = torch.mean(torch.cat(bg_feats, dim=0), dim=0, keepdim=True)
        score = poincare_dist(f_d, f_b)
    return score


def gen_one_wgan_sample(netG, latent_dim, img_size_g, base_images, BASE_IMG_DIR, BASE_LBL_DIR, device):
    """
    WGAN单样本生成：内存生成缺陷patch(不从磁盘读patch)
    return (cv_bgr_mixed_image, label_str)
    """
    while True:
        noise = torch.randn((1, latent_dim), device=device)
        with torch.no_grad():
            fake_tensor = netG(noise)  # output [-1, 1]
        fake_tensor = (fake_tensor.squeeze(0).permute(1,2,0).cpu().numpy() +1.0)/2.0 *255.0
        fake_patch_bgr = fake_tensor.astype(np.uint8)
        defect_crop = fake_patch_bgr
        dh, dw, _ = defect_crop.shape

        bg_name = random.choice(base_images)
        raw_bg = cv2.imread(os.path.join(BASE_IMG_DIR, bg_name))
        bg_txt = os.path.join(BASE_LBL_DIR, os.path.splitext(bg_name)[0]+".txt")
        candidates = get_pure_background_candidates(raw_bg, bg_txt, margin=MARGIN)
        valid_cands = [c for c in candidates if c["box"].shape[0]>dh and c["box"].shape[1]>dw]
        if not valid_cands:
            continue
        pure_bg = max(valid_cands, key=lambda x:x["area"])["box"]
        ph, pw, _ = pure_bg.shape

        gray_defect = cv2.cvtColor(defect_crop, cv2.COLOR_BGR2GRAY)
        gray_bg = cv2.cvtColor(pure_bg, cv2.COLOR_BGR2GRAY)
        if gray_bg.shape[0] <= gray_defect.shape[0] or gray_bg.shape[1] <= gray_defect.shape[1]:
            continue

        ncc_heatmap = cv2.matchTemplate(gray_bg, gray_defect, cv2.TM_CCOEFF_NORMED)
        _, _, _, max_loc = cv2.minMaxLoc(ncc_heatmap)
        best_center = (max_loc[0] + dw//2, max_loc[1] + dh//2)

        target_patch = pure_bg[max_loc[1]:max_loc[1]+dh, max_loc[0]:max_loc[0]+dw]
        if get_white_ratio(target_patch) > WHITE_RATIO_THRESH:
            continue

        mask = 255 * np.ones(defect_crop.shape, defect_crop.dtype)
        mixed = cv2.seamlessClone(defect_crop, pure_bg, mask, best_center, cv2.NORMAL_CLONE)

        cx_norm = best_center[0]/pw
        cy_norm = best_center[1]/ph
        w_norm = dw/pw
        h_norm = dh/ph
        label_str = f"0 {cx_norm:.6f} {cy_norm:.6f} {w_norm:.6f} {h_norm:.6f}\n"
        return mixed, label_str


def main():
    os.makedirs(TMP_SAVE, exist_ok=True)
    base_images = [f for f in os.listdir(BASE_IMG_DIR) if f.lower().endswith((".jpg",".png"))]
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    # load WGAN‑GP Generator
    netG = Generator(latent_dim=LATENT_DIM, img_size=IMG_SIZE_GAN).to(device).eval()
    netG.load_state_dict(torch.load(WGAN_GEN_WEIGHT, map_location=device))

    # Poincaré filter model
    model_filter = models.resnet18(weights="DEFAULT").to(device).eval()
    model_filter.fc = torch.nn.Identity()
    tf = transforms.Compose([
        transforms.Resize((224,224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
    ])

    # warm‑up
    print("\n==== WGAN Benchmark Warm‑up ====")
    for _ in range(WARMUP):
        cv_bgr, lab = gen_one_wgan_sample(netG, LATENT_DIM, IMG_SIZE_GAN, base_images, BASE_IMG_DIR, BASE_LBL_DIR, device)
        pil = Image.fromarray(cv2.cvtColor(cv_bgr, cv2.COLOR_BGR2RGB))
        _ = cfsd_inference_only(pil, lab, model_filter, tf, device, NUM_BG_SAMPLE)
    torch.cuda.synchronize()

    wgan_only_times = []
    wgan_full_gen_times = []
    wgan_full_gen_filter_times = []

    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats(device)

    for idx in tqdm(range(TEST_SAMPLES), desc="WGAN benchmark running"):
        # 1. Only WGAN‑GP generate defect patch (only generator forward)
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        noise = torch.randn((1, LATENT_DIM), device=device)
        with torch.no_grad():
            fake_tensor = netG(noise)
        torch.cuda.synchronize()
        t1 = time.perf_counter()
        wgan_only_times.append((t1-t0)*1000)

        # 2. WGAN generate defect + NCC + Poisson (full generate, no filter)
        torch.cuda.synchronize()
        t2 = time.perf_counter()
        cv_bgr, lab = gen_one_wgan_sample(netG, LATENT_DIM, IMG_SIZE_GAN, base_images, BASE_IMG_DIR, BASE_LBL_DIR, device)
        torch.cuda.synchronize()
        t3 = time.perf_counter()
        wgan_full_gen_times.append((t3-t2)*1000)

        pil_rgb = Image.fromarray(cv2.cvtColor(cv_bgr, cv2.COLOR_BGR2RGB))

        # 3. WGAN full generate + CFSD filter
        torch.cuda.synchronize()
        t4 = time.perf_counter()
        _ = cfsd_inference_only(pil_rgb, lab, model_filter, tf, device, NUM_BG_SAMPLE)
        torch.cuda.synchronize()
        t5 = time.perf_counter()
        total = (t3-t2)*1000 + (t5-t4)*1000
        wgan_full_gen_filter_times.append(total)

    print("\n" + "="*75)
    print(f"WGAN‑GP Benchmark, Test samples: {TEST_SAMPLES}")
    print(f"1) Only WGAN‑GP generator(defect patch): avg={np.mean(wgan_only_times):.2f} ms, std={np.std(wgan_only_times):.2f} ms")
    print(f"2) WGAN‑GP + NCC + Poisson(full generate no filter): avg={np.mean(wgan_full_gen_times):.2f} ms, std={np.std(wgan_full_gen_times):.2f} ms")
    print(f"3) WGAN full generate + Poincaré CFSD filter: avg={np.mean(wgan_full_gen_filter_times):.2f} ms")
    if torch.cuda.is_available():
        peak_mb = torch.cuda.max_memory_allocated(device) / (1024*1024)
        print(f"GPU peak memory(WGAN pipeline): {peak_mb:.2f} MB")
    print("="*75)

if __name__ == "__main__":
    main()