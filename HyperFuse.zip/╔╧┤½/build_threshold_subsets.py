# -*- coding: utf-8 -*-
"""
庞加莱筛选阈值消融脚本（对应论文 Table 3）：
先算真实缺陷在庞加莱空间的 Fréchet 均值 mu 和距离分布，
再按多个分位数（80/85/90/95/99）取阈值，分别从候选池筛出 5k 数据集，
用于对比不同筛选阈值的检测效果。
用法:
    python build_threshold_subsets.py --real_img ... --real_lbl ... \
        --pool_img ... --pool_lbl ... --out ... --quantiles 80 85 90 95 99
"""
import os
import shutil
import json
import argparse

import torch
import numpy as np
import pandas as pd
from PIL import Image
from tqdm import tqdm
from torchvision import models, transforms


def poincare_dist(u, v, eps=1e-5):
    """庞加莱圆盘距离，c=1"""
    norm_u = torch.clamp(torch.sum(u ** 2, dim=-1), max=1.0 - eps)
    norm_v = torch.clamp(torch.sum(v ** 2, dim=-1), max=1.0 - eps)
    sq = torch.sum((u - v) ** 2, dim=-1)
    arg = torch.clamp(1.0 + 2.0 * sq / ((1.0 - norm_u) * (1.0 - norm_v)), min=1.0 + eps)
    return torch.acosh(arg)


def frechet_mean_poincare(points, num_iter=20, lr=0.1, eps=1e-5):
    """加权迭代求 Fréchet 均值，返回 [1, D] 的锚点"""
    mu = torch.mean(points, dim=0, keepdim=True)
    mu = mu / (torch.norm(mu, dim=-1, keepdim=True) + eps) * 0.99
    for _ in range(num_iter):
        d = poincare_dist(mu, points)[:, None]
        w = 1.0 / (d + eps)
        numerator = torch.sum(w * points, dim=0, keepdim=True)
        denom = torch.sum(w, dim=0, keepdim=True)
        mu = numerator / denom
        norm_mu = torch.norm(mu, dim=-1, keepdim=True)
        mu = mu / (norm_mu + eps) * 0.99
    return mu


def extract_patch_feature(img_obj, bbox, model, tf, device):
    x1, y1, x2, y2 = bbox
    crop = img_obj.crop((x1, y1, x2, y2))
    inp = tf(crop).unsqueeze(0).to(device)
    with torch.no_grad():
        feat = model(inp)
        feat = torch.nn.functional.normalize(feat, p=2, dim=1) * 0.99
    return feat


def read_first_bbox(lbl_path, W, H):
    with open(lbl_path, "r") as f:
        line = f.readline().strip()
    if not line:
        return None
    _, cx, cy, bw, bh = map(float, line.split())
    x1 = max(0, int((cx - bw / 2) * W))
    y1 = max(0, int((cy - bh / 2) * H))
    x2 = min(W, int((cx + bw / 2) * W))
    y2 = min(H, int((cy + bh / 2) * H))
    if x2 <= x1 or y2 <= y1:
        return None
    return (x1, y1, x2, y2)


def collect_real_features(img_dir, lbl_dir, model, tf, device):
    feats = []
    for name in tqdm(sorted(os.listdir(img_dir)), desc="真实集特征"):
        if not name.lower().endswith((".jpg", ".png")):
            continue
        img_path = os.path.join(img_dir, name)
        lbl_path = os.path.join(lbl_dir, os.path.splitext(name)[0] + ".txt")
        if not os.path.exists(lbl_path):
            continue
        img = Image.open(img_path).convert("RGB")
        W, H = img.size
        bbox = read_first_bbox(lbl_path, W, H)
        if bbox is None:
            continue
        feats.append(extract_patch_feature(img, bbox, model, tf, device))
    return torch.cat(feats, dim=0)


def score_candidates(img_dir, lbl_dir, mu, model, tf, device):
    rows = []
    for name in tqdm(sorted(os.listdir(img_dir)), desc="候选池打分"):
        if not name.lower().endswith((".jpg", ".png")):
            continue
        img_path = os.path.join(img_dir, name)
        lbl_path = os.path.join(lbl_dir, os.path.splitext(name)[0] + ".txt")
        if not os.path.exists(lbl_path):
            continue
        try:
            img = Image.open(img_path).convert("RGB")
            W, H = img.size
            bbox = read_first_bbox(lbl_path, W, H)
            if bbox is None:
                continue
            feat = extract_patch_feature(img, bbox, model, tf, device)
            d = poincare_dist(mu, feat).item()
            rows.append({"filename": name, "distance": d})
        except Exception:
            continue
    return pd.DataFrame(rows)


def build_subset(df, tau, top_k, pool_img, pool_lbl, out_img, out_lbl, tag):
    valid = df[df["distance"] <= tau].sort_values("distance").reset_index(drop=True)
    keep = valid.head(top_k)
    print(f"{tag}: 阈值 {tau:.4f} 及格 {len(valid)} 张，保留 {len(keep)} 张")
    os.makedirs(out_img, exist_ok=True)
    os.makedirs(out_lbl, exist_ok=True)
    for name in tqdm(keep["filename"], desc=f"复制 {tag}"):
        shutil.copy(os.path.join(pool_img, name), out_img)
        txt = os.path.splitext(name)[0] + ".txt"
        shutil.copy(os.path.join(pool_lbl, txt), out_lbl)
    return len(keep)


def main():
    parser = argparse.ArgumentParser(description="庞加莱阈值消融数据集")
    parser.add_argument("--real_img", required=True, help="真实训练集图像")
    parser.add_argument("--real_lbl", required=True, help="真实训练集标签")
    parser.add_argument("--pool_img", required=True, help="候选池图像")
    parser.add_argument("--pool_lbl", required=True, help="候选池标签")
    parser.add_argument("--out", required=True, help="输出根目录")
    parser.add_argument("--quantiles", nargs="+", type=int, default=[80, 85, 90, 95, 99])
    parser.add_argument("--top_k", type=int, default=5000)
    parser.add_argument("--save_report", action="store_true", help="保存打分报告")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"设备: {device}")
    model = models.resnet18(weights="DEFAULT").to(device).eval()
    model.fc = torch.nn.Identity()
    tf = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    real_feats = collect_real_features(args.real_img, args.real_lbl, model, tf, device)
    print(f"真实样本特征数: {real_feats.shape[0]}")
    mu = frechet_mean_poincare(real_feats)
    dists = poincare_dist(mu, real_feats)
    print(f"mu 已计算, 真实距离均值 {dists.mean():.4f}")

    df = score_candidates(args.pool_img, args.pool_lbl, mu, model, tf, device)
    print(f"候选池打分完成: {len(df)} 张")

    if args.save_report:
        df.to_csv(os.path.join(args.out, "candidate_scores.csv"), index=False)

    for q in args.quantiles:
        tau = float(np.percentile(dists.numpy(), q))
        tag = f"q{q}"
        build_subset(
            df, tau, args.top_k,
            args.pool_img, args.pool_lbl,
            os.path.join(args.out, tag, "images", "train"),
            os.path.join(args.out, tag, "labels", "train"),
            tag,
        )

    # 顺手把 mu / tau 存下来，后面训练或复现要用
    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "poincare_stats.json"), "w") as f:
        json.dump({"mu_mean": float(mu.mean().item())}, f, indent=2)
    print("完成")


if __name__ == "__main__":
    main()
