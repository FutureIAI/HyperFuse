# -*- coding: utf-8 -*-
"""
数据集统计脚本（对应论文 Table 1 的缺陷类别计数）：
按文件名前缀统计每个物理缺陷子类的图像数与缺陷框数，
并输出缺陷框尺寸分布（论文 4.1 提到缺陷"tiny size, blurred boundaries"）。
用法:
    python dataset_stats.py --img_dir .../images/train --lbl_dir .../labels/train
"""
import os
import argparse
import numpy as np


def main():
    parser = argparse.ArgumentParser(description="FPCSD 数据集统计")
    parser.add_argument("--img_dir", required=True, help="图像目录")
    parser.add_argument("--lbl_dir", required=True, help="YOLO 标签目录")
    parser.add_argument("--prefix_sep", default="_", help="文件名前缀分隔符，用于分物理子类")
    args = parser.parse_args()

    names = [f for f in os.listdir(args.img_dir) if f.lower().endswith((".jpg", ".png"))]
    stats = {}      # 前缀 -> [图像数, 缺陷框数]
    sizes = []      # (w, h) 归一化尺寸
    total_imgs = 0
    total_boxes = 0

    for name in sorted(names):
        stem = os.path.splitext(name)[0]
        prefix = stem.split(args.prefix_sep)[0]
        stats.setdefault(prefix, [0, 0])
        stats[prefix][0] += 1
        total_imgs += 1

        txt = os.path.join(args.lbl_dir, stem + ".txt")
        if not os.path.exists(txt):
            continue
        with open(txt) as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) < 5:
                    continue
                w = float(parts[3])
                h = float(parts[4])
                sizes.append((w, h))
                stats[prefix][1] += 1
                total_boxes += 1

    print(f"{'类别前缀':<16}{'图像数':>8}{'缺陷框数':>10}")
    print("-" * 38)
    for prefix, (n_img, n_box) in sorted(stats.items(), key=lambda x: -x[1][1]):
        print(f"{prefix:<16}{n_img:>8}{n_box:>10}")
    print("-" * 38)
    print(f"{'合计':<16}{total_imgs:>8}{total_boxes:>10}")

    if sizes:
        ws = np.array([s[0] for s in sizes])
        hs = np.array([s[1] for s in sizes])
        area = ws * hs
        print("\n缺陷框尺寸统计 (归一化坐标):")
        print(f"  框宽  均值 {ws.mean():.4f}  中位 {np.median(ws):.4f}  最大 {ws.max():.4f}")
        print(f"  框高  均值 {hs.mean():.4f}  中位 {np.median(hs):.4f}  最大 {hs.max():.4f}")
        print(f"  面积  均值 {area.mean():.4f}  中位 {np.median(area):.4f}")


if __name__ == "__main__":
    main()
