# -*- coding: utf-8 -*-
"""
扩增数量消融脚本（对应论文 Table 2）：
从最终扩增集（默认 5000 张）里随机抽出更小的子集，比如 1000 / 3000，
用来对比不同扩增数量对检测性能的影响。
用法:
    python build_ablation_subsets.py --src_img /path/to/ours/images/train \
        --src_lbl /path/to/ours/labels/train --out /path/to/out \
        --sizes 1000 3000
"""
import os
import shutil
import random
import argparse


def main():
    parser = argparse.ArgumentParser(description="扩增数量消融子集构建")
    parser.add_argument("--src_img", required=True)
    parser.add_argument("--src_lbl", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--sizes", nargs="+", type=int, default=[1000, 3000])
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    images = [f for f in os.listdir(args.src_img) if f.lower().endswith((".jpg", ".png"))]
    random.seed(args.seed)
    random.shuffle(images)
    print(f"源扩增集共 {len(images)} 张")

    for size in args.sizes:
        if size > len(images):
            print(f"警告: 需要 {size} 张但只有 {len(images)} 张，按全部处理")
        selected = images[:size]
        out_img = os.path.join(args.out, f"aug_{size}", "images", "train")
        out_lbl = os.path.join(args.out, f"aug_{size}", "labels", "train")
        os.makedirs(out_img, exist_ok=True)
        os.makedirs(out_lbl, exist_ok=True)

        copied = 0
        for name in selected:
            txt = os.path.splitext(name)[0] + ".txt"
            src_txt = os.path.join(args.src_lbl, txt)
            if not os.path.exists(src_txt):
                continue
            shutil.copy(os.path.join(args.src_img, name), out_img)
            shutil.copy(src_txt, out_lbl)
            copied += 1
        print(f"aug_{size}: 实际复制 {copied} 对 (图+标签) -> {os.path.join(args.out, f'aug_{size}')}")


if __name__ == "__main__":
    main()
