import os
import cv2
import numpy as np

def get_all_defects(img, txt_path):
    if not os.path.exists(txt_path):
        return []
    h_img, w_img = img.shape[:2]
    bboxes = []
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            _, cx, cy, bw, bh = map(float, parts)
            x1 = max(0, int((cx - bw / 2) * w_img))
            y1 = max(0, int((cy - bh / 2) * h_img))
            x2 = min(w_img, int((cx + bw / 2) * w_img))
            y2 = min(h_img, int((cy + bh / 2) * h_img))
            if x2 <= x1 or y2 <= y1:
                continue
            bboxes.append((x1, y1, x2, y2))
    return bboxes

def fourier_poincare_particle(img_patch, num_desc=32, max_norm=0.95):
    gray = cv2.cvtColor(img_patch, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (3, 3), 0)
    _, binary = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    cnt = max(contours, key=cv2.contourArea)
    if cnt.shape[0] < 10:
        return None
    cnt = cnt.reshape(-1, 2).astype(np.float32)
    cx = np.mean(cnt[:, 0])
    cy = np.mean(cnt[:, 1])
    z_seq = (cnt[:, 0] - cx) + 1j * (cnt[:, 1] - cy)
    fft_vals = np.fft.fft(z_seq)
    fft_vals = fft_vals[1:num_desc + 1]
    mag = np.abs(fft_vals)
    if mag[0] < 1e-6:
        return None
    feat = fft_vals / mag[0]
    z = feat[0] + 1j * (feat[1] if len(feat)>=2 else 0.0)
    norm_z = abs(z)
    if norm_z >= max_norm:
        return None
    return z

def poincare_distance(z1: complex, z2: complex):
    norm1 = abs(z1)
    norm2 = abs(z2)
    num = 2 * abs(z1 - z2)**2
    den = (1 - norm1**2) * (1 - norm2**2)
    arg = 1.0 + num / den
    arg = np.clip(arg, 1.0, None)
    return np.arccosh(arg)

def poincare_frechet_mean(z_list, max_iter=20, lr=0.2):
    if len(z_list) == 0:
        raise ValueError("质点集合为空")
    mu = np.mean(np.array(z_list))
    for _ in range(max_iter):
        grad = 0.0 + 0.0j
        for z in z_list:
            d = poincare_distance(mu, z)
            if d < 1e-8:
                continue
            mob = (z - mu) / (1.0 - np.conj(mu)*z)
            mob = mob / abs(mob)
            grad += d * mob
        grad = grad / len(z_list)
        mu = mu + lr * grad
        norm_mu = abs(mu)
        if norm_mu >= 0.95:
            mu = mu / norm_mu * 0.94
    return mu

def main():
    BASE = os.path.expanduser("~/桌面/pangjialai/VOC2007")
    IMG_DIR = os.path.join(BASE, "images")
    LBL_DIR = os.path.join(BASE, "labels")
    train_txt = os.path.join(BASE, "train.txt")

    print(f"BASE={BASE}")
    print(f"train_txt={train_txt}")
    print(f"文件是否存在:{os.path.exists(train_txt)}")
    print(f"是否是文件:{os.path.isfile(train_txt)}")

    if not os.path.isfile(train_txt):
        raise FileNotFoundError("train.txt不是有效的文件！")

    train_names = []
    with open(train_txt,"r",encoding="utf-8") as f:
        for line in f:
            s = line.strip()
            if s:
                train_names.append(s)
    print(f"读取到训练图片数量:{len(train_names)}")

    particle_list = []
    for name in train_names:
        img_path = os.path.join(IMG_DIR, name + ".jpg")
        txt_path = os.path.join(LBL_DIR, name + ".txt")
        if not os.path.exists(img_path):
            print(f"图片不存在:{img_path}")
            continue
        img = cv2.imread(img_path)
        if img is None:
            print(f"cv读取失败 {img_path}")
            continue
        boxes = get_all_defects(img, txt_path)
        for box in boxes:
            x1,y1,x2,y2 = box
            patch = img[y1:y2,x1:x2]
            z = fourier_poincare_particle(patch)
            if z is not None:
                particle_list.append(z)
    print(f"=====有效质点总数：{len(particle_list)}")
    if len(particle_list) <10:
        print("警告：有效质点太少，无法计算mu,tau")
        return

    mu = poincare_frechet_mean(particle_list)
    dists = [poincare_distance(z,mu) for z in particle_list]
    tau = np.percentile(dists,95)
    print(f"mu={mu}, |mu|={abs(mu):.3f}, tau={tau:.3f}")
    np.savez("poincare_config.npz",mu_real=np.real(mu),mu_imag=np.imag(mu),tau=tau)
    print("保存完成 poincare_config.npz")

if __name__ == "__main__":
    main()