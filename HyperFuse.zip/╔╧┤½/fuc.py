# calc_real_target_score.py
import os
import json
import torch
import numpy as np
from PIL import Image
from torchvision import models, transforms
from tqdm import tqdm


def poincare_dist(u, v, eps=1e-5):
    norm_u = torch.clamp(torch.sum(u ** 2, dim=-1), max=1 - eps)
    norm_v = torch.clamp(torch.sum(v ** 2, dim=-1), max=1 - eps)
    sq_dist = torch.sum((u - v) ** 2, dim=-1)
    x = torch.clamp(1 + 2 * sq_dist / ((1 - norm_u) * (1 - norm_v)), min=1 + eps)
    return torch.acosh(x).item()


def sample_valid_bg_patches(img_obj, defect_bbox, patch_h, patch_w, num_sample=3):
    """
    在图内避开缺陷框，随机采样num_sample块背景patch
    defect_bbox: (x1,y1,x2,y2) 像素坐标
    """
    W, H = img_obj.size
    dx1, dy1, dx2, dy2 = defect_bbox
    bg_crops = []
    max_tries = 200
    tries = 0
    while len(bg_crops) < num_sample and tries < max_tries:
        tries += 1
        x1 = np.random.randint(0, max(W - patch_w, 1))
        y1 = np.random.randint(0, max(H - patch_h, 1))
        x2 = x1 + patch_w
        y2 = y1 + patch_h
        # 判断与缺陷框是否相交，相交就跳过
        inter_x1 = max(x1, dx1)
        inter_y1 = max(y1, dy1)
        inter_x2 = min(x2, dx2)
        inter_y2 = min(y2, dy2)
        if not (inter_x1 < inter_x2 and inter_y1 < inter_y2):
            bg_crops.append((x1, y1, x2, y2))
    return bg_crops


def main():
    # ========== 修改这里为你的真实数据集路径 ==========
    REAL_IMG_DIR = r"D:\pangjialai\yolo_datasets\dataset_baseline\images\train"
    REAL_LBL_DIR = r"D:\pangjialai\yolo_datasets\dataset_baseline\labels\train"
    OUT_JSON = r"D:\pangjialai\real_cfsd_stat.json"
    NUM_BG_SAMPLE = 3

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = models.resnet18(weights="DEFAULT").to(device).eval()
    model.fc = torch.nn.Identity()

    tf = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    img_files = [f for f in os.listdir(REAL_IMG_DIR) if f.lower().endswith((".jpg", ".png"))]
    cfsd_list = []
    for fname in tqdm(img_files):
        try:
            img_path = os.path.join(REAL_IMG_DIR, fname)
            txt_path = os.path.join(REAL_LBL_DIR, os.path.splitext(fname)[0] + ".txt")
            if not os.path.exists(txt_path):
                continue
            img = Image.open(img_path).convert("RGB")
            W, H = img.size
            with open(txt_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
                if not lines:
                    continue
                cx, cy, bw, bh = map(float, lines[0].strip().split()[1:5])
            # yolo归一化转像素
            x1 = max(0, int((cx - bw / 2) * W))
            y1 = max(0, int((cy - bh / 2) * H))
            x2 = min(W, int((cx + bw / 2) * W))
            y2 = min(H, int((cy + bh / 2) * H))
            if x2 <= x1 or y2 <= y1:
                continue
            patch_w = x2 - x1
            patch_h = y2 - y1
            # 缺陷特征
            d_patch = tf(img.crop((x1, y1, x2, y2))).unsqueeze(0).to(device)
            bg_crops = sample_valid_bg_patches(img, (x1, y1, x2, y2), patch_h, patch_w, NUM_BG_SAMPLE)
            if len(bg_crops) == 0:
                continue
            bg_feats = []
            with torch.no_grad():
                f_d = torch.nn.functional.normalize(model(d_patch), p=2, dim=1) * 0.99
                for crop_coord in bg_crops:
                    b_patch = tf(img.crop(crop_coord)).unsqueeze(0).to(device)
                    fb = torch.nn.functional.normalize(model(b_patch), p=2, dim=1) * 0.99
                    bg_feats.append(fb)
                f_b = torch.mean(torch.cat(bg_feats, dim=0), dim=0, keepdim=True)
                score = poincare_dist(f_d, f_b)
            cfsd_list.append(score)
        except Exception:
            continue

    arr = np.array(cfsd_list)
    stat = {
        "count": int(len(arr)),
        "mean_cfsd": float(np.mean(arr)),
        "median_cfsd": float(np.median(arr)),
        "std_cfsd": float(np.std(arr))
    }
    print("\n====真实数据集CFSD统计结果====")
    print(f"有效样本数量: {stat['count']}")
    print(f"均值mean_cfsd: {stat['mean_cfsd']:.4f}")
    print(f"中位数median_cfsd: {stat['median_cfsd']:.4f}")
    print(f"标准差std_cfsd: {stat['std_cfsd']:.4f}")
    with open(OUT_JSON, "w", encoding="utf‑8") as fp:
        json.dump(stat, fp, indent=2)
    print(f"统计结果已保存至 {OUT_JSON}")


if __name__ == "__main__":
    main()