import os
import random

BASE = os.path.expanduser("~/桌面/pangjialai/VOC2007")
img_dir = os.path.join(BASE, "images")

all_names = []
for f in os.listdir(img_dir):
    if f.endswith(".jpg"):
        name_no_suffix = os.path.splitext(f)[0]
        all_names.append(name_no_suffix)

random.seed(42)
random.shuffle(all_names)

split_idx = int(len(all_names)*0.8)
train_list = all_names[:split_idx]
test_list = all_names[split_idx:]

with open(os.path.join(BASE,"train.txt"),"w",encoding="utf-8") as f:
    for n in train_list:
        f.write(n+"\n")

with open(os.path.join(BASE,"test.txt"),"w",encoding="utf-8") as f:
    for n in test_list:
        f.write(n+"\n")

print(f"生成完成！train:{len(train_list)}张，test:{len(test_list)}张")