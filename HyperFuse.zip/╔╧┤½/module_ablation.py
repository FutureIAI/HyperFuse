# -*- coding: utf-8 -*-
"""
模块消融数据集生成脚本（对应论文 Table 4）：
固定保留 5000 个样本，按组合开关生成不同模块配置的训练集：
    --no-ncc      去掉 NCC 检索（随机选嵌入位置），保留泊松融合
    --no-poisson  去掉泊松融合（直接覆盖粘贴），保留 NCC 检索
    --no-ncc --no-poisson  全关 = 直接 Cut-Paste（等价 cutpaste_augment.py）
全部开启 = NCC + 泊松，输出的是候选样本，后续还需要 newpangjia.py 做庞加莱筛选。
用法:
    python module_ablation.py --real_img ... --real_lbl ... --out ./ablation_ncc_off \
        --no-ncc --tag ncc_off
    python module_ablation.py --real_img ... --real_lbl ... --out ./ablation_poisson_off \
        --no-poisson --tag poisson_off
"""
import os
import argparse
import random

import cv2
import numpy as np
from tqdm import tqdm


def get_white_ratio(patch, threshold=200):
    gray = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY)
    return np.sum(gray > threshold) / gray.size


def get_defect_crop(img, txt_path, resize_to=128):
    with open(txt_path, "r") as f:
        line = f.readline().strip()
    if not line:
        return None
    _, cx, cy, bw, bh = map(float, line.split())
    h, w = img.shape[:2]
    x1 = max(0, int((cx - bw / 2) * w))
    y1 = max(0, int((cy - bh / 2) * h))
    x2 = min(w, int((cx + bw / 2) * w))
    y2 = min(h, int((cy + bh / 2) * h))
    if x2 <= x1 or y2 <= y1:
        return None
    crop = img[y1:y2, x1:x2]
    if resize_to is not None:
        crop = cv2.resize(crop, (resize_to, resize_to))
    return crop


def get_pure_bg(img, txt_path, margin=15):
    with open(txt_path, "r") as f:
        line = f.readline().strip()
    if not line:
        return None
    _, cx, cy, bw, bh = map(float, line.split())
    h, w = img.shape[:2]
    x1 = int((cx - bw / 2) * w)
    y1 = int((cy - bh / 2) * h)
    x2 = int((cx + bw / 2) * w)
    y2 = int((cy + bh / 2) * h)
    sx1 = max(0, x1 - margin)
    sy1 = max(0, y1 - margin)
    sx2 = min(w, x2 + margin)
    sy2 = min(h, y2 + margin)
    cands = [
        {"box": img[0:h, 0:sx1], "area": h * sx1},
        {"box": img[0:h, sx2:w], "area": h * (w - sx2)},
        {"box": img[0:sy1, 0:w], "area": sy1 * w},
        {"box": img[sy2:h, 0:w], "area": (h - sy2) * w},
    ]
    cands = [c for c in cands if c["area"] > 0 and c["box"].size > 0]
    if not cands:
        return None
    return max(cands, key=lambda x: x["area"])["box"]


def main():
    parser = argparse.ArgumentParser(description="模块消融数据集生成")
    parser.add_argument("--real_img", required=True, help="真实缺陷图像目录")
    parser.add_argument("--real_lbl", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--num", type=int, default=5000)
    parser.add_argument("--patch_size", type=int, default=128)
    parser.add_argument("--no_ncc", action="store_true", help="去掉 NCC 检索")
    parser.add_argument("--no_poisson", action="store_true", help="去掉泊松融合")
    parser.add_argument("--white_thresh", type=float, default=0.01)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    print(f"配置: NCC={'关' if args.no_ncc else '开'}  Poisson={'关' if args.no_poisson else '开'}")

    images = [f for f in os.listdir(args.real_img) if f.lower().endswith((".jpg", ".png"))]
    out_img = os.path.join(args.out, "images", "train")
    out_lbl = os.path.join(args.out, "labels", "train")
    os.makedirs(out_img, exist_ok=True)
    os.makedirs(out_lbl, exist_ok=True)

    gen = 0
    pbar = tqdm(total=args.num, desc="模块消融生成中")
    while gen < args.num:
        try:
            def_name = random.choice(images)
            def_img = cv2.imread(os.path.join(args.real_img, def_name))
            if def_img is None:
                continue
            def_txt = os.path.join(args.real_lbl, os.path.splitext(def_name)[0] + ".txt")
            crop = get_defect_crop(def_img, def_txt, args.patch_size)
            if crop is None:
                continue
            dh, dw = crop.shape[:2]

            bg_name = random.choice(images)
            bg_img = cv2.imread(os.path.join(args.real_img, bg_name))
            if bg_img is None:
                continue
            bg_txt = os.path.join(args.real_lbl, os.path.splitext(bg_name)[0] + ".txt")
            pure_bg = get_pure_bg(bg_img, bg_txt)
            if pure_bg is None:
                continue
            bh_, bw_ = pure_bg.shape[:2]
            if bh_ <= dh or bw_ <= dw:
                continue

            if args.no_ncc:
                x = random.randint(0, bw_ - dw)
                y = random.randint(0, bh_ - dh)
                center = (x + dw // 2, y + dh // 2)
            else:
                gray_defect = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
                gray_bg = cv2.cvtColor(pure_bg, cv2.COLOR_BGR2GRAY)
                ncc = cv2.matchTemplate(gray_defect, gray_bg, cv2.TM_CCOEFF_NORMED)
                _, _, _, max_loc = cv2.minMaxLoc(ncc)
                x, y = max_loc
                center = (x + dw // 2, y + dh // 2)
                target = pure_bg[y:y + dh, x:x + dw]
                if get_white_ratio(target) > args.white_thresh:
                    continue

            if args.no_poisson:
                mixed = pure_bg.copy()
                mixed[y:y + dh, x:x + dw] = crop
            else:
                mask = 255 * np.ones(crop.shape, crop.dtype)
                mixed = cv2.seamlessClone(crop, pure_bg, mask, center, cv2.NORMAL_CLONE)

            label_str = f"0 {center[0] / bw_:.6f} {center[1] / bh_:.6f} {dw / bw_:.6f} {dh / bh_:.6f}\n"
            name = f"abl_{gen:05d}.jpg"
            cv2.imwrite(os.path.join(out_img, name), mixed)
            with open(os.path.join(out_lbl, os.path.splitext(name)[0] + ".txt"), "w") as f:
                f.write(label_str)
            gen += 1
            pbar.update(1)
        except Exception:
            continue
    pbar.close()
    print(f"完成，共 {gen} 张 -> {args.out}")


if __name__ == "__main__":
    main()
