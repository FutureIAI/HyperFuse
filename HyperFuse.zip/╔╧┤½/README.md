# Defect Synthesis via NCC Retrieval, Poisson Blending and Poincaré-Space Quality Filtering

FPC 缺陷样本合成扩增的复现仓库。方法分三步：NCC 检索找全局最优嵌入位置，

泊松融合消边界，再用 ResNet-18 特征在庞加莱圆盘空间做质量筛选，

与真实样本的 Fréchet 均值锚点比较双曲距离，按 95% 分位阈值保留合成样本。

> 自建数据集 FPCSD-EXP2025 因保密协议不能公开，仓库只含代码。
> 数据请用自己的 FPC 缺陷图像替换，目录结构见下文。

## 目录结构与用法



```
split\_dataset.py                  真实集划分 train/val/test（论文 4.1，默认 1514/300/400）

dataset\_stats.py                  数据集统计：物理子类计数与缺陷框尺寸（Table 1）

gen\_candidate\_pool.py             候选池生成：NCC 检索 + 泊松融合（论文 3.2/3.3，默认 10000）

poincare\_filter.py                庞加莱筛选：Fréchet 均值 + 分位阈值 + top-k 截断（论文 3.4，默认 5000，可调 --top\_k）

fuc.py                            真实样本 CFSD 分布统计（筛选锚点来源）

build\_ablation\_subsets.py         扩增数量消融子集（Table 2：1000/2000/3000/4000/5000；6000 档用 poincare\_filter.py --top\_k 6000 生成）

build\_threshold\_subsets.py        筛选阈值消融数据集（Table 3：80/85/90/95/99）

module\_ablation.py                模块消融数据集（Table 4：去 NCC / 去泊松 / 全关）

wgan\_gp\_train.py                  WGAN-GP 训练（Table 4.5 WGAN 组）

wgan\_gp\_generate.py               WGAN-GP 生成 patch + NCC/泊松组装 5k

cutpaste\_augment.py               Cut-Paste 随机粘贴生成 5k（Table 4.5 Cut-Paste 组）

train\_ddpm.py                     DDPM 从零训练（论文 4.2：1000 noise timesteps）

ddpm\_generate.py                  DDPM 采样（50 步 DDIM）+ NCC/泊松组装 5k

diffusion\_generate\_dataset.py     SD-Inpaint + IP-Adapter 生成 5k（扩散组实验复现）

pku\_prepare.py                    PKU-Market-PCB 预处理（resize 768 / 类别合并 / 划分校验）

train\_yolo.py                     五组统一 YOLO 训练（论文 4.2 超参）

eval\_detection.py                 测试集检测指标评估（Table 7/8/9/10）

eval\_metrics.py                   FID / SSIM / LPIPS 生成质量评估（Table 5）

testdiff.py / testgan.py / testpang.py / testpang2.py

&#x20;                                 生成耗时与显存 benchmark（Table 6）
```

## 复现步骤



1. 安装依赖：`pip install -r requirements.txt`

2. 数据准备：`python split_dataset.py --src_img <原始图像> --src_lbl <原始标签> --out dataset_baseline`

3. 生成候选池：`python gen_candidate_pool.py --real_img <训练图像> --real_lbl <训练标签> --out dataset_10k`（输出 10k 张候选）

4. 庞加莱筛选：`python poincare_filter.py --real_img <训练图像> --real_lbl <训练标签> --pool_img dataset_10k/images/train --pool_lbl dataset_10k/labels/train --out_img dataset_ours/images/train --out_lbl dataset_ours/labels/train --top_k 5000`（输出 5k 最终扩增集；Table 2 的 6000 档把 `--top_k` 改成 6000）

5. 对比组（可选，按需跑）：

* WGAN-GP：`python wgan_gp_train.py --data <缺陷patch目录>` 后 `python wgan_gp_generate.py --weight <权重> --pool_img ... --pool_lbl ... --out dataset_wgan`

* Cut-Paste：`python cutpaste_augment.py --real_img ... --real_lbl ... --pool_img ... --pool_lbl ... --out dataset_cutpaste`

* DDPM（从零训练，论文口径）：`python train_ddpm.py --data <缺陷patch目录>` 后 `python ddpm_generate.py --model ./ddpm_model --pool_img ... --pool_lbl ... --out dataset_ddpm`

* 扩散（SD-Inpaint 实验复现）：`python diffusion_generate_dataset.py --real_img ... --real_lbl ... --out dataset_diff`

1. 训练检测器（五组同超参）：

* `python train_yolo.py --train dataset_baseline/images/train --val dataset_baseline/images/val --name baseline`

* `python train_yolo.py --train dataset_baseline/images/train,dataset_ours/images/train --val dataset_baseline/images/val --name ours`

* 其余组把 `--train` 换成对应数据集目录

1. 测试集评估：`python eval_detection.py --weights runs/detect/ours/best.pt --img_dir .../images/test --lbl_dir .../labels/test --name eval_ours`

2. 质量评估：`python eval_metrics.py --real_img ... --real_lbl ... --gen_img ... --gen_lbl ...`

3. PKU 泛化实验：先 `python pku_prepare.py --src <PKU原始目录> --out pku_yolo`，再按第 5-7 步在 PKU 数据上重跑

## 说明



* 扩散组有两套代码：`train_ddpm.py` + `ddpm_generate.py` 对应论文 4.2 声称的

  "DDPM trained from scratch with 1000 noise timesteps, 50 sampling steps"（无条件 DDPM + 50 步 DDIM）；

  `diffusion_generate_dataset.py` 是 Stable Diffusion Inpainting + IP-Adapter 的批量生成版本，

  用于复现实验中的扩散组结果（参数与 `testdiff.py` 一致）。发表时建议把论文口径与所用实现统一。

* 训练超参（论文 4.2）：YOLO 统一 epochs=100、batch=8、lr0=0.01、SGD、imgsz=640；

  检测器支持 yolo11s.pt/yolov8s.pt，PKU-Market-PCB 泛化实验同样用 `train_yolo.py` 跑。

* 所有随机流程默认固定 seed=42（`split_dataset.py` / `gen_candidate_pool.py` /

  `poincare_filter.py` / `build_ablation_subsets.py` / `build_threshold_subsets.py` /

  `module_ablation.py` / `wgan_gp_*.py` / `cutpaste_augment.py` / `train_ddpm.py` /

  `ddpm_generate.py` / `diffusion_generate_dataset.py` / `eval_metrics.py`）。

* 路径默认走命令行参数，服务器与本机路径不同时不需要改代码。

* 主流程生成脚本统一为 `gen_candidate_pool.py` + `poincare_filter.py`。

  目录里的 `10k.py` / `newpangjia.py` 是早期版本（路径硬编码，仅保留参考，不建议直接使用）。

## 引用

如果本代码对你的工作有帮助，请引用论文（待补充 BibTeX）。