# -*- coding: utf-8 -*-
"""
DDPM 从零训练脚本（对应论文 4.2 "DDPM is trained from scratch with
1000 noise timesteps"）：在真实缺陷 patch 上训练无条件扩散模型。
用法:
    python train_ddpm.py --data /path/to/defect_patches --out ./ddpm_model \
        --epochs 200 --batch 16
训练完的权重目录可直接给 ddpm_generate.py 用。
"""
import os
import argparse

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
from PIL import Image
from tqdm import tqdm

from diffusers import DDPMScheduler, UNet2DModel


class PatchDataset(Dataset):
    def __init__(self, img_dir, size=128):
        self.names = [f for f in os.listdir(img_dir) if f.lower().endswith((".jpg", ".png"))]
        self.dir = img_dir
        self.tf = transforms.Compose([
            transforms.Resize((size, size)),
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5]),
        ])

    def __len__(self):
        return len(self.names)

    def __getitem__(self, idx):
        img = Image.open(os.path.join(self.dir, self.names[idx])).convert("RGB")
        return self.tf(img)


def main():
    parser = argparse.ArgumentParser(description="DDPM 从零训练")
    parser.add_argument("--data", required=True, help="缺陷 patch 目录")
    parser.add_argument("--out", default="ddpm_model")
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--batch", type=int, default=16)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--size", type=int, default=128)
    parser.add_argument("--timesteps", type=int, default=1000, help="论文 1000 个噪声步")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"设备: {device}")

    dataset = PatchDataset(args.data, args.size)
    loader = DataLoader(dataset, batch_size=args.batch, shuffle=True,
                        num_workers=4, pin_memory=True, drop_last=True)
    print(f"训练样本数: {len(dataset)}")

    scheduler = DDPMScheduler(
        num_train_timesteps=args.timesteps,
        beta_schedule="squaredcos_cap_v2",
    )
    unet = UNet2DModel(
        sample_size=args.size,
        in_channels=3,
        out_channels=3,
        block_out_channels=(64, 128, 128, 256),
        layers_per_block=2,
    ).to(device)

    opt = torch.optim.AdamW(unet.parameters(), lr=args.lr)

    for epoch in range(1, args.epochs + 1):
        loss_sum, n_batch = 0.0, 0
        pbar = tqdm(loader, desc=f"Epoch {epoch}/{args.epochs}", leave=False)
        for clean in pbar:
            clean = clean.to(device)
            bs = clean.size(0)

            noise = torch.randn_like(clean)
            timesteps = torch.randint(0, scheduler.config.num_train_timesteps,
                                      (bs,), device=device).long()
            noisy = scheduler.add_noise(clean, noise, timesteps)

            noise_pred = unet(noisy, timesteps).sample
            loss = F.mse_loss(noise_pred, noise)

            opt.zero_grad()
            loss.backward()
            opt.step()

            loss_sum += loss.item()
            n_batch += 1
            pbar.set_postfix(loss=loss.item())

        print(f"Epoch {epoch}: loss {loss_sum / n_batch:.4f}")

        if epoch % 50 == 0 or epoch == args.epochs:
            unet.save_pretrained(args.out)
            scheduler.save_pretrained(args.out)
            print(f"  已保存 -> {args.out}")

    print(f"训练完成，权重在 {args.out}")


if __name__ == "__main__":
    main()
