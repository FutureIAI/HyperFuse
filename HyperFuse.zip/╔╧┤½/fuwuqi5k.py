"""
gen_synthesis_final_fix.py
论文原版逻辑：整张原图做背景，保留原图已有缺陷，只禁止在原有缺陷周边粘贴新缺陷，输出完整大图
修复：边界越界、粘贴位置二次校验，不切小块背景
"""
import os
import cv2
import numpy as np
import random
from tqdm import tqdm

def get_white_ratio(patch, threshold=200):
    gray = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY)
    cnt = np.sum(gray > threshold)
    return cnt / (patch.shape[0] * patch.shape[1])

def get_all_defects(img, txt_path):
    if not os.path.exists(txt_path):
        return []
    h_img, w_img = img.shape[:2]
    bboxes = []
    with open(txt_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            _, cx, cy, bw, bh = map(float, parts)
            x1 = max(0, int((cx - bw / 2) * w_img))
            y1 = max(0, int((cy - bh / 2) * h_img))
            x2 = min(w_img, int((cx + bw / 2) * w_img))
            y2 = min(h_img, int((cy + bh / 2) * h_img))
            if x2 <= x1 or y2 <= y1:
                continue
            bboxes.append((x1, y1, x2, y2))
    return bboxes

def get_allowed_mask(full_h, full_w, defect_boxes, margin=20):
    mask = np.ones((full_h, full_w), dtype=np.uint8)
    for (x1, y1, x2, y2) in defect_boxes:
        sx1 = max(0, x1 - margin)
        sy1 = max(0, y1 - margin)
        sx2 = min(full_w, x2 + margin)
        sy2 = min(full_h, y2 + margin)
        mask[sy1:sy2, sx1:sx2] = 0
    return mask

def fourier_poincare_particle(img_patch, num_desc=32, max_norm=0.95):
    gray = cv2.cvtColor(img_patch, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (3,3), 0)
    _, binary = cv2.threshold(blur,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
    contours,_ = cv2.findContours(binary,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None
    cnt = max(contours, key=cv2.contourArea)
    if cnt.shape[0] < 10:
        return None
    cnt = cnt.reshape(-1,2).astype(np.float32)
    cx = np.mean(cnt[:,0])
    cy = np.mean(cnt[:,1])
    z_seq = (cnt[:,0]-cx) + 1j*(cnt[:,1]-cy)
    fft_vals = np.fft.fft(z_seq)
    fft_vals = fft_vals[1:num_desc+1]
    mag = np.abs(fft_vals)
    if mag[0] < 1e-6:
        return None
    feat = fft_vals/mag[0]
    z = feat[0] + 1j*(feat[1] if len(feat)>=2 else 0.0)
    norm_z = abs(z)
    if norm_z >= max_norm:
        return None
    return z

def poincare_distance(z1:complex, z2:complex):
    norm1 = abs(z1)
    norm2 = abs(z2)
    num = 2*abs(z1-z2)**2
    den = (1-norm1**2)*(1-norm2**2)
    arg = 1.0 + num/den
    arg = np.clip(arg,1.0,None)
    return np.arccosh(arg)

def main():
    BASE = os.path.expanduser("~/桌面/pangjialai/VOC2007")
    IMG_DIR = os.path.join(BASE, "images")
    LBL_DIR = os.path.join(BASE, "labels")
    OUT_BASE = os.path.expanduser("~/桌面/pangjialai/dataset_synth_final")

    cfg = np.load("poincare_config.npz")
    mu = cfg["mu_real"] + 1j * cfg["mu_imag"]
    tau = float(cfg["tau"])
    print(f"加载双曲配置 mu={mu:.4f}, tau={tau:.4f}")

    TARGET = 5000
    MAX_LOOP = 400000
    WHITE_RATIO_THRESH = 0.05
    MARGIN = 20

    train_names = []
    with open(os.path.join(BASE,"train.txt"),"r",encoding="utf-8") as f:
        for line in f:
            n = line.strip()
            if n:
                train_names.append(n+".jpg")

    for sub in ["images/train","labels/train"]:
        os.makedirs(os.path.join(OUT_BASE,sub), exist_ok=True)

    success = 0
    loop_cnt = 0
    pbar = tqdm(total=TARGET)
    while success < TARGET and loop_cnt < MAX_LOOP:
        loop_cnt +=1
        try:
            # 取缺陷样本
            def_img_name = random.choice(train_names)
            def_img = cv2.imread(os.path.join(IMG_DIR, def_img_name))
            if def_img is None:
                continue
            def_txt = os.path.join(LBL_DIR, os.path.splitext(def_img_name)[0]+".txt")
            boxes_def = get_all_defects(def_img, def_txt)
            if len(boxes_def)==0:
                continue
            x1d,y1d,x2d,y2d = random.choice(boxes_def)
            defect_patch = def_img[y1d:y2d, x1d:x2d]
            dh,dw = defect_patch.shape[:2]

            # 背景：整张原图，保留原图原有缺陷
            bg_img_name = random.choice(train_names)
            bg_full = cv2.imread(os.path.join(IMG_DIR, bg_img_name))
            if bg_full is None:
                continue
            bh, bw = bg_full.shape[:2]
            bg_txt = os.path.join(LBL_DIR, os.path.splitext(bg_img_name)[0]+".txt")
            bg_boxes = get_all_defects(bg_full, bg_txt)
            mask_allow = get_allowed_mask(bh, bw, bg_boxes, margin=MARGIN)

            # 获取所有允许粘贴的连通区域
            contours,_ = cv2.findContours(mask_allow, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            rois = []
            for cnt in contours:
                xx,yy,ww,hh = cv2.boundingRect(cnt)
                if hh >= dh and ww >= dw:
                    rois.append((xx,yy,ww,hh))
            if len(rois)==0:
                continue
            rx, ry, rw, rh = random.choice(rois)
            roi_crop = bg_full[ry:ry+rh, rx:rx+rw]

            # 在允许区域内模板匹配
            gray_def = cv2.cvtColor(defect_patch, cv2.COLOR_BGR2GRAY)
            gray_roi = cv2.cvtColor(roi_crop, cv2.COLOR_BGR2GRAY)
            res = cv2.matchTemplate(gray_roi, gray_def, cv2.TM_CCOEFF_NORMED)
            _, _, _, (loc_x, loc_y) = cv2.minMaxLoc(res)

            paste_x = rx + loc_x
            paste_y = ry + loc_y

            # --------核心修复1：强制patch完全在图内，防止seamlessClone返回原图--------
            paste_x = max(0, min(paste_x, bw - dw))
            paste_y = max(0, min(paste_y, bh - dh))
            px0, py0 = paste_x, paste_y
            px1, py1 = paste_x + dw, paste_y + dh
            paste_cx = (px0 + px1)//2
            paste_cy = (py0 + py1)//2

            if not (0 <= px0 and px1 <= bw and 0 <= py0 and py1 <= bh):
                continue
            # --------核心修复2：再次校验粘贴中心点不在禁止区--------
            if mask_allow[paste_cy, paste_cx] == 0:
                continue

            check_patch = bg_full[py0:py1, px0:px1]
            if check_patch.shape[:2] != (dh,dw):
                continue
            if get_white_ratio(check_patch) > WHITE_RATIO_THRESH:
                continue

            z_syn = fourier_poincare_particle(defect_patch, num_desc=32, max_norm=0.95)
            if z_syn is None:
                continue
            d = poincare_distance(z_syn, mu)
            if d > tau:
                continue

            mask_poisson = np.ones_like(defect_patch)*255
            out_img = cv2.seamlessClone(defect_patch, bg_full, mask_poisson, (paste_cx,paste_cy), cv2.NORMAL_CLONE)

            save_name = f"syn_{success:05d}.jpg"
            out_img_path = os.path.join(OUT_BASE,"images/train", save_name)
            cv2.imwrite(out_img_path, out_img)

            cx_norm = paste_cx / bw
            cy_norm = paste_cy / bh
            w_norm = dw / bw
            h_norm = dh / bh
            label_path = os.path.join(OUT_BASE,"labels/train", f"syn_{success:05d}.txt")
            with open(label_path,"w",encoding="utf-8") as f:
                f.write(f"0 {cx_norm:.6f} {cy_norm:.6f} {w_norm:.6f} {h_norm:.6f}\n")

            success += 1
            pbar.update(1)
        except Exception:
            continue
    pbar.close()
    print(f"完成：成功{success}/{TARGET},总循环{loop_cnt}")

if __name__ == "__main__":
    main()