import os
import xml.etree.ElementTree as ET

def convert_xml_to_yolo(xml_file, img_w, img_h):
    tree = ET.parse(xml_file)
    root = tree.getroot()
    yolo_lines = []
    for obj in root.findall("object"):
        # 类别id，这里统一0；如果有多类需要自己改映射表
        cls_id = 0
        bnd = obj.find("bndbox")
        xmin = float(bnd.find("xmin").text)
        ymin = float(bnd.find("ymin").text)
        xmax = float(bnd.find("xmax").text)
        ymax = float(bnd.find("ymax").text)

        # voc坐标转yolo归一化 cx cy w h
        x_center = (xmin + xmax) / 2.0 / img_w
        y_center = (ymin + ymax) / 2.0 / img_h
        w = (xmax - xmin) / img_w
        h = (ymax - ymin) / img_h
        yolo_lines.append(f"{cls_id} {x_center:.6f} {y_center:.6f} {w:.6f} {h:.6f}")
    return yolo_lines

def main():
    base = os.path.expanduser("~/桌面/pangjialai/VOC2007")
    xml_dir = os.path.join(base, "Annotations")
    img_dir = os.path.join(base, "images")
    out_label_dir = os.path.join(base, "labels")
    os.makedirs(out_label_dir, exist_ok=True)

    xml_list = [f for f in os.listdir(xml_dir) if f.endswith(".xml")]
    print(f"总xml文件：{len(xml_list)}")

    empty_count = 0
    for xml_name in xml_list:
        name_no_ext = os.path.splitext(xml_name)[0]
        xml_path = os.path.join(xml_dir, xml_name)
        img_path = os.path.join(img_dir, name_no_ext + ".jpg")

        import cv2
        img = cv2.imread(img_path)
        if img is None:
            print(f"跳过，找不到图片：{img_path}")
            continue
        ih, iw = img.shape[:2]

        lines = convert_xml_to_yolo(xml_path, iw, ih)
        txt_out = os.path.join(out_label_dir, name_no_ext + ".txt")
        with open(txt_out, "w", encoding="utf-8") as f:
            if lines:
                f.write("\n".join(lines)+"\n")
            else:
                empty_count += 1

    print(f"转换完成！空标注文件数量：{empty_count}")
    print(f"输出labels目录：{out_label_dir}")

if __name__ == "__main__":
    main()