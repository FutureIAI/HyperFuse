# -*- coding: utf-8 -*-
"""
DDPM 采样 + 扩增集组装（对应论文 4.2 "inference uses 50 sampling steps"）：
用训练好的 DDPM（train_ddpm.py 产物）采样缺陷 patch，50 步 DDIM 加速，
再用 NCC 检索 + 泊松融合把 patch 贴到真实 PCB 背景上，凑成 5k 数据集。
组装逻辑复用 wgan_gp_generate.py 的粘贴函数。
用法:
    python ddpm_generate.py --model ./ddpm_model --pool_img ... --pool_lbl ... \
        --out ./dataset_ddpm --num 5000
"""
import os
import argparse
import random

import cv2
import numpy as np
import torch
from tqdm import tqdm

from diffusers import DDIMPipeline

from wgan_gp_generate import paste_wgan_patch


def main():
    parser = argparse.ArgumentParser(description="DDPM 采样生成扩增集")
    parser.add_argument("--model", required=True, help="train_ddpm.py 输出的模型目录")
    parser.add_argument("--pool_img", required=True, help="背景池图像目录")
    parser.add_argument("--pool_lbl", required=True, help="背景池标签目录")
    parser.add_argument("--out", required=True)
    parser.add_argument("--num", type=int, default=5000)
    parser.add_argument("--steps", type=int, default=50, help="论文 50 采样步")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    pipe = DDIMPipeline.from_pretrained(args.model).to(device)
    pipe.set_progress_bar_config(disable=True)
    print("DDPM 模型加载完成")

    out_img = os.path.join(args.out, "images", "train")
    out_lbl = os.path.join(args.out, "labels", "train")
    os.makedirs(out_img, exist_ok=True)
    os.makedirs(out_lbl, exist_ok=True)

    pool_images = [f for f in os.listdir(args.pool_img) if f.lower().endswith((".jpg", ".png"))]
    print(f"背景池: {len(pool_images)} 张")

    gen = 0
    pbar = tqdm(total=args.num, desc="DDPM 采样生成中")
    while gen < args.num:
        try:
            with torch.no_grad():
                # 生成 1 张 128x128 patch，输出范围 [-1,1]
                img = pipe(
                    generator=torch.Generator(device="cpu").manual_seed(args.seed + gen),
                    num_inference_steps=args.steps,
                    output_type="pt",
                ).images[0]
            patch = ((img.cpu().permute(1, 2, 0).numpy() * 0.5 + 0.5) * 255).astype(np.uint8)
            patch = cv2.cvtColor(patch, cv2.COLOR_RGB2BGR)

            bg_name = random.choice(pool_images)
            bg = cv2.imread(os.path.join(args.pool_img, bg_name))
            if bg is None:
                continue
            txt = os.path.join(args.pool_lbl, os.path.splitext(bg_name)[0] + ".txt")
            ret = paste_wgan_patch(bg, patch, txt)
            if ret is None:
                continue
            mixed, bg_w, bg_h, center, pw, ph = ret

            label_str = f"0 {center[0] / bg_w:.6f} {center[1] / bg_h:.6f} {pw / bg_w:.6f} {ph / bg_h:.6f}\n"
            name = f"ddpm_{gen:05d}.jpg"
            cv2.imwrite(os.path.join(out_img, name), mixed)
            with open(os.path.join(out_lbl, os.path.splitext(name)[0] + ".txt"), "w") as f:
                f.write(label_str)
            gen += 1
            pbar.update(1)
        except Exception:
            continue
    pbar.close()
    print(f"完成，共 {gen} 张 -> {args.out}")


if __name__ == "__main__":
    main()
