# benchmark_diffusion.py
import os
import random
import time
import torch
import numpy as np
from PIL import Image, ImageDraw
from diffusers import StableDiffusionInpaintPipeline
from transformers import CLIPVisionModelWithProjection

# ===================== PATH CONFIG =====================
REAL_TRAIN_IMG = "/home/cgz/桌面/pangjialai/yolo_datasets/dataset_baseline/images/train"
REAL_VAL_IMG = "/home/cgz/桌面/pangjialai/yolo_datasets/dataset_baseline/images/val"
REAL_TRAIN_LABEL = "/home/cgz/桌面/pangjialai/yolo_datasets/dataset_baseline/labels/train"
REAL_VAL_LABEL = "/home/cgz/桌面/pangjialai/yolo_datasets/dataset_baseline/labels/val"

# ===================== SEED 统一42 和之前实验对齐 =====================
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
DTYPE = torch.float16 if DEVICE == "cuda" else torch.float32
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

TARGET_ROI_SIZE = 128
DEFECT_MIN = 64
DEFECT_MAX = 96
FINAL_SIZE = 512
EDGE_PAD = 20

# ===================== 模型加载 =====================
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
os.environ["HF_HUB_DOWNLOAD_TIMEOUT"] = "300"

print("📡 正在装载 SD Inpainting 引擎...")
model_id = "runwayml/stable-diffusion-inpainting"
pipe = StableDiffusionInpaintPipeline.from_pretrained(
    model_id,
    variant="fp16",
    use_safetensors=True,
    torch_dtype=DTYPE,
    resume_download=True
).to(DEVICE)

print("🔌 正在挂载 IP-Adapter...")
image_encoder = CLIPVisionModelWithProjection.from_pretrained(
    "h94/IP-Adapter",
    subfolder="models/image_encoder",
    torch_dtype=DTYPE
).to(DEVICE)
pipe.image_encoder = image_encoder

pipe.load_ip_adapter(
    "h94/IP-Adapter",
    subfolder="models",
    weight_name="ip-adapter_sd15.safetensors"
)

pipe.set_ip_adapter_scale(1.7)
pipe.enable_vae_slicing()

PROMPT = "Micro industrial PCB photography, severe circuit defect, dark burnt marks, rough damaged area, high contrast broken copper trace, clearly visible flaw, high resolution"
NEG_PROMPT = "smooth, perfect healing, connected lines, flawless, clean background, normal wires, blurry, low resolution, seamless"
STEPS = 50
CFG_SCALE = 13.0

# ===================== 工具函数（复用原逻辑） =====================
def collect_img_label_pairs():
    pair_list = []
    VALID_IMG_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".PNG", ".JPG", ".JPEG"}

    def scan(img_dir, label_dir):
        if not os.path.exists(img_dir) or not os.path.exists(label_dir):
            return
        for fname in os.listdir(img_dir):
            base_name, ext = os.path.splitext(fname)
            if ext not in VALID_IMG_EXTS:
                continue
            img_p = os.path.join(img_dir, fname)
            label_p = os.path.join(label_dir, base_name + ".txt")
            if os.path.exists(label_p):
                pair_list.append((img_p, label_p))

    scan(REAL_TRAIN_IMG, REAL_TRAIN_LABEL)
    scan(REAL_VAL_IMG, REAL_VAL_LABEL)
    assert len(pair_list) > 0, "❌ 弹药库为空！请检查图片和txt文件名是否能对应上！"
    print(f"✅ 成功找到 原图 + txt标签 配对：{len(pair_list)} 组")
    return pair_list

def create_mask_from_yolo_txt(txt_path, img_w, img_h):
    mask_np = np.zeros((img_h, img_w), dtype=np.uint8)
    with open(txt_path, "r") as f:
        lines = f.readlines()
    for line in lines:
        parts = line.strip().split()
        if len(parts) >= 5:
            _, cx, cy, bw, bh = map(float, parts[:5])
            x_center, y_center = cx * img_w, cy * img_h
            box_w, box_h = bw * img_w, bh * img_h
            x0 = int(max(0, x_center - box_w / 2))
            y0 = int(max(0, y_center - box_h / 2))
            x1 = int(min(img_w, x_center + box_w / 2))
            y1 = int(min(img_h, y_center + box_h / 2))
            mask_np[y0:y1, x0:x1] = 255
    return mask_np

def get_valid_roi(real_mask_np, img_w, img_h):
    max_retries = 100
    for _ in range(max_retries):
        x0 = random.randint(EDGE_PAD, img_w - TARGET_ROI_SIZE - EDGE_PAD)
        y0 = random.randint(EDGE_PAD, img_h - TARGET_ROI_SIZE - EDGE_PAD)
        x1, y1 = x0 + TARGET_ROI_SIZE, y0 + TARGET_ROI_SIZE
        if (real_mask_np[y0:y1, x0:x1] > 127).sum() == 0:
            return x0, y0
    return None, None

def extract_real_defect_crop(img_pil, real_mask_np):
    y_idx, x_idx = np.where(real_mask_np > 127)
    if len(y_idx) == 0:
        return None
    y_min, y_max = np.min(y_idx), np.max(y_idx)
    x_min, x_max = np.min(x_idx), np.max(x_idx)
    pad = 5
    y_min, y_max = max(0, y_min - pad), min(img_pil.height, y_max + pad)
    x_min, x_max = max(0, x_min - pad), min(img_pil.width, x_max + pad)
    return img_pil.crop((x_min, y_min, x_max, y_max)).resize((224, 224))

def create_diff_mask_and_label(w, h, clean_x0, clean_y0):
    mask = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(mask)
    dw, dh = random.randint(DEFECT_MIN, DEFECT_MAX), random.randint(DEFECT_MIN, DEFECT_MAX)
    dx0 = clean_x0 + random.randint(0, TARGET_ROI_SIZE - dw)
    dy0 = clean_y0 + random.randint(0, TARGET_ROI_SIZE - dh)
    dx1, dy1 = dx0 + dw, dy0 + dh
    draw.rectangle([dx0, dy0, dx1, dy1], fill=255)
    return mask

def main():
    TEST_SAMPLES = 30
    WARMUP = 2
    img_label_pairs = collect_img_label_pairs()
    gen_times_ms = []

    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats(DEVICE)

    print("\n==== Diffusion Warm-up ====")
    # warm‑up
    for _ in range(WARMUP):
        img_path, txt_path = random.choice(img_label_pairs)
        orig_img = Image.open(img_path).convert("RGB").resize((FINAL_SIZE, FINAL_SIZE))
        real_mask_np = create_mask_from_yolo_txt(txt_path, FINAL_SIZE, FINAL_SIZE)
        reference_defect_img = extract_real_defect_crop(orig_img, real_mask_np)
        roi_x0, roi_y0 = get_valid_roi(real_mask_np, FINAL_SIZE, FINAL_SIZE)
        if reference_defect_img is None or roi_x0 is None:
            continue
        diff_mask_img = create_diff_mask_and_label(FINAL_SIZE, FINAL_SIZE, roi_x0, roi_y0)
        with torch.no_grad():
            _ = pipe(
                prompt=PROMPT,
                negative_prompt=NEG_PROMPT,
                image=orig_img,
                mask_image=diff_mask_img,
                ip_adapter_image=reference_defect_img,
                width=FINAL_SIZE,
                height=FINAL_SIZE,
                num_inference_steps=STEPS,
                guidance_scale=CFG_SCALE,
                strength=1.0,
                output_type="pil"
            )
    torch.cuda.synchronize()

    valid_count = 0
    from tqdm import tqdm
    pbar = tqdm(total=TEST_SAMPLES, desc="Diffusion Benchmark running")
    while valid_count < TEST_SAMPLES:
        img_path, txt_path = random.choice(img_label_pairs)
        orig_img = Image.open(img_path).convert("RGB").resize((FINAL_SIZE, FINAL_SIZE))
        real_mask_np = create_mask_from_yolo_txt(txt_path, FINAL_SIZE, FINAL_SIZE)
        reference_defect_img = extract_real_defect_crop(orig_img, real_mask_np)
        roi_x0, roi_y0 = get_valid_roi(real_mask_np, FINAL_SIZE, FINAL_SIZE)
        if reference_defect_img is None or roi_x0 is None:
            continue
        diff_mask_img = create_diff_mask_and_label(FINAL_SIZE, FINAL_SIZE, roi_x0, roi_y0)

        torch.cuda.synchronize()
        t0 = time.perf_counter()
        with torch.no_grad():
            _ = pipe(
                prompt=PROMPT,
                negative_prompt=NEG_PROMPT,
                image=orig_img,
                mask_image=diff_mask_img,
                ip_adapter_image=reference_defect_img,
                width=FINAL_SIZE,
                height=FINAL_SIZE,
                num_inference_steps=STEPS,
                guidance_scale=CFG_SCALE,
                strength=1.0,
                output_type="pil"
            )
        torch.cuda.synchronize()
        t1 = time.perf_counter()
        gen_times_ms.append((t1 - t0)*1000)
        valid_count += 1
        pbar.update(1)
    pbar.close()

    print("\n" + "="*70)
    print(f"Test samples: {TEST_SAMPLES}, SEED={SEED}")
    print(f"SD‑Inpaint+IP‑Adapter generate only: avg={np.mean(gen_times_ms):.2f} ms, std={np.std(gen_times_ms):.2f} ms")
    if torch.cuda.is_available():
        peak_mb = torch.cuda.max_memory_allocated(DEVICE) / (1024*1024)
        print(f"GPU peak memory: {peak_mb:.2f} MB")
    print("="*70)

if __name__ == "__main__":
    main()