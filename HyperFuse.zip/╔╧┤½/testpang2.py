# benchmark_full_pipeline.py
"""
Benchmark: NCC‑Poisson generate + Poincaré CFSD filter
Metrics:
1. Only generate(NCC+Poisson)
2. Only CFSD filter inference(ResNet18 + Poincaré dist, no IO/copy)
3. End‑to‑end: generate → save disk → load → CFSD score(with disk IO)
Output: per‑sample time(ms), GPU peak memory(MB)
"""
import os
import cv2
import time
import random
import numpy as np
import torch
from PIL import Image
from torchvision import models, transforms
from tqdm import tqdm

# ====================== CONFIG SWITCH ======================
SEED = 42
# True: 将缺陷crop resize到128×128，用于和WGAN公平对照实验
# False: 使用原始缺陷尺寸，我们主实验跑这个
RESIZE_DEFECT_TO_128 = False
# ==========================================================

# 固定全部模块随机种子，保证实验可复现
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

# ====================== Copy from Generate_10k_Candidates.py ======================
def get_white_ratio(patch, threshold=200):
    gray = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY)
    white_pixels = np.sum(gray > threshold)
    return white_pixels / gray.size

def get_defect_crop(img, txt_path):
    if not os.path.exists(txt_path):
        return None
    with open(txt_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        if not lines:
            return None
        cx, cy, bw, bh = map(float, lines[0].strip().split()[1:5])
    h_img, w_img = img.shape[:2]
    x1 = max(0, int((cx - bw / 2) * w_img))
    y1 = max(0, int((cy - bh / 2) * h_img))
    x2 = min(w_img, int((cx + bw / 2) * w_img))
    y2 = min(h_img, int((cy + bh / 2) * h_img))
    if x2 <= x1 or y2 <= y1:
        return None
    defect_crop = img[y1:y2, x1:x2]

    # benchmark对照开关，主实验保持False
    if RESIZE_DEFECT_TO_128:
        defect_crop = cv2.resize(defect_crop, (128, 128))
    return defect_crop

def get_pure_background_candidates(img, txt_path, margin=15):
    if not os.path.exists(txt_path):
        return []
    with open(txt_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        if not lines:
            return []
        cx, cy, bw, bh = map(float, lines[0].strip().split()[1:5])
    h_img, w_img = img.shape[:2]
    x1 = int((cx - bw / 2) * w_img)
    y1 = int((cy - bh / 2) * h_img)
    x2 = int((cx + bw / 2) * w_img)
    y2 = int((cy + bh / 2) * h_img)
    safe_x1 = max(0, x1 - margin)
    safe_y1 = max(0, y1 - margin)
    safe_x2 = min(w_img, x2 + margin)
    safe_y2 = min(h_img, y2 + margin)
    candidates = [
        {"box": img[0:h_img, 0:safe_x1], "area": h_img * safe_x1},
        {"box": img[0:h_img, safe_x2:w_img], "area": h_img * (w_img - safe_x2)},
        {"box": img[0:safe_y1, 0:w_img], "area": safe_y1 * w_img},
        {"box": img[safe_y2:h_img, 0:w_img], "area": (h_img - safe_y2) * w_img}
    ]
    return [c for c in candidates if c["area"] > 0 and c["box"].size > 0]

def generate_one_candidate(base_images, BASE_IMG_DIR, BASE_LBL_DIR, WHITE_RATIO_THRESHOLD=0.01, MARGIN=15):
    """Generate single synthetic sample, return (cv_bgr_image, label_str) or None if failed"""
    while True:
        def_name = random.choice(base_images)
        raw_def_img = cv2.imread(os.path.join(BASE_IMG_DIR, def_name))
        def_txt = os.path.join(BASE_LBL_DIR, os.path.splitext(def_name)[0] + ".txt")
        defect_crop = get_defect_crop(raw_def_img, def_txt)
        if defect_crop is None:
            continue
        dh, dw = defect_crop.shape[:2]

        bg_name = random.choice(base_images)
        raw_bg = cv2.imread(os.path.join(BASE_IMG_DIR, bg_name))
        bg_txt = os.path.join(BASE_LBL_DIR, os.path.splitext(bg_name)[0] + ".txt")
        bg_candidates = get_pure_background_candidates(raw_bg, bg_txt, margin=MARGIN)
        valid_cands = [c for c in bg_candidates if c["box"].shape[0] > dh and c["box"].shape[1] > dw]
        if not valid_cands:
            continue
        pure_bg = max(valid_cands, key=lambda x: x["area"])["box"]
        ph, pw = pure_bg.shape[:2]

        gray_defect = cv2.cvtColor(defect_crop, cv2.COLOR_BGR2GRAY)
        gray_bg = cv2.cvtColor(pure_bg, cv2.COLOR_BGR2GRAY)
        if gray_bg.shape[0] <= gray_defect.shape[0] or gray_bg.shape[1] <= gray_defect.shape[1]:
            continue

        ncc_heatmap = cv2.matchTemplate(gray_defect, gray_bg, cv2.TM_CCOEFF_NORMED)
        _, _, _, max_loc = cv2.minMaxLoc(ncc_heatmap)
        best_center = (max_loc[0] + dw // 2, max_loc[1] + dh // 2)

        target_patch = pure_bg[max_loc[1]: max_loc[1] + dh, max_loc[0]: max_loc[0] + dw]
        if get_white_ratio(target_patch) > WHITE_RATIO_THRESHOLD:
            continue

        mask = 255 * np.ones(defect_crop.shape, defect_crop.dtype)
        mixed = cv2.seamlessClone(defect_crop, pure_bg, mask, best_center, cv2.NORMAL_CLONE)

        cx_norm = best_center[0] / pw
        cy_norm = best_center[1] / ph
        w_norm = dw / pw
        h_norm = dh / ph
        label_str = f"0 {cx_norm:.6f} {cy_norm:.6f} {w_norm:.6f} {h_norm:.6f}\n"
        return mixed, label_str
# ===================================================================================

# ---------------- Poincaré CFSD module ----------------
def poincare_dist(u, v, eps=1e-5):
    norm_u = torch.clamp(torch.sum(u ** 2, dim=-1), max=1 - eps)
    norm_v = torch.clamp(torch.sum(v ** 2, dim=-1), max=1 - eps)
    sq_dist = torch.sum((u - v) ** 2, dim=-1)
    x = torch.clamp(1 + 2 * sq_dist / ((1 - norm_u) * (1 - norm_v)), min=1 + eps)
    return torch.acosh(x).item()

def sample_valid_bg_patches(img_obj, defect_bbox, patch_h, patch_w, num_sample=3):
    W, H = img_obj.size
    dx1, dy1, dx2, dy2 = defect_bbox
    bg_crops = []
    max_tries = 200
    tries = 0
    while len(bg_crops) < num_sample and tries < max_tries:
        tries += 1
        x1 = np.random.randint(0, max(W - patch_w, 1))
        y1 = np.random.randint(0, max(H - patch_h, 1))
        x2 = x1 + patch_w
        y2 = y1 + patch_h
        inter_x1 = max(x1, dx1)
        inter_y1 = max(y1, dy1)
        inter_x2 = min(x2, dx2)
        inter_y2 = min(y2, dy2)
        if not (inter_x1 < inter_x2 and inter_y1 < inter_y2):
            bg_crops.append((x1, y1, x2, y2))

    # 兜底：一个都没采到，降低约束，强制返回至少1个patch，防止空列表
    if len(bg_crops) == 0:
        x1 = np.random.randint(0, max(W - patch_w, 1))
        y1 = np.random.randint(0, max(H - patch_h, 1))
        bg_crops.append((x1, y1, x1+patch_w, y1+patch_h))

    return bg_crops

def cfsd_inference_only(pil_img, label_str, model, tf, device, num_bg_sample=3):
    """Only CFSD inference: no disk IO, no file copy"""
    W, H = pil_img.size
    line0 = label_str.strip().splitlines()[0].strip()
    _, cx, cy, bw, bh = map(float, line0.split())
    x1 = max(0, int((cx - bw / 2) * W))
    y1 = max(0, int((cy - bh / 2) * H))
    x2 = min(W, int((cx + bw / 2) * W))
    y2 = min(H, int((cy + bh / 2) * H))
    patch_w = x2 - x1
    patch_h = y2 - y1

    # patch尺寸异常兜底
    if patch_w <= 0 or patch_h <=0:
        return None

    d_patch = tf(pil_img.crop((x1, y1, x2, y2))).unsqueeze(0).to(device)
    bg_crops = sample_valid_bg_patches(pil_img, (x1, y1, x2, y2), patch_h, patch_w, num_bg_sample)

    bg_feats = []
    with torch.no_grad():
        f_d = torch.nn.functional.normalize(model(d_patch), p=2, dim=1) * 0.99
        for cc in bg_crops:
            bp = tf(pil_img.crop(cc)).unsqueeze(0).to(device)
            fb = torch.nn.functional.normalize(model(bp), p=2, dim=1) * 0.99
            bg_feats.append(fb)

        if len(bg_feats) == 0:
            return None
        f_b = torch.mean(torch.cat(bg_feats, dim=0), dim=0, keepdim=True)
        score = poincare_dist(f_d, f_b)
    return score

def main():
    # ====================== CONFIG —— 改成你服务器路径 ======================
    BASE_IMG_DIR = os.path.expanduser("~/桌面/pangjialai/yolo_datasets/huge_pool/images/train")
    BASE_LBL_DIR = os.path.expanduser("~/桌面/pangjialai/yolo_datasets/huge_pool/labels/train")
    TMP_SAVE = "./benchmark_tmp"
    TEST_SAMPLES = 30
    WARMUP = 5
    NUM_BG_SAMPLE = 3
    # =======================================================================
    os.makedirs(TMP_SAVE, exist_ok=True)
    base_images = [f for f in os.listdir(BASE_IMG_DIR) if f.lower().endswith((".jpg",".png"))]

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    print(f"RESIZE_DEFECT_TO_128 = {RESIZE_DEFECT_TO_128}, SEED={SEED}")

    # init Poincaré filter model
    model = models.resnet18(weights="DEFAULT").to(device).eval()
    model.fc = torch.nn.Identity()
    tf = transforms.Compose([
        transforms.Resize((224,224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225])
    ])

    # warm‑up
    print("\n==== Warm‑up ====")
    for _ in range(WARMUP):
        cv_bgr, lab = generate_one_candidate(base_images, BASE_IMG_DIR, BASE_LBL_DIR)
        pil = Image.fromarray(cv2.cvtColor(cv_bgr, cv2.COLOR_BGR2RGB))
        _ = cfsd_inference_only(pil, lab, model, tf, device, NUM_BG_SAMPLE)
    torch.cuda.synchronize()

    gen_only_times = []
    filter_only_times = []
    end2end_times = []
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats(device)

    # 循环收集够TEST_SAMPLES个有效样本
    valid_count = 0
    pbar = tqdm(total=TEST_SAMPLES, desc="Benchmark running")
    while valid_count < TEST_SAMPLES:
        # 1. Only generate(NCC+Poisson)
        t0 = time.perf_counter()
        cv_bgr, lab = generate_one_candidate(base_images, BASE_IMG_DIR, BASE_LBL_DIR)
        t1 = time.perf_counter()

        pil_rgb = Image.fromarray(cv2.cvtColor(cv_bgr, cv2.COLOR_BGR2RGB))

        # 2. Only CFSD filter inference
        torch.cuda.synchronize()
        t2 = time.perf_counter()
        score_ret = cfsd_inference_only(pil_rgb, lab, model, tf, device, NUM_BG_SAMPLE)
        torch.cuda.synchronize()
        t3 = time.perf_counter()
        if score_ret is None:
            continue

        # 3. End‑to‑end: generate → save disk → load → score
        torch.cuda.synchronize()
        t4 = time.perf_counter()
        tmp_jpg = os.path.join(TMP_SAVE, f"tmp_{valid_count}.jpg")
        cv2.imwrite(tmp_jpg, cv_bgr)
        img_read = Image.open(tmp_jpg).convert("RGB")
        score_e2e = cfsd_inference_only(img_read, lab, model, tf, device, NUM_BG_SAMPLE)
        torch.cuda.synchronize()
        t5 = time.perf_counter()
        if score_e2e is None:
            continue

        gen_only_times.append((t1-t0)*1000)
        filter_only_times.append((t3-t2)*1000)
        end2end_times.append((t5-t4)*1000)
        valid_count +=1
        pbar.update(1)
    pbar.close()

    # report
    print("\n" + "="*70)
    print(f"Test samples: {TEST_SAMPLES}, RESIZE_DEFECT_TO_128={RESIZE_DEFECT_TO_128}")
    print(f"1) NCC+Poisson generate only: avg={np.mean(gen_only_times):.2f} ms, std={np.std(gen_only_times):.2f} ms")
    print(f"2) Poincaré CFSD filter only: avg={np.mean(filter_only_times):.2f} ms, std={np.std(filter_only_times):.2f} ms")
    print(f"3) End‑to‑end(generate+save+load+filter): avg={np.mean(end2end_times):.2f} ms, std={np.std(end2end_times):.2f} ms")
    if torch.cuda.is_available():
        peak_mb = torch.cuda.max_memory_allocated(device) / (1024*1024)
        print(f"GPU peak memory(whole pipeline): {peak_mb:.2f} MB")
    print("="*70)

if __name__ == "__main__":
    main()