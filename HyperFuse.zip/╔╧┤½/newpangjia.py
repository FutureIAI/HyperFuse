import os
import shutil
import json
import torch
import numpy as np
import pandas as pd
from torchvision import models, transforms
from PIL import Image
from tqdm import tqdm


def poincare_dist(u, v, eps=1e-5):
    """庞加莱圆盘距离 c=1，输入特征已约束在圆盘内部 ||x||<1"""
    norm_u = torch.clamp(torch.sum(u ** 2, dim=-1), max=1.0 - eps)
    norm_v = torch.clamp(torch.sum(v ** 2, dim=-1), max=1.0 - eps)
    sq = torch.sum((u - v) ** 2, dim=-1)
    arg = torch.clamp(1.0 + 2.0 * sq / ((1.0 - norm_u) * (1.0 - norm_v)), min=1.0 + eps)
    return torch.acosh(arg)


def frechet_mean_poincare(points, num_iter=20, lr=0.1, eps=1e-5):
    """庞加莱圆盘Fréchet均值迭代求解，返回锚点 mu [1,D]"""
    mu = torch.mean(points, dim=0, keepdim=True)
    mu = mu / (torch.norm(mu, dim=-1, keepdim=True) + eps) * 0.99
    for _ in range(num_iter):
        d = poincare_dist(mu, points)[:, None]
        w = 1.0 / (d + eps)
        numerator = torch.sum(w * points, dim=0, keepdim=True)
        denom = torch.sum(w, dim=0, keepdim=True)
        mu = numerator / denom
        norm_mu = torch.norm(mu, dim=-1, keepdim=True)
        mu = mu / (norm_mu + eps) * 0.99
    return mu


def extract_patch_feature(img_obj, bbox, model, tf, device):
    """抠缺陷patch，提取特征并约束到庞加莱圆盘内"""
    x1, y1, x2, y2 = bbox
    crop = img_obj.crop((x1, y1, x2, y2))
    inp = tf(crop).unsqueeze(0).to(device)
    with torch.no_grad():
        feat = model(inp)
        feat = torch.nn.functional.normalize(feat, p=2, dim=1) * 0.99
    return feat


def compute_real_statistics(real_img_dir, real_lbl_dir, model, tf, device, out_json):
    """
    遍历真实训练集，提取缺陷patch特征
    计算Fréchet锚点mu、95%分位数阈值tau
    """
    img_list = [f for f in os.listdir(real_img_dir) if f.lower().endswith((".jpg", ".png"))]
    feat_list = []
    for fname in tqdm(img_list, desc="Calc real‑set Fréchet stat"):
        img_path = os.path.join(real_img_dir, fname)
        txt_path = os.path.join(real_lbl_dir, os.path.splitext(fname)[0] + ".txt")
        if not os.path.exists(txt_path):
            continue
        img = Image.open(img_path).convert("RGB")
        W, H = img.size
        with open(txt_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
            if not lines:
                continue
            _, cx, cy, bw, bh = map(float, lines[0].strip().split())
        x1 = max(0, int((cx - bw / 2) * W))
        y1 = max(0, int((cy - bh / 2) * H))
        x2 = min(W, int((cx + bw / 2) * W))
        y2 = min(H, int((cy + bh / 2) * H))
        if x2 <= x1 or y2 <= y1:
            continue
        feat = extract_patch_feature(img, (x1, y1, x2, y2), model, tf, device)
        feat_list.append(feat)

    all_points = torch.cat(feat_list, dim=0)
    mu = frechet_mean_poincare(all_points)
    dists = poincare_dist(mu, all_points)
    tau = float(torch.quantile(dists, 0.95))

    stat = {
        "num_real_samples": int(all_points.shape[0]),
        "tau_95quantile": tau,
        "mu_shape": list(mu.shape),
    }
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(stat, f, ensure_ascii=False, indent=2)
    print(f"✅真实集统计完成：有效样本 {stat['num_real_samples']}, τ(95%)={tau:.4f}，保存 {out_json}")
    return mu, tau


def filter_candidates(candidate_img_dir, candidate_lbl_dir, mu, tau, top_k, model, tf, device, out_img_dir, out_lbl_dir, report_csv):
    """
    1.全部候选计算到锚点距离
    2.初筛 d <= tau
    3.合格样本按距离升序排序，取最多top_k
    4.输出数据集 + 打分报告csv
    """
    os.makedirs(out_img_dir, exist_ok=True)
    os.makedirs(out_lbl_dir, exist_ok=True)
    img_files = [f for f in os.listdir(candidate_img_dir) if f.lower().endswith((".jpg", ".png"))]

    all_results = []
    score_fail = 0

    for fname in tqdm(img_files, desc="Score candidate pool"):
        img_path = os.path.join(candidate_img_dir, fname)
        txt_path = os.path.join(candidate_lbl_dir, os.path.splitext(fname)[0] + ".txt")
        if not os.path.exists(txt_path):
            score_fail += 1
            continue
        try:
            img = Image.open(img_path).convert("RGB")
            W, H = img.size
            with open(txt_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
                if not lines:
                    score_fail += 1
                    continue
                _, cx, cy, bw, bh = map(float, lines[0].strip().split())
            x1 = max(0, int((cx - bw / 2) * W))
            y1 = max(0, int((cy - bh / 2) * H))
            x2 = min(W, int((cx + bw / 2) * W))
            y2 = min(H, int((cy + bh / 2) * H))
            if x2 <= x1 or y2 <= y1:
                score_fail += 1
                continue

            feat = extract_patch_feature(img, (x1, y1, x2, y2), model, tf, device)
            d = poincare_dist(mu, feat).item()
            all_results.append({"filename": fname, "distance_to_mu": d})
        except Exception:
            score_fail += 1
            continue

    df = pd.DataFrame(all_results)
    df.to_csv(report_csv, index=False, encoding="utf-8")
    print(f"\n📝完整打分报告保存至 {report_csv}")

    # 步骤1：阈值初筛，剔除离群
    valid_df = df[df["distance_to_mu"] <= tau].copy()
    print(f"🔍候选总数:{len(img_files)}，打分成功:{len(all_results)}，初筛通过(d<=τ):{len(valid_df)}，失败/跳过:{score_fail}")

    # 步骤2：按距离升序排序，取最多top‑K
    valid_sorted = valid_df.sort_values(by="distance_to_mu", ascending=True).reset_index(drop=True)
    keep_df = valid_sorted.head(top_k)
    final_num = len(keep_df)

    if final_num < top_k:
        print(f"⚠️警告：阈值初筛合格样本只有 {final_num}，不足设定Top‑{top_k}，全部保留。")
    else:
        print(f"✅初筛合格样本大于{top_k}，选取距离最优前{top_k}张。")

    # 复制文件
    keep_files = keep_df["filename"].tolist()
    for fname in tqdm(keep_files, desc="Copy final dataset"):
        shutil.copy(os.path.join(candidate_img_dir, fname), os.path.join(out_img_dir, fname))
        txt_name = os.path.splitext(fname)[0] + ".txt"
        shutil.copy(os.path.join(candidate_lbl_dir, txt_name), os.path.join(out_lbl_dir, txt_name))

    print("\n" + "=" * 60)
    print(f"🏆过滤完成！最终输出扩增样本数量：{final_num}")
    print(f"📂输出图片目录：{out_img_dir}")
    print("=" * 60)


def main():
    # ======================【修改为你本机路径】======================
    REAL_IMG_DIR = r"D:\pangjialai\yolo_datasets\dataset_baseline\images\train"
    REAL_LBL_DIR = r"D:\pangjialai\yolo_datasets\dataset_baseline\labels\train"

    CANDIDATE_IMG = r"D:\pangjialai\dataset_10k_candidate_pool\images\train"
    CANDIDATE_LBL = r"D:\pangjialai\dataset_10k_candidate_pool\labels\train"

    OUT_IMG = r"D:\pangjialai\dataset_filtered\images\train"
    OUT_LBL = r"D:\pangjialai\dataset_filtered\labels\train"

    STAT_JSON = r"D:\pangjialai\real_frechet_stat.json"
    REPORT_CSV = r"D:\pangjialai\filter_score_report.csv"

    TOP_K = 5000
    # ==============================================================

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = models.resnet18(weights="DEFAULT").to(device).eval()
    model.fc = torch.nn.Identity()

    tf = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    mu, tau = compute_real_statistics(REAL_IMG_DIR, REAL_LBL_DIR, model, tf, device, STAT_JSON)
    filter_candidates(CANDIDATE_IMG, CANDIDATE_LBL, mu, tau, TOP_K, model, tf, device, OUT_IMG, OUT_LBL, REPORT_CSV)


if __name__ == "__main__":
    main()