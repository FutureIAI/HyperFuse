"""
Generate_10k_Candidates.py
Generate synthetic defect candidate pool for Poincaré‑ball filtering pipeline.

Workflow:
1. Crop real defect patch from dataset annotations.
2. Extract pure background regions avoiding original defect area.
3. Use NCC (normalized cross‑correlation) template matching to find globally optimal texture position.
4. White‑pixel ratio check to avoid pasting onto white table background.
5. Poisson seamless cloning for image blending.
6. Save synthesized image and YOLO‑format label.

Note:
- All synthesized samples keep globally optimal texture matching.
- Color mismatched samples are preserved and handled by downstream Poincaré‑ball filtering module.
"""

import os
import cv2
import numpy as np
import random
from tqdm import tqdm


def get_white_ratio(patch, threshold=200):
    """
    Calculate white pixel ratio of image patch, avoid defect pasting on white table.
    :param patch: input image patch
    :param threshold: grayscale threshold for white pixel
    :return: ratio of white pixels
    """
    gray = cv2.cvtColor(patch, cv2.COLOR_BGR2GRAY)
    white_pixels = np.sum(gray > threshold)
    return white_pixels / gray.size


def get_defect_crop(img, txt_path):
    """
    Crop real defect patch from image using YOLO annotation file.
    :param img: source image
    :param txt_path: yolo annotation txt path
    :return: defect image patch, None if invalid
    """
    if not os.path.exists(txt_path):
        return None
    with open(txt_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        if not lines:
            return None
        cx, cy, bw, bh = map(float, lines[0].strip().split()[1:5])

    h_img, w_img = img.shape[:2]
    x1 = max(0, int((cx - bw / 2) * w_img))
    y1 = max(0, int((cy - bh / 2) * h_img))
    x2 = min(w_img, int((cx + bw / 2) * w_img))
    y2 = min(h_img, int((cy + bh / 2) * h_img))

    if x2 <= x1 or y2 <= y1:
        return None
    return img[y1:y2, x1:x2]


def get_pure_background_candidates(img, txt_path, margin=15):
    """
    Get four pure background sub‑regions, exclude area around original defect.
    :param img: source image
    :param txt_path: yolo annotation
    :param margin: safety margin around original defect bbox
    :return: list of background candidates {"box": image_roi, "area": pixel_area}
    """
    if not os.path.exists(txt_path):
        return []
    with open(txt_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
        if not lines:
            return None
        cx, cy, bw, bh = map(float, lines[0].strip().split()[1:5])

    h_img, w_img = img.shape[:2]
    x1 = int((cx - bw / 2) * w_img)
    y1 = int((cy - bh / 2) * h_img)
    x2 = int((cx + bw / 2) * w_img)
    y2 = int((cy + bh / 2) * h_img)

    safe_x1 = max(0, x1 - margin)
    safe_y1 = max(0, y1 - margin)
    safe_x2 = min(w_img, x2 + margin)
    safe_y2 = min(h_img, y2 + margin)

    candidates = [
        {"box": img[0:h_img, 0:safe_x1], "area": h_img * safe_x1},
        {"box": img[0:h_img, safe_x2:w_img], "area": h_img * (w_img - safe_x2)},
        {"box": img[0:safe_y1, 0:w_img], "area": safe_y1 * w_img},
        {"box": img[safe_y2:h_img, 0:w_img], "area": (h_img - safe_y2) * w_img}
    ]
    return [c for c in candidates if c["area"] > 0 and c["box"].size > 0]


def main():
    # ===================== Configuration =====================
    BASE_IMG_DIR = r"D:\pangjialai\yolo_datasets\dataset_baseline\images\train"
    BASE_LBL_DIR = r"D:\pangjialai\yolo_datasets\dataset_baseline\labels\train"
    OUTPUT_BASE = r"D:\pangjialai\dataset_10k_candidate_pool"

    TOTAL_TARGET = 10000
    WHITE_RATIO_THRESHOLD = 0.01
    MARGIN = 15
    # =========================================================

    os.makedirs(os.path.join(OUTPUT_BASE, "images/train"), exist_ok=True)
    os.makedirs(os.path.join(OUTPUT_BASE, "labels/train"), exist_ok=True)

    base_images = [f for f in os.listdir(BASE_IMG_DIR) if f.lower().endswith(('.png', '.jpg'))]
    if not base_images:
        print("[ERROR] Dataset folder is empty.")
        return

    success_count = 0
    print(f"[INFO] Start generating {TOTAL_TARGET} candidate samples. Output: {OUTPUT_BASE}")

    with tqdm(total=TOTAL_TARGET) as pbar:
        while success_count < TOTAL_TARGET:
            try:
                # Sample defect patch
                def_name = random.choice(base_images)
                raw_def_img = cv2.imread(os.path.join(BASE_IMG_DIR, def_name))
                def_txt = os.path.join(BASE_LBL_DIR, os.path.splitext(def_name)[0] + ".txt")
                defect_crop = get_defect_crop(raw_def_img, def_txt)
                if defect_crop is None:
                    continue
                dh, dw = defect_crop.shape[:2]

                # Sample pure background canvas
                bg_name = random.choice(base_images)
                raw_bg = cv2.imread(os.path.join(BASE_IMG_DIR, bg_name))
                bg_txt = os.path.join(BASE_LBL_DIR, os.path.splitext(bg_name)[0] + ".txt")
                bg_candidates = get_pure_background_candidates(raw_bg, bg_txt, margin=MARGIN)
                valid_cands = [c for c in bg_candidates if c["box"].shape[0] > dh and c["box"].shape[1] > dw]
                if not valid_cands:
                    continue
                pure_bg = max(valid_cands, key=lambda x: x["area"])["box"]
                ph, pw = pure_bg.shape[:2]

                gray_defect = cv2.cvtColor(defect_crop, cv2.COLOR_BGR2GRAY)
                gray_bg = cv2.cvtColor(pure_bg, cv2.COLOR_BGR2GRAY)
                if gray_bg.shape[0] <= gray_defect.shape[0] or gray_bg.shape[1] <= gray_defect.shape[1]:
                    continue

                # NCC template matching, get globally best texture position
                ncc_heatmap = cv2.matchTemplate(gray_defect, gray_bg, cv2.TM_CCOEFF_NORMED)
                _, _, _, max_loc = cv2.minMaxLoc(ncc_heatmap)
                best_center = (max_loc[0] + dw // 2, max_loc[1] + dh // 2)

                # White‑pixel check for optimal position
                target_patch = pure_bg[max_loc[1]: max_loc[1] + dh, max_loc[0]: max_loc[0] + dw]
                if get_white_ratio(target_patch) > WHITE_RATIO_THRESHOLD:
                    continue

                # Poisson seamless clone
                mask = 255 * np.ones(defect_crop.shape, defect_crop.dtype)
                mixed = cv2.seamlessClone(defect_crop, pure_bg, mask, best_center, cv2.NORMAL_CLONE)

                # Save image and yolo label
                save_name = f"v13_candidate_{success_count:05d}.jpg"
                cv2.imwrite(os.path.join(OUTPUT_BASE, "images/train", save_name), mixed)

                cx_norm = best_center[0] / pw
                cy_norm = best_center[1] / ph
                w_norm = dw / pw
                h_norm = dh / ph
                label_path = os.path.join(OUTPUT_BASE, "labels/train", f"v13_candidate_{success_count:05d}.txt")
                with open(label_path, 'w', encoding='utf-8') as f:
                    f.write(f"0 {cx_norm:.6f} {cy_norm:.6f} {w_norm:.6f} {h_norm:.6f}\n")

                success_count += 1
                pbar.update(1)

            except Exception:
                continue

    print("=" * 50)
    print(f"[FINISH] Generated {TOTAL_TARGET} candidate samples.")
    print(f"[OUTPUT] {OUTPUT_BASE}")
    print("=" * 50)


if __name__ == "__main__":
    main()