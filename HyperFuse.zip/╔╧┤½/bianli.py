import os
import numpy as np
from PIL import Image

# ========== 修改这里为你本地真实数据集路径 ==========
img_dir = r"D:\pangjialai\yolo_datasets\dataset_baseline\images\train"   # 原始图片文件夹
label_dir = r"D:\pangjialai\yolo_datasets\dataset_baseline\labels\train" # yolo txt标注文件夹
# ====================================================

box_w_px = []
box_h_px = []

txt_files = [f for f in os.listdir(label_dir) if f.lower().endswith(".txt")]

for txt_name in txt_files:
    base = os.path.splitext(txt_name)[0]
    img_path = os.path.join(img_dir, base + ".jpg")
    if not os.path.exists(img_path):
        img_path = os.path.join(img_dir, base + ".png")
    if not os.path.exists(img_path):
        continue

    im = Image.open(img_path)
    img_w, img_h = im.size

    txt_path = os.path.join(label_dir, txt_name)
    with open(txt_path, "r", encoding="utf-8") as f:
        lines = f.readlines()

    for line in lines:
        line = line.strip()
        if not line:
            continue
        parts = list(map(float, line.split()))
        # yolo: cls xc yc w_norm h_norm
        w_norm = parts[3]
        h_norm = parts[4]
        bw = w_norm * img_w
        bh = h_norm * img_h
        box_w_px.append(bw)
        box_h_px.append(bh)


box_w_px = np.array(box_w_px)
box_h_px = np.array(box_h_px)

print(f"总缺陷框数量：{len(box_w_px)}")
print(f"宽度(像素)  均值:{np.mean(box_w_px):.1f}  中位数:{np.median(box_w_px):.1f}  min:{np.min(box_w_px):.1f}  max:{np.max(box_w_px):.1f}")
print(f"高度(像素)  均值:{np.mean(box_h_px):.1f}  中位数:{np.median(box_h_px):.1f}  min:{np.min(box_h_px):.1f}  max:{np.max(box_h_px):.1f}")
print(f"平均框尺寸：{np.mean(box_w_px):.0f} × {np.mean(box_h_px):.0f}")